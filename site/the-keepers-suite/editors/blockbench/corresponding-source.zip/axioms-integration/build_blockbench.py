#!/usr/bin/env python3
"""Build a pinned, separately distributed Blockbench web companion. No game content."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile

REVISION = '574d8a0ae148fc5b36bb52b7bb1f8940022dd079'
UPSTREAM = 'https://github.com/JannisX11/blockbench.git'


def run(args, cwd, timeout=300):
    result = subprocess.run(args, cwd=cwd, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, timeout=timeout)
    if result.returncode:
        raise RuntimeError(f'{args[0]} failed ({result.returncode}):\n{result.stdout[-8000:]}')
    return result.stdout.strip()


def build(output: Path, support: Path):
    output = output.resolve()
    support = support.resolve()
    if output.exists() and any(output.iterdir()):
        raise ValueError('Editor output must be empty; refusing to overwrite another artifact.')
    root = Path(os.environ.get('RUNNER_TOOL_CACHE', tempfile.gettempdir())) / 'axioms-editor-builds' / REVISION
    source = root / 'source'
    root.mkdir(parents=True, exist_ok=True)
    if not (source / '.git').exists():
        source.mkdir(exist_ok=True)
        run(['git', 'init', '-q'], source)
        run(['git', 'remote', 'add', 'origin', UPSTREAM], source)
        run(['git', 'fetch', '--depth', '1', 'origin', REVISION], source)
        run(['git', 'checkout', '--detach', 'FETCH_HEAD'], source)
    if run(['git', 'rev-parse', 'HEAD'], source) != REVISION or run(['git', 'diff', '--name-only'], source):
        raise ValueError('The cached upstream source is not the exact clean pinned revision.')
    bundle = source / 'dist/bundle.js'
    stamp = root / 'compiled.json'
    expected = json.loads(stamp.read_text()) if stamp.exists() else {}
    cached = bundle.exists() and expected.get('revision') == REVISION and expected.get('bundle_sha256') == hashlib.sha256(bundle.read_bytes()).hexdigest()
    if not cached:
        run(['npm', 'ci', '--ignore-scripts', '--no-audit', '--no-fund'], source, 600)
        run(['npm', 'run', 'build-web'], source, 300)
        stamp.write_text(json.dumps({'revision': REVISION, 'bundle_sha256': hashlib.sha256(bundle.read_bytes()).hexdigest()}))
    output.mkdir(parents=True, exist_ok=True)
    for name in ['assets', 'css', 'font', 'lib']:
        if (source / name).is_dir():
            shutil.copytree(source / name, output / name, ignore=shutil.ignore_patterns('*.map', '.*'))
    (output / 'dist').mkdir()
    # Public hosts need not permit loose source maps: corresponding source is explicit below.
    script = bundle.read_text()
    script = '\n'.join(line for line in script.split('\n') if not line.startswith('//# sourceMappingURL='))
    (output / 'dist/bundle.js').write_text(script)
    for item in source.iterdir():
        if item.is_file() and (item.suffix in ['.png', '.ico', '.webmanifest'] or item.name == 'LICENSE.MD'):
            shutil.copy2(item, output / item.name)
    for name in ['blockbench-bridge.js', 'isolated-storage.js']:
        shutil.copy2(support / name, output / name)
    html = (source / 'index.html').read_text()
    if '<head>' not in html or '</body>' not in html:
        raise ValueError('Pinned upstream HTML structure changed.')
    html = html.replace('<head>', '<head>\n<script src="isolated-storage.js"></script>', 1)
    html = html.replace('</body>', '<script src="blockbench-bridge.js"></script>\n</body>', 1)
    if not (output / 'manifest.webmanifest').exists():
        html = html.replace('<link rel="manifest" href="manifest.webmanifest">', '')
    (output / 'index.html').write_text(html)
    archive = output / 'corresponding-source.zip'
    run(['git', 'archive', '--format=zip', '-o', str(archive), REVISION], source)
    with zipfile.ZipFile(archive, 'a', compression=zipfile.ZIP_DEFLATED) as package:
        package.write(__file__, 'axioms-integration/build_blockbench.py')
        for name in ['blockbench-bridge.js', 'isolated-storage.js']:
            package.write(support / name, 'axioms-integration/' + name)
        package.write(source / 'dist/bundle.js.map', 'axioms-integration/bundle.js.map')
        package.writestr('axioms-integration/index.html', html)
    (output / 'SOURCES.md').write_text(
        '# Blockbench browser companion\n\n'
        f'Upstream: https://github.com/JannisX11/blockbench/tree/{REVISION}\n\n'
        'License: GPL-3.0-or-later; see LICENSE.MD. This is the real upstream editor, not an Axioms-owned modeler.\n\n'
        'The exact upstream source, companion scripts, modified HTML, build recipe and bundled-dependency source map '
        'are in corresponding-source.zip. Use the included lockfile and '
        '`npm ci --ignore-scripts; npm run build-web` to reproduce the upstream bundle. '
        'The companion uses the versioned artifact protocol; no game code is linked into this editor.\n\n'
        'Modifications: namespaced browser storage and the same-origin project/GLB handoff script, loaded by two added script tags. '
        'The loose source-map reference is removed; its complete contents remain in corresponding-source.zip. '
        'Editor source and GLB are separate artifacts. Download both from Studio to retain/share your work.\n')
    files = {p.relative_to(output).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
             for p in sorted(output.rglob('*')) if p.is_file()}
    (output / 'upstream.json').write_text(json.dumps({'schema': 1, 'revision': REVISION,
        'license': 'GPL-3.0-or-later', 'files': files}, indent=2) + '\n')
    print(f'BLOCKBENCH_BUILD revision={REVISION} reused={str(cached).lower()} files={len(files)} bytes={sum(p.stat().st_size for p in output.rglob("*") if p.is_file())}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    parser.add_argument('--support', type=Path, default=Path(__file__).resolve().parent.parent / 'web')
    args = parser.parse_args()
    build(args.output, args.support)
