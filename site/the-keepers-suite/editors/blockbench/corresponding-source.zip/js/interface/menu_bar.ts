import { ModelLoader } from "../io/model_loader";
import { Menu, MenuItem, MenuOpenPositionAnchor, MenuOptions } from "./menu"
import { currentwindow, exposeNativeApisInDevTools } from "../native_apis";

declare global {
	function factoryResetAndReload(): void
	interface Window {
		ErrorLog: {message: string, file: string, line: number}[]
	}
}
export interface BarMenuOptions extends MenuOptions {
	name?: string
	icon?: IconString
	condition?: ConditionResolvable
}
/**
 * Creates a new menu in the menu bar
 */
export class BarMenu extends Menu {
	type: 'bar_menu' = 'bar_menu';
	name: string
	icon: IconString
	label: HTMLElement
	constructor(id: string, structure: MenuItem[] | ((context: any) => MenuItem[]), options: BarMenuOptions = {}) {
		super(id, structure, options)
		MenuBar.menus[id] = this
		this.type = 'bar_menu'
		this.id = id
		this.children = [];
		this.condition = options.condition
		this.node = document.createElement('ul');
		this.node.className = 'contextMenu menu_bar_menu';
		this.node.style.minHeight = '8px';
		this.node.style.minWidth = '150px';
		this.icon = options.icon;
		this.name = tl(options.name || `menu.${id}`);
		this.label = Interface.createElement('li', {class: 'menu_bar_point'}, this.name);
		this.label.addEventListener('click', (event) => {
			if (Menu.open === this) {
				this.hide()
			} else {
				this.open()
			}
		})
		this.label.addEventListener('mouseenter', (event) => {
			if (MenuBar.open && MenuBar.open !== this) {
				this.open()
			}
		})
		this.structure = structure;
		this.highlight_action = null;
	}
	open(position?: MenuOpenPositionAnchor, context?: any): this {
		super.open(position, context);
		Blockbench.dispatchEvent('open_bar_menu', {menu: this});
		return this;
	}
	hide() {
		super.hide();
		this.label.classList.remove('opened');
		MenuBar.open = undefined;
		this.highlight_action = null;
		this.label.classList.remove('highlighted');
		if (MenuBar.last_opened == this) document.getElementById('mobile_menu_bar')?.remove();
		return this;
	}
	/**
	 * Visually highlights an action within the menu, until the user opens the menu
	 */
	highlight(action: MenuItem): void {
		this.highlight_action = action;
		this.label.classList.add('highlighted');
	}
	delete() {
		super.delete();
		this.label.remove();
		delete MenuBar.menus[this.id];
	}
}

export const MenuBar = {
	menus: {} as {
		file: BarMenu
		edit: BarMenu
		transform: BarMenu
		uv: BarMenu
		texture: BarMenu
		animation: BarMenu
		keyframe: BarMenu
		display: BarMenu
		tools: BarMenu
		view: BarMenu
		help: BarMenu
		[id: string]: BarMenu
	},
		/**
	 * @deprecated
	 */
	menues: {} as Record<string, Menu>,
	keys: [] as string[],
	open: null as Menu | null,
	last_opened: null,
	mode_switcher_button: null as null | HTMLDivElement,
	setup() {
		MenuBar.menues = MenuBar.menus;
		new BarMenu('file', [
			new MenuSeparator('file_options'),
			'project_window',
			new MenuSeparator('open'),
			{name: 'menu.file.new', id: 'new', icon: 'insert_drive_file',
				children: function() {
					let arr = [];
					let redact = settings.streamer_mode.value;
					for (let key in Formats) {
						let format = Formats[key];
						if (format.show_in_new_list === false) continue;
						arr.push({
							id: format.id,
							name: (redact && format.confidential) ? `[${tl('generic.redacted')}]` : format.name,
							icon: format.icon,
							description: format.description,
							click: (e) => {
								format.new()
							}
						})
					}
					arr.push(new MenuSeparator('loaders', 'format_category.loaders'));
					for (let key in ModelLoader.loaders) {
						let loader = ModelLoader.loaders[key];
						arr.push({
							id: loader.id,
							name: (redact && loader.confidential) ? `[${tl('generic.redacted')}]` : loader.name,
							icon: loader.icon,
							description: loader.description,
							click: (e) => {
								loader.new()
							}
						})
					}
					return arr;
				}
			},
			{name: 'menu.file.recent', id: 'recent', icon: 'history',
				condition() {return isApp && recent_projects.length > 0},
				searchable: true,
				children() {
					var arr = []
					let redact = settings.streamer_mode.value;
					for (let p of recent_projects) {
						if (arr.length > 12) break;
						arr.push({
							name: redact ? `[${tl('generic.redacted')}]` : p.name,
							path: p.path,
							description: redact ? '' : p.path,
							icon: p.icon,
							click(c, event) {
								Blockbench.read([p.path], {}, files => {
									loadModelFile(files[0]);
								})
							}
						})
					}
					if (recent_projects.length > 12) {
						arr.push('_', {
							name: 'menu.file.recent.more',
							icon: 'read_more',
							always_show: true,
							click(c, event) {
								ActionControl.select('recent: ');
							}
						})
					}
					if (arr.length) {
						arr.push('_', {
							name: 'menu.file.recent.clear',
							icon: 'clear',
							always_show: true,
							click(c, event) {
								recent_projects.empty();
								updateRecentProjects();
							}
						})
					}
					return arr
				}
			},
			'open_model',
			'open_from_link',
			'new_window',
			new MenuSeparator('project'),
			'save_project',
			'save_project_as',
			'save_project_incremental',
			'convert_project',
			'close_project',
			new MenuSeparator('import_export'),
			{name: 'menu.file.import', id: 'import', icon: 'insert_drive_file', condition: () => Format && !Format.pose_mode, children: [
				{
					id: 'import_open_project',
					name: 'menu.file.import.import_open_project',
					icon: 'input',
					condition: () => Project && ModelProject.all.length > 1,
					children() {
						let projects = [];
						ModelProject.all.forEach(project => {
							if (project == Project) return;
							projects.push({
								name: project.getDisplayName(true),
								icon: project.format.icon,
								description: project.path,
								click() {
									let current_project = Project;
									project.select();
									let bbmodel = Codecs.project.compile();
									current_project.select();
									Codecs.project.merge(JSON.parse(bbmodel));
								}
							})
						})
						return projects;
					}
				},
				'import_project',
				'import_java_block_model',
				'import_optifine_part',
				'import_bedrock_attachable',
				'import_bedrock_voxel_shape',
				'import_obj',
				'extrude_texture'
			]},
			{name: 'generic.export', id: 'export', icon: 'insert_drive_file', condition: () => !!Project, children: [
				'export_blockmodel',
				'export_bedrock',
				'export_entity',
				'export_bedrock_voxel_shape',
				'export_class_entity',
				'export_optifine_full',
				'export_optifine_part',
				'export_minecraft_skin',
				'export_image',
				'export_gltf',
				'export_obj',
				'export_fbx',
				'export_stl',
				'export_collada',
				'export_legacy_project',
				'export_modded_animations',
				'upload_sketchfab',
				'share_model',
			]},
			'export_over',
			'export_asset_archive',
			new MenuSeparator('options'),
			{name: 'menu.file.preferences', id: 'preferences', icon: 'tune', children: [
				'settings_window',
				'keybindings_window',
				'theme_window',
				{
					id: 'profiles',
					name: 'data.settings_profile',
					icon: 'manage_accounts',
					condition: () => SettingsProfile.all.findIndex(p => p.condition.type == 'selectable') != -1,
					children: () => {
						let list: MenuItem[] = [
							{
								name: 'generic.none',
								icon: SettingsProfile.selected ? 'far.fa-circle' : 'far.fa-dot-circle',
								click: () => {
									SettingsProfile.unselect();
								}
							},
							'_'
						];
						SettingsProfile.all.forEach(profile => {
							if (profile.condition.type != 'selectable') return;
							list.push({
								name: profile.name,
								icon: profile.selected ? 'far.fa-dot-circle' : 'far.fa-circle',
								color: markerColors[profile.color % markerColors.length].standard,
								click: () => {
									profile.select();
								}
							})
						})
						return list;
					}
				}
			]},
			'plugins_window',
			'edit_session'
		], {icon: 'draft'})
		new BarMenu('edit', [
			new MenuSeparator('undo'),
			'undo',
			'redo',
			'edit_history',
			new MenuSeparator('add_element'),
			'add_element',
			'add_group',
			new MenuSeparator('modify_elements'),
			'duplicate',
			'rename',
			'find_replace',
			'unlock_everything',
			'delete',
			'apply_mirror_modeling',
			new MenuSeparator('mesh_specific'),
			new MenuSeparator('editing_mode'),
			'proportional_editing',
			'mirror_modeling',
			new MenuSeparator('selection'),
			'select_window',
			'select_all',
			'unselect_all',
			'invert_selection',
			'expand_texture_selection'
		], {icon: 'edit'})
		new BarMenu('transform', [
			'scale',
			{name: 'menu.transform.rotate', id: 'rotate', icon: 'rotate_90_degrees_ccw', children: [
				'rotate_x_cw',
				'rotate_x_ccw',
				'rotate_y_cw',
				'rotate_y_ccw',
				'rotate_z_cw',
				'rotate_z_ccw'
			]},
			{name: 'menu.transform.flip', id: 'flip', icon: 'flip', children: [
				'flip_x',
				'flip_y',
				'flip_z',
				'flip_in_place_x',
				'flip_in_place_y',
				'flip_in_place_z'
			]},
			{name: 'menu.transform.center', id: 'center', icon: 'filter_center_focus', children: [
				'center_x',
				'center_y',
				'center_z',
				'center_lateral'
			]},
			{name: 'menu.transform.properties', id: 'properties', icon: 'navigate_next', children: [
				'toggle_visibility',
				'toggle_locked',
				'toggle_export',
				'toggle_autouv',
				'toggle_shade',
				'toggle_mirror_uv'
			]}

		], {
			icon: 'open_with',
			condition: {modes: ['edit']},
		})
		new BarMenu('mesh', [
			new MenuSeparator('geometry'),
			'extrude_mesh_selection',
			'inset_mesh_selection',
			'loop_cut',
			'create_face',
			'invert_face',
			'switch_face_crease',
			'merge_vertices',
			'dissolve_edges',
			'solidify_mesh_selection',
			'set_vertex_weights',
			new MenuSeparator('element'),
			'apply_mesh_rotation',
			'split_mesh',
			'merge_meshes',
		], {icon: 'fa-gem', condition: {selected: {mesh: true}, modes: ['edit']}})

		new BarMenu('skin', [
			new MenuSeparator('view'),
			'custom_skin_poses',
			'add_custom_skin_pose',
			new MenuSeparator('edit'),
			'toggle_skin_layer',
			'explode_skin_model',
			'convert_minecraft_skin_variant',
		], {icon: 'icon-player', condition: {formats: ['skin']}})

		new BarMenu('uv', UVEditor.menu.structure, {
			condition: {modes: ['edit']},
			icon: 'photo_size_select_large',
			onOpen() {
				setActivePanel('uv');
			}
		})

		new BarMenu('image', [
			new MenuSeparator('adjustment'),
			'adjust_brightness_contrast',
			'adjust_saturation_hue',
			'adjust_opacity',
			'invert_colors',
			'adjust_curves',
			new MenuSeparator('filters'),
			'limit_to_palette',
			'split_rgb_into_layers',
			'split_alpha_into_layer',
			'clear_unused_texture_space',
			new MenuSeparator('transform'),
			'flip_texture_x',
			'flip_texture_y',
			'rotate_texture_cw',
			'rotate_texture_ccw',
			'resize_texture',
			'crop_texture_to_selection'
		], {
			icon: 'image',
			condition: {modes: ['paint']}
		})

		new BarMenu('paint', [
			new MenuSeparator('options'),
			'mirror_painting',
			'color_erase_mode',
			'lock_alpha',
			'painting_grid',
			'pixel_perfect_drawing',
			'brush_lock_mode',
			new MenuSeparator('operations'),
		], {
			icon: 'fa-paint-brush',
			condition: {modes: ['paint']}
		})

		new BarMenu('animation', [
			new MenuSeparator('edit_options'),
			'animation_onion_skin',
			'animation_onion_skin_selective',
			'toggle_motion_trails',
			'lock_motion_trail',
			new MenuSeparator('edit'),
			'add_marker',
			'select_effect_animator',
			'copy_animation_pose',
			'flip_animation',
			'optimize_animation',
			'retarget_animators',
			'bake_ik_animation',
			'bake_animation_into_model',
			'merge_animation',
			new MenuSeparator('file'),
			'load_animation_file',
			'save_all_animations',
			'export_animation_file'
		], {
			icon: 'movie',
			condition: {modes: ['animate']}
		})

		new BarMenu('keyframe', [
			new MenuSeparator('copypaste'),
			'copy',
			'paste',
			new MenuSeparator('edit'),
			'add_keyframe',
			'keyframe_column_create',
			'reverse_keyframes',
			{name: 'menu.animation.flip_keyframes', id: 'flip_keyframes', condition: () => Timeline.selected.length > 0, icon: 'flip', children: [
				'flip_x',
				'flip_y',
				'flip_z'
			]},
			'keyframe_uniform',
			'reset_keyframe',
			'round_keyframe_values',
			'resolve_keyframe_expressions',
			'delete',
			new MenuSeparator('select'),
			'select_all',
			'keyframe_column_select',
			'keyframe_select_before_playhead',
			'keyframe_select_after_playhead',
		], {
			icon: 'icon-keyframe',
			condition: {modes: ['animate']}
		})

		new BarMenu('timeline', Timeline.menu.structure, {
			name: 'panel.timeline',
			icon: 'timeline',
			condition: {modes: ['animate'], method: () => !AnimationController.selected},
			onOpen() {
				setActivePanel('timeline');
			}
		})

		new BarMenu('display', [
			new MenuSeparator('copypaste'),
			'copy',
			'paste',
			new MenuSeparator('presets'),
			'add_display_preset',
			'apply_display_preset'
		], {
			icon: 'tune',
			condition: {modes: ['display']}
		})
		
		new BarMenu('tools', [
			new MenuSeparator('overview'),
			{id: 'main_tools', icon: 'construction', name: 'menu.tools.main_tools', condition: () => !!Project, children() {
				let tools: Tool[] = Toolbox.children.filter(tool => tool instanceof Tool && tool.condition !== false) as Tool[];
				tools.forEach(tool => {
					let old_condition = tool.condition;
					tool.condition = () => {
						tool.condition = old_condition;
						return true;
					}
				})
				let modes = Object.keys(Modes.options);
				tools.sort((a, b) => {
					return (a.modes ? modes.indexOf(a.modes[0]) : -1) - (b.modes ? modes.indexOf(b.modes[0]) : -1);
				})
				let menu_entries: (Tool|'_')[] = tools;
				let mode = tools[0].modes?.[0];
				for (let i = 0; i < tools.length; i++) {
					if (tools[i].modes?.[0] !== mode) {
						mode = tools[i].modes?.[0];
						menu_entries.splice(i, 0, '_');
						i++;
					}
				}
				return menu_entries;
			}},
			'swap_tools',
			'action_control',
			new MenuSeparator('tools'),
			'predicate_overrides',
			'convert_to_mesh',
			'auto_set_cullfaces',
			'remove_blank_faces',
			'generate_voxel_shapes',
			'generate_bedrock_block_box',
			'generate_bedrock_entity_box',
			'slice_bedrock_multiblock',
		], {icon: 'handyman'})
		MenuBar.menus.filter = MenuBar.menus.tools;

		new BarMenu('view', [
			new MenuSeparator('window'),
			'fullscreen',
			new MenuSeparator('interface'),
			{
				id: 'panels',
				name: 'menu.view.panels',
				icon: 'web_asset',
				children() {
					let entries = [];
					let available_panels = [];
					for (let id in Panels) {
						let panel = Panels[id];
						if (!Condition(panel.condition)) continue;
						available_panels.push(panel);
					}

					for (let panel of available_panels) {
						let menu_entry = {
							id: panel.id,
							name: panel.name,
							icon: panel.icon,
							context: panel,
							children: panel.snap_menu.structure
						}
						entries.push(menu_entry);
					}
					return entries;
				}
			},
			'toggle_sidebars',
			'split_screen',
			new MenuSeparator('viewport'),
			'view_mode',
			'toggle_shading',
			'toggle_all_grids',
			'toggle_ground_plane',
			'preview_checkerboard',
			'pixel_grid',
			'painting_grid',
			new MenuSeparator('references'),
			'bedrock_animation_mode',
			'preview_scene',
			'preview_models',
			'edit_reference_images',
			new MenuSeparator('model'),
			'hide_everything_except_selection',
			'focus_on_selection',
			{name: 'menu.view.screenshot', id: 'screenshot', icon: 'camera_alt', children: []},
			new MenuSeparator('media'),
			'screenshot_model',
			'screenshot_app',
			'advanced_screenshot',
			'record_model_gif',
			'timelapse',
		], {icon: 'visibility'})
		new BarMenu('help', [
			new MenuSeparator('search'),
			{name: 'menu.help.search_action', description: BarItems.action_control.description, keybind: BarItems.action_control.keybind, id: 'search_action', icon: 'search', click: ActionControl.select},
			new MenuSeparator('links'),
			{name: 'menu.help.quickstart', id: 'quickstart', icon: 'fas.fa-directions', click: () => {
				Blockbench.openLink('https://blockbench.net/quickstart/');
			}},
			{name: 'menu.help.discord', id: 'discord', icon: 'fab.fa-discord', condition: () => (!settings.classroom_mode.value), click: () => {
				Blockbench.openLink('http://discord.blockbench.net');
			}},
			{name: 'menu.help.wiki', id: 'wiki', icon: 'menu_book', click: () => {
				Blockbench.openLink('https://blockbench.net/wiki/');
			}},
			{name: 'menu.help.report_issue', id: 'report_issue', icon: 'bug_report', click: () => {
				Blockbench.openLink('https://github.com/JannisX11/blockbench/issues');
			}},
			new MenuSeparator('backups'),
			'view_backups',
			new MenuSeparator('about'),
			{name: 'menu.help.developer', id: 'developer', icon: 'fas.fa-wrench', children: [
				'reload_plugins',
				{name: 'menu.help.plugin_documentation', id: 'plugin_documentation', icon: 'fa-book', click: () => {
					Blockbench.openLink('https://www.blockbench.net/wiki/docs/plugin');
				}},
				'experimental_settings',
				'open_dev_tools',
				{
					name: 'Error Log',
					condition: () => window.ErrorLog.length > 0,
					icon: 'error',
					color: 'red',
					keybind: {toString: () => window.ErrorLog.length.toString()} as any,
					click() {
						let error_messages = window.ErrorLog.map((error) => {
							return `${error.message}\n - In .${error.file.split(location.origin).join('')} : ${error.line}`;
						})
						let lines = error_messages.slice(0, 64).map((message) => {
							return Interface.createElement('p', {style: 'word-break: break-word;'}, message);
						})
						new Dialog({
							id: 'error_log',
							title: 'Error Log',
							lines,
							buttons: ['action.copy', 'dialog.close'],
							confirmIndex: 1,
							cancelIndex: 1,
							onButton(index) {
								if (index == 0) {
									Clipbench.setText(error_messages.slice(0, 256).join('\n'));
								}
							}
						}).show();
					}
				},
				{name: 'Expose Native Modules', icon: 'terminal', condition: isApp && (() => {
					return currentwindow.webContents.isDevToolsOpened();
				}), click: () => {
					exposeNativeApisInDevTools();
				}},
				{name: 'menu.help.developer.reset_storage', icon: 'fas.fa-hdd', click: () => {
					factoryResetAndReload();
				}},
				{name: 'menu.help.developer.unlock_projects', id: 'unlock_projects', icon: 'vpn_key', condition: () => ModelProject.all.some(project => project.locked), click() {
					ModelProject.all.forEach(project => project.locked = false);
				}},
				{
					name: 'Uncorrupt Mesh',
					id: 'uncorrupt_mesh',
					icon: 'build',
					condition: () => Mesh.hasSelected(),
					click() {
						// @ts-ignore
						uncorruptMesh();
					}
				},
				{name: 'menu.help.developer.cache_reload', id: 'cache_reload', icon: 'cached', condition: !isApp, click: () => {
					if('caches' in window){
						caches.keys().then((names) => {
							names.forEach(async (name) => {
								await caches.delete(name)
							})
						})
					}
					// @ts-expect-error
					window.location.reload(true)
				}},
				'reload',
			]},
			'reset_layout',
			'about_window'
		], {icon: 'help'})
		MenuBar.update();

		if (Blockbench.isMobile) {
			let header = document.querySelector('header');
			document.getElementById('menu_bar').remove();
			document.getElementById('header_free_bar').remove();
			document.getElementById('corner_logo').remove();

			let menu_button = Interface.createElement('div', {class: 'tool'}, Blockbench.getIconNode('menu'));
			menu_button.addEventListener('click', event => {
				MenuBar.openMobile(menu_button, event);
			})
			let search_button = Interface.createElement('div', {class: 'tool'}, Blockbench.getIconNode('search'));
			search_button.addEventListener('click', event => {
				ActionControl.select()
			})
			let undo_button = Interface.createElement('div', {class: 'tool'}, Blockbench.getIconNode('undo'));
			undo_button.addEventListener('click', event => {
				BarItems.undo.trigger()
			})
			let redo_button = Interface.createElement('div', {class: 'tool'}, Blockbench.getIconNode('redo'));
			redo_button.addEventListener('click', event => {
				BarItems.redo.trigger()
			})
			let mode_switcher = Interface.createElement('div', {class: 'tool hidden', style: 'margin-left: auto'}, Blockbench.getIconNode('settings')) as HTMLDivElement;
			mode_switcher.addEventListener('click', event => {
				Modes.mobileModeMenu(mode_switcher, event);
			})
			MenuBar.mode_switcher_button = mode_switcher;

			let home_button = document.getElementById('title_bar_home_button');
			let profile_button = document.getElementById('settings_profiles_header_menu');

			let buttons = [menu_button, search_button, profile_button, home_button, undo_button, redo_button,, mode_switcher];
			buttons.forEach(button => {
				header.append(button);
			})

			header.addEventListener('touchstart', e1 => {
				convertTouchEvent(e1);
				let opened, bar, initial;
				let onMove = (e2: TouchEvent) => {
					convertTouchEvent(e2);
					// @ts-expect-error
					let y_diff = e2.clientY - e1.clientY;
					if (y_diff > 16) {
						if (!opened) {
							bar = MenuBar.openMobile(menu_button);
							opened = true;
							initial = y_diff;
						}
					}
					if (bar) {
						bar.style.marginTop = Math.clamp(y_diff - 50, -60, 0)+'px';
						for (let node of bar.childNodes) {
							if (!node.bbOpenMenu) continue;
							let offset_center = bar.offsetLeft + node.offsetLeft + node.clientWidth/2;
							// @ts-expect-error
							if (Math.abs(offset_center - e2.clientX) < 21) {
								node.bbOpenMenu(e2);
								break;
							}
						}
					}
				}
				let onStop = (e2: TouchEvent) => {
					document.removeEventListener('touchmove', onMove);
					document.removeEventListener('touchend', onStop);
					if (bar) {
						bar.style.marginTop = '0';
						convertTouchEvent(e2);
						// @ts-expect-error
						let y_diff = e2.clientY - e1.clientY;
						if (y_diff < initial && MenuBar.open) {
							MenuBar.open.hide()
						}
					}
				}
				document.addEventListener('touchmove', onMove);
				document.addEventListener('touchend', onStop);
			})
		}
	},
	openMobile(button: HTMLElement, event?: Event) {
		if (document.getElementById('mobile_menu_bar')) {
			document.getElementById('mobile_menu_bar').remove();
			return;
		}
		let label = Interface.createElement('label', {});
		let bar = Interface.createElement('div', {id: 'mobile_menu_bar'}, label);
		let menu_button_nodes = [];
		let menu_position;
		let setSelected = (node: HTMLElement, menu: BarMenu) => {
			menu_button_nodes.forEach(n => n.classList.remove('selected'))
			node.classList.add('selected');
			label.innerText = menu.name;
		}
		for (let id in MenuBar.menus) {
			let menu = MenuBar.menus[id];
			if (id == 'filter') continue;
			if (!Condition(menu.condition)) continue;

			let node = Interface.createElement('div', {class: 'tool'}, Blockbench.getIconNode(menu.icon));
			let openMenu = (event: Event) => {
				if (MenuBar.last_opened == menu) return;
				MenuBar.last_opened = MenuBar.open = menu;
				menu.open(menu_position);
				setSelected(node, menu);
			}
			addEventListeners(node, 'pointerdown touchmove', openMenu);
			// @ts-expect-error
			node.bbOpenMenu = openMenu;

			menu_button_nodes.push(node);
			bar.append(node);
			if (MenuBar.last_opened == menu || (!MenuBar.last_opened && id == 'file')) {
				setTimeout(() => {
					MenuBar.last_opened = menu;
					menu.open(menu_position);
					setSelected(node, menu);
				}, 1)
			}
		}
		document.body.append(bar);
		menu_position = {
			clientX: bar.offsetLeft + 7,
			clientY: bar.offsetTop + bar.clientHeight - 1
		}
		return bar;
	},
	/**
	 * Add a new menu to the menu bar
	 * @param menu The BarMenu to add
	 * @param position Specify the position in the menu list where to add insert the menu. Can either be an index in the list of all menus, or the ID of the menu to insert right from.
	 */
	addMenu(menu: BarMenu, position?: number | string): void {
		MenuBar.menus[menu.id] = menu;
		if (position) {
			let order = Object.keys(MenuBar.menus);
			order.remove(menu.id);
			let index = typeof position == 'number' ? position : order.indexOf(position)+1;
			order.splice(index, 0, menu.id);

			let menus = Object.assign({}, MenuBar.menus);
			order.forEach(id => delete MenuBar.menus[id]);
			order.forEach(id => MenuBar.menus[id] = menus[id]);
		}
		MenuBar.update();
	},
	/**
	 * Update the menu bar
	 */
	update(): void {
		if (!Blockbench.isMobile) {
			let bar = document.getElementById('menu_bar');
			bar.replaceChildren();
			this.keys = [];
			for (var menu in MenuBar.menus) {
				if (MenuBar.menus.hasOwnProperty(menu)) {
					if (MenuBar.menus[menu].conditionMet()) {
						bar.append(MenuBar.menus[menu].label)
						this.keys.push(menu);
					}
				}
			}
		}
	},
	/**
	 * Adds an action to the menu structure
	 * @param action Action to add
	 * @param path Path pointing to the location. Use the ID of each level of the menu, or index or group within a level, separated by a point. For example, `file.export.0` places the action at the top position of the Export submenu in the File menu.
	 */
	addAction(action: Action, path?: string): void {
		if (!path) return;
		let path_segments = path.split('.')
		var menu = MenuBar.menus[path_segments.splice(0, 1)[0]]
		if (menu) {
			menu.addAction(action, path_segments.join('.'))
		}
	},
	/**
	 *
	 * @param path Path pointing to the location. Use the ID of each level of the menu, or index or group within a level, or item ID, separated by a point. For example, `export.export_special_format` removes the action "Export Special Format" from the Export submenu.
	 */
	removeAction(path: string): void {
		if (!path) return;
		let path_segments = path.split('.')
		var menu = MenuBar.menus[path_segments.splice(0, 1)[0]]
		if (menu) {
			menu.removeAction(path_segments.join('.'))
		}
	}
}


const global = {
	BarMenu,
	MenuBar
}
declare global {
	type BarMenu = import('./menu_bar').BarMenu
	const BarMenu: typeof global.BarMenu
	const MenuBar: typeof global.MenuBar
}
Object.assign(window, global);
