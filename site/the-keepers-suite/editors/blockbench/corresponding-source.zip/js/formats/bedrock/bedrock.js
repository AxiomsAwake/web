import { findExistingFile } from "../../desktop";
import { CanvasFrame } from "../../lib/CanvasFrame";
import { currentwindow, dialog, fs } from "../../native_apis";
import VersionUtil from '../../util/version_util'
import {animation_codec} from "./bedrock_animation"
import "./animation_controller_codec"
import { loadBedrockCollisionFromJSON } from "./bedrock_voxel_shape";

if (isApp) {
window.BedrockEntityManager = class BedrockEntityManager {
	constructor(project) {
		this.project = project || Project;
		this.root_path = '';
	}
	checkEntityFile(path, content) {
		try {
			content ??= fs.readFileSync(path, 'utf-8');
			if (typeof content === 'string') {
				const data = autoParseJSON(content, false);
				let main = data && (data['minecraft:client_entity'] || data['minecraft:attachable']);
				if (main && main.description && typeof main.description.geometry == 'object') {
					for (var key in main.description.geometry) {
						var geoname = main.description.geometry[key];
						if (typeof geoname == 'string') {
							geoname = geoname.replace(/^geometry\./, '');
							if (geoname == this.project.geometry_name) {
								main.type = data['minecraft:attachable'] ? 'attachable' : 'client_entity';
								return main;
							}
						}
					}
				} 
			}
		} catch (err) {
			console.error(err);
			return false;
		}
	}
	getEntityFile(externalDataLoader) {
		let path = this.project.export_path.split(osfs);
		const name = path.pop().replace(/\.json$/, '').replace(/\.geo$/, '');

		if (externalDataLoader) {
			let entity_file = externalDataLoader({
				dir: "entity",
				filter: file => file.endsWith(".json") && file.includes(name),
				find: content => this.checkEntityFile(null, content),
				return: "find"
			});
			if (!entity_file) {
				entity_file = externalDataLoader({
					dir: "attachables",
					filter: file => file.endsWith(".json") && file.includes(name),
					find: content => this.checkEntityFile(null, content),
					return: "find"
				});
			}
			if (entity_file) {
				return entity_file
			}
		}

		var root_index = path.indexOf('models');
		path.splice(root_index);
		this.root_path = path.slice().join(osfs);

		if (BedrockEntityManager.CurrentContext?.entity_file_path) {
			let content = this.checkEntityFile(BedrockEntityManager.CurrentContext?.entity_file_path);
			if (content) {
				return content;
			}
		}

		path.push('entity');
		path = path.join(osfs);

		let base_directories = [path, path.replace(/entity$/, 'attachables')];
		if (Group.all.find(group => group.bedrock_binding)) {
			// probably an attachable
			base_directories.reverse();
		}
		return Blockbench.findFileFromContent(base_directories, {filter_regex: /\.json$/i, priority_regex: new RegExp(name, 'i'), read_file: false}, (path) => {
			return this.checkEntityFile(path);
		});
	}
	initEntity(args) {
		this.client_entity = this.getEntityFile(args?.externalDataLoader);
		if (this.client_entity && this.client_entity.description) {

			let render_mode;
			let {materials} = this.client_entity.description;
			if (materials) {
				let [key] = Object.keys(materials);
				if (typeof materials[key] == 'string') {
					if (materials[key].includes('emissive')) {
						render_mode = 'emissive'
					} else if (materials[key].includes('multitexture')) {
						render_mode = 'layered';
					}
				}
			}
			function updateLayeredTextures() {
				Texture.all.forEach((tex, i) => {
					tex.visible = i < 3
				})
				Interface.Panels.textures.inside_vue.$forceUpdate()
				Canvas.updateLayeredTextures();
			}

			// Textures
			var tex_list = this.client_entity.description.textures
			if (tex_list instanceof Object) {
				var valid_textures_list = [];
				for (var key in tex_list) {
					if (typeof tex_list[key] == 'string') {
						let added
						if (args?.externalDataLoader) {
							if (args.externalDataLoader(tex_list[key] + ".png")) {
								added = true
								valid_textures_list.safePush(tex_list[key] + ".png")
							} else if (args.externalDataLoader(tex_list[key] + ".tga")) {
								added = true
								valid_textures_list.safePush(tex_list[key] + ".tga")
							}
						}
						if (!added) {
							var path = this.root_path + osfs + tex_list[key].replace(/\//g, osfs);
							path = findExistingFile([
								path+'.png',
								path+'.tga'
							])
							if (path) {
								valid_textures_list.safePush(path);
							}
						}
					}
				}
				if (valid_textures_list.length == 1) {
					let texture = new Texture({keep_size: true, render_mode}).fromPath(valid_textures_list[0], args?.externalDataLoader).add()
					if (isApp) loadAdjacentTextureSet(texture);
					if (render_mode == 'layered') {
						updateLayeredTextures();
					}
					if (isApp) setTimeout(() => updateRecentProjectThumbnail(), 40);

				} else if (valid_textures_list.length > 1) {
					setTimeout(() => {this.project.whenNextOpen(() => {
						valid_textures_list = valid_textures_list.filter(entry => {
							return Texture.all.findIndex(t => t.path == entry) == -1;
						});
						if (!valid_textures_list.length) return;
						let selected_textures = [];
						var dialog = new Dialog({
							title: tl('data.texture'),
							id: 'select_texture',
							width: 704,
							component: {
								data() {return {
									valid_textures_list,
									selected_textures,
									search_term: '',
									backgrounds: {}
								}},
								methods: {
									getName(path) {
										return pathToName(path, true);
									},
									getBackground(path) {
										if (this.backgrounds[path]) return
										if (args?.externalDataLoader) {
											const external = args.externalDataLoader(path)
											if (typeof external === "string") {
												return `url("${external}}")`
											} else if (external instanceof Uint8Array) {
												// If the returned data is a Buffer, infer the data type and turn it into a data URL
												const u8 = new Uint8Array(external)
												let base64
												if (typeof Buffer !== "undefined" && external instanceof Buffer) {
													base64 = external.toString("base64")
												} else {
													base64 = btoa(String.fromCharCode(...u8))
												}
												if (pathToExtension(path) === 'tga') {
													let frame = new CanvasFrame().loadFromTGA(u8).then(() => {
														this.backgrounds[path] = `url("${frame.toDataURL()}")`
														this.$forceUpdate()
													});
												}
												let mime
												if (u8.slice(0, 4).toString() === [0x89, 0x50, 0x4E, 0x47].toString()) {
													mime = 'image/png'
												} else if (u8.slice(0, 3).toString() === [0xFF, 0xD8, 0xFF].toString()) {
													mime = 'image/jpeg'
												} else if (u8.slice(0, 4).toString() === [0x52, 0x49, 0x46, 0x46].toString() && u8.slice(8, 12).toString() === [0x57, 0x45, 0x42, 0x50].toString()) {
													mime = 'image/webp'
												}
												if (mime) {
													this.backgrounds[path] = `url("data:${mime};base64,${base64}")`
													return this.backgrounds[path]
												}
											}
										}
										if (pathToExtension(path) === 'tga') {
											console.log(path);
											this.backgrounds[path] = true;
											let data;
											if (isApp) {
												data = fs.readFileSync(path);
											} else {

											}
											let frame = new CanvasFrame();
											frame.loadFromTGA(data).then((a, b) => {
												this.backgrounds[path] = `url("${frame.canvas.toDataURL()}")`
												this.$forceUpdate()
											});
											return
										}
										return `url("${ path.replace(/\\/g, '/').replace(/#/g, '%23') }?1")`
									},
									clickTexture(texture) {
										if (selected_textures.includes(texture)) {
											selected_textures.remove(texture)
										} else {
											selected_textures.push(texture)
										}
									},
									dblclickTexture(texture) {
										selected_textures.replace([texture])
										dialog.confirm()
									}
								},
								computed: {
									textures() {
										if (!this.search_term) return this.valid_textures_list;
										let term = this.search_term.toLowerCase();
										return this.valid_textures_list.filter(path => {
											return path.toLowerCase().includes(term);
										});
									}
								},
								template: `
									<div>
										<search-bar style="float: none; height: 40px; margin-left: auto;" v-model="search_term" />
										<ul id="import_texture_list" class="y_scrollable">
											<li v-for="(texture, index) in textures"
												:title="getName(texture)" :arr_index="index"
												:class="{elevated: true, selected: selected_textures.includes(texture)}"
												:style="{backgroundImage: backgrounds[texture] ?? getBackground(texture)}"
												@click="clickTexture(texture)"
												@dblclick="dblclickTexture(texture)"
											>
												<label>{{ getName(texture) }}</label>
											</li>
										</ul>
									</div>
								`
							},
							buttons: ['dialog.import', 'dialog.select_texture.import_all', 'dialog.cancel'],
							confirmIndex: 0,
							cancelIndex: 2,
							onButton(index) {
								dialog.hide();
								let textures_to_import = [];
								if (index == 1) {
									textures_to_import = valid_textures_list;
								} else if (index == 0) {
									textures_to_import = selected_textures;
								}
								for (let path of textures_to_import) {
									let texture = new Texture({keep_size: true, render_mode}).fromPath(path, args?.externalDataLoader).add();
									if (isApp) loadAdjacentTextureSet(texture);
								}
								if (render_mode == 'layered') {
									updateLayeredTextures();
								}
								if (isApp) setTimeout(() => updateRecentProjectThumbnail(), 40);
							}
						}).show();
					})}, 2)
				}
			}

		} else {
			this.findEntityTexture(this.project.geometry_name, null, args?.externalDataLoader);
		}
		if (this.client_entity && this.client_entity.type == 'attachable' && Format.id == 'bedrock' && !args.import_to_current_project) {
			Project.bedrock_animation_mode = 'attachable_first';
			BarItems.bedrock_animation_mode.set(Project.bedrock_animation_mode);
		}
	}
	initAnimations() {
		this.initialized_animations = true;
		let anim_list = this.client_entity && this.client_entity.description && this.client_entity.description.animations;
		if (anim_list instanceof Object) {
			let animation_names = [];
			let has_animations = false, has_controllers = false;
			for (var key in anim_list) {
				if (typeof anim_list[key] !== 'string') continue;
				if (anim_list[key].startsWith('animation.')) {
					has_animations = true;
					animation_names.push(anim_list[key]);
				} else if (anim_list[key].startsWith('controller.animation.')) {
					has_controllers = true;
					animation_names.push(anim_list[key]);
				}
			}
			// get all paths in folder
			let anim_files = [];
			function searchFolder(path) {
				try {
					var files = fs.readdirSync(path);	
					for (var name of files) {
						var new_path = path + osfs + name;
						if (name.match(/\.json$/)) {
							anim_files.push(new_path);
						} else if (!name.includes('.')) {
							searchFolder(new_path);
						}
					}
				} catch (err) {}
			}
			if (has_animations) searchFolder(PathModule.join(this.root_path, 'animations'));
			if (has_controllers) searchFolder(PathModule.join(this.root_path, 'animation_controllers'));

			anim_files.forEach(path => {
				try {
					let content = fs.readFileSync(path, 'utf8');
					animation_codec.loadFile({path, content}, animation_names);
				} catch (err) {
					console.error(err)
				}
			})
		}
	}
	getParticleFile(short_name) {
		let particle_id = this.client_entity?.description?.particle_effects?.[short_name];
		if (!particle_id) return;
		let particle_dir = PathModule.join(this.root_path, 'particles');
		let no_namespace = particle_id.replace(/^.+:/, '');
		return Filesystem.findFileFromContent(
			[particle_dir],
			{
				filter_regex: /\.json$/i,
				priority_regex: new RegExp(no_namespace, 'i'),
				recursive: true,
				json: true,
				read_file: true,
			},
			(path, content) => {
				if (content?.particle_effect?.description?.identifier == particle_id) {
					return path;
				}
			}
		);
	}
	getSoundFile(short_name) {
		let sound_id = this.client_entity?.description?.sound_effects?.[short_name];
		if (!sound_id) return;
		let sound_dir = PathModule.join(this.root_path, 'sounds');
		try {
			let sound_file_content = fs.readFileSync(PathModule.join(sound_dir, 'sound_definitions.json'), 'utf-8');
			let content = autoParseJSON(sound_file_content, false);
			let entry = content.sound_definitions[sound_id];
			if (!entry?.sounds) return;
			let name = typeof entry.sounds[0] == 'string' ? entry.sounds[0] : entry.sounds[0].name;
			if (!name.match(/\.\w+$/)) name += '.ogg';
			return PathModule.join(sound_dir, '..', name);
		} catch (err) {
			console.error(err);
		}
	}
	findEntityTexture(mob, return_path, externalDataLoader) {
		if (!mob) return;
		var textures = {
			'llamaspit': 'llama/spit',
			'llama': 'llama/llama_creamy',
			'dragon': 'dragon/dragon',
			'ghast': 'ghast/ghast',
			'slime': 'slime/slime',
			'slime.armor': 'slime/slime',
			'lavaslime': 'slime/magmacube',
			'shulker': 'shulker/shulker_undyed',
			'rabbit': 'rabbit/brown',
			'horse': 'horse/horse_brown',
			'horse.v2': 'horse2/horse_brown',
			'humanoid': 'steve',
			'creeper': 'creeper/creeper',
			'enderman': 'enderman/enderman',
			'zombie': 'zombie/zombie',
			'zombie.husk': 'zombie/husk',
			'zombie.drowned': 'zombie/drowned',
			'pigzombie': 'pig/pigzombie',
			'pigzombie.baby': 'pig/pigzombie',
			'skeleton': 'skeleton/skeleton',
			'skeleton.wither': 'skeleton/wither_skeleton',
			'skeleton.stray': 'skeleton/stray',
			'spider': 'spider/spider',
			'cow': 'cow/cow',
			'mooshroom': 'cow/mooshroom',
			'sheep.sheared': 'sheep/sheep',
			'sheep': 'sheep/sheep',
			'pig': 'pig/pig',
			'irongolem': 'iron_golem',
			'snowgolem': 'snow_golem',
			'zombie.villager': 'zombie_villager/zombie_farmer',
			'evoker': 'illager/evoker',
			'vex': 'vex/vex',
			'wolf': 'wolf/wolf',
			'ocelot': 'cat/ocelot',
			'cat': 'cat/siamese',
			'turtle': 'sea_turtle',
			'villager': 'villager/farmer',
			'villager.witch': 'witch',
			'witherBoss': 'wither_boss/wither',
			'parrot': 'parrot/parrot_red_blue',
			'bed': 'bed/white',
			'player_head': 'steve',
			'mob_head': 'skeleton/skeleton',
			'dragon_head': 'dragon/dragon',
			'boat': 'boat/boat_oak',
			'cod': 'fish/fish',
			'pufferfish.small': 'fish/pufferfish',
			'pufferfish.mid': 'fish/pufferfish',
			'pufferfish.large': 'fish/pufferfish',
			'salmon': 'fish/salmon',
			'tropicalfish_a': 'fish/tropical_a',
			'tropicalfish_b': 'fish/tropical_b',
			'panda': 'panda/panda',
			'fishing_hook': 'fishhook',
			'ravager': 'illager/ravager',
			'bee': 'bee/bee',
			'fox': 'fox/fox',
			'shield': 'shield',
			'shulker_bullet': 'shulker/spark',
		}
		mob = mob.split(':')[0].replace(/^geometry\./, '')
		var path = textures[mob]
		if (!path) {
			path = mob
		}
		if (path) {
			var texture_path = this.project.export_path.split(osfs)
			var index = texture_path.lastIndexOf('models') - texture_path.length
			texture_path.splice(index)
			texture_path = [...texture_path, 'textures', 'entity', ...path.split('/')].join(osfs)

			if (return_path === true) {
				return texture_path+'.png';
			} else if (return_path === 'raw') {
				return ['entity', ...path.split('/')].join(osfs)
			} else {
				function tryItWith(extension, skip_external) {
					let texture;
					if (!skip_external && externalDataLoader?.(`textures/entity/${path}.${extension}`)) {
						texture = new Texture({keep_size: true}).fromPath(`textures/entity/${path}.${extension}`, externalDataLoader).add();
					}
					if (!texture && fs.existsSync(texture_path+'.'+extension)) {
						texture = new Texture({keep_size: true}).fromPath(texture_path+'.'+extension).add();
					}
					if (texture) {
						loadAdjacentTextureSet(texture);
						return true;
					}
				}
				if (!tryItWith('png') && !tryItWith('tga')) {
					if (settings.default_path && settings.default_path.value) {
						
						texture_path = settings.default_path.value + osfs + 'entity' + osfs + path.split('/').join(osfs)
						tryItWith('png', true) || tryItWith('tga', true)
					}
				}
			}
		}
	}
}
window.BedrockBlockManager = class BedrockBlockManager {
	constructor(project) {
		this.project = project || Project;
		this.root_path = '';
	}
	checkBlockFile(path) {
		try {
			var c = fs.readFileSync(path, 'utf-8');
			if (typeof c === 'string') {
				c = autoParseJSON(c, false);
				let main = c && c['minecraft:block'];
				if (!main || !main.components) return;

				let isThisGeo = (geo_component) => {
					if (typeof geo_component == 'object') {
						return isThisGeo(geo_component.identifier);
					}
					return typeof geo_component == 'string' && geo_component.replace(/^geometry\./, '') == this.project.geometry_name;
				}
				if (isThisGeo(main.components['minecraft:geometry'])) {
					main.type = 'block';
					return main;
				}
				if (main.permutations instanceof Array) {
					for (let permutation of main.permutations) {
						if (permutation.components && isThisGeo(permutation.components['minecraft:geometry'])) {
							main.type = 'block';
							return main;
						}
					}
				}
			}
		} catch (err) {
			console.error(err);
			return false;
		}
	}
	getBlockFile() {
		var path = this.project.export_path.split(osfs);
		var name = path.pop().replace(/\.json$/, '').replace(/\.geo$/, '');
		let rp_dir = path.find(dir => (dir == 'resource_packs' || dir == 'development_resource_packs'));
		var root_index = path.indexOf(rp_dir);
		
		let rp_manifest_path = [...path.slice(0, root_index+2), 'manifest.json'].join(osfs);
		let rp_uuid;
		try {
			let rp_manifest_content = autoParseJSON(fs.readFileSync(rp_manifest_path, 'utf-8'), false);
			rp_uuid = rp_manifest_content.header.uuid;
		} catch (err) {}
		if (!rp_uuid) return;

		path.splice(root_index);
		path.push(rp_dir.match(/development/) ? 'development_behavior_packs' : 'behavior_packs');
		let behavior_packs = fs.readdirSync(path.join(osfs), {withFileTypes: true});
		let bp_name;
		for (let dirent of behavior_packs) {
			if (dirent.isDirectory()) {
				try {
					let bp_manifest_path = [...path, dirent.name, 'manifest.json'].join(osfs);
					let bp_manifest_content = autoParseJSON(fs.readFileSync(bp_manifest_path, 'utf-8'), false);
					if (bp_manifest_content && bp_manifest_content.dependencies instanceof Array) {
						let matching_dependency = bp_manifest_content.dependencies.find(dep => dep.uuid == rp_uuid);
						if (matching_dependency) {
							bp_name = dirent.name;
							break;
						}
					}
				} catch (err) {}
			}
		}
		if (!bp_name) return;

		path.push(bp_name, 'blocks')
		path = path.join(osfs);
		var block_path = findExistingFile([
			path+osfs+name+'.block.json',
			path+osfs+name+'.json',
		])
		if (block_path) {
			var content = this.checkBlockFile(block_path);
			if (content) {
				return content;
			}
		} else {
			return Blockbench.findFileFromContent([path], {filter_regex: /\.json$/i, priority_regex: new RegExp(name, 'i'), read_file: false}, (path) => {
				return this.checkBlockFile(path);
			});
		}
	}
	initBlock() {
		this.rp_root_path = this.project.export_path.replace(/[\\/]models[\\/]blocks[\\/].+/, '');
		try {
			this.client_block = this.getBlockFile();
		} catch (err) {
			console.error(err);
		}
		if (this.client_block && this.client_block.components && this.client_block.components['minecraft:material_instances']) {

			let terrain_texture;
			try {
				let terrain_tex_path = this.rp_root_path + osfs + 'textures' + osfs + 'terrain_texture.json';
				let terrain_tex_content = autoParseJSON(fs.readFileSync(terrain_tex_path, 'utf-8'), false);
				terrain_texture = terrain_tex_content.texture_data;
			} catch (err) {
				console.error(err)
			}

			let materials = this.client_block.components['minecraft:material_instances'];
			for (let target in materials) {
				let material = materials[target];
				let texture_path = `textures/blocks/${material.texture || this.project.geometry_name}`;
				if (terrain_texture) {
					let texture_data = terrain_texture[material.texture];
					if (typeof texture_data?.textures == 'string') {
						texture_path = texture_data.textures;
					}
				}
				let full_texture_path = PathModule.join(this.rp_root_path + osfs + texture_path.replace(/\.png$/i, ''));
				full_texture_path = findExistingFile([
					full_texture_path+'.png',
					full_texture_path+'.tga'
				])
				if (full_texture_path) {
					let texture = new Texture({keep_size: true}).fromPath(full_texture_path).add();
					if (isApp) loadAdjacentTextureSet(texture);
					if (target == '*') {
						texture.use_as_default = true;

					} else {
						let target_regex = new RegExp('^' + target.replace(/\*/g, '.*') + '$');
						Cube.all.forEach(cube => {
							for (let fkey in cube.faces) {
								let face = cube.faces[fkey];
								if (face.texture === null) continue;
								if (face.material_name && face.material_name.match(target_regex)) {
									face.texture = texture.uuid;
								}
							}
						})
					}

				}
			}
			Canvas.updateView({elements: Cube.all, element_aspects: {faces: true}})
			UVEditor.loadData()
		}
		if (this.client_block?.components) {
			let boxes = {
				collision: this.client_block?.components["minecraft:collision_box"],
				selection: this.client_block?.components["minecraft:selection_box"],
			}
			for (let key in boxes) {
				try {
					loadBedrockCollisionFromJSON(boxes[key], key, false);
				} catch (err) {
					console.error(err);
				}
			}
		}
	}
}
}

export function calculateVisibleBox() {
	var visible_box = new THREE.Box3()
	Canvas.withoutGizmos(() => {
		Cube.all.forEach(cube => {
			if (cube.export && cube.mesh) {
				visible_box.expandByObject(cube.mesh);
			}
		})
	})

	var offset = new THREE.Vector3(8,8,8);
	visible_box.max.add(offset);
	visible_box.min.add(offset);

	// Width
	var radius = Math.max(
		visible_box.max.x,
		visible_box.max.z,
		-visible_box.min.x,
		-visible_box.min.z
	)
	if (Math.abs(radius) === Infinity) {
		radius = 0
	}
	let width = Math.ceil((radius*2) / 16)
	width = Math.max(width, Project.visible_box[0]);
	Project.visible_box[0] = width;

	//Height
	let y_min = Math.floor(visible_box.min.y / 16);
	let y_max = Math.ceil(visible_box.max.y / 16);
	if (y_min === Infinity) y_min = 0;
	if (y_max === Infinity) y_max = 0;
	y_min = Math.min(y_min, Project.visible_box[2] - Project.visible_box[1]/2);
	y_max = Math.max(y_max, Project.visible_box[2] + Project.visible_box[1]/2);

	Project.visible_box.replace([width, y_max-y_min, (y_max+y_min) / 2])

	return Project.visible_box;
}
window.calculateVisibleBox = calculateVisibleBox;


// Parse

	function parseCube(s, group, bone_data) {
		var base_cube = new Cube({
			name: s.name || group.name,
			autouv: 0,
			color: group.color,
			rotation: s.rotation,
			origin: s.pivot
		})
		base_cube.rotation.forEach(function(br, axis) {
			if (axis != 2) base_cube.rotation[axis] *= -1
		})
		base_cube.origin[0] *= -1;
		if (s.origin) {
			base_cube.from.V3_set(s.origin)
			base_cube.from[0] = -(base_cube.from[0] + s.size[0])
			if (s.size) {
				base_cube.to[0] = s.size[0] + base_cube.from[0]
				base_cube.to[1] = s.size[1] + base_cube.from[1]
				base_cube.to[2] = s.size[2] + base_cube.from[2]
			}
		}
		if (s.uv instanceof Array) {
			base_cube.uv_offset[0] = s.uv[0]
			base_cube.uv_offset[1] = s.uv[1]
			base_cube.box_uv = true;
		} else if (s.uv) {
			base_cube.box_uv = false;
			for (var key in base_cube.faces) {
				var face = base_cube.faces[key]
				if (s.uv[key]) {
					face.extend({
						material_name: s.uv[key].material_instance,
						uv: [
							s.uv[key].uv[0],
							s.uv[key].uv[1]
						],
						rotation: s.uv[key].uv_rotation
					})
					if (s.uv[key].uv_size) {
						face.uv_size = [
							s.uv[key].uv_size[0],
							s.uv[key].uv_size[1]
						]
					} else {
						base_cube.autouv = 1;
						base_cube.mapAutoUV();
					}
					if (key == 'up' || key == 'down') {
						face.uv = [face.uv[2], face.uv[3], face.uv[0], face.uv[1]]
					}
				} else {
					face.texture = null;
					face.uv = [0, 0, 0, 0],
					face.rotation = 0;
				}
			}
			
		}
		let inflate = s.inflate ?? bone_data?.inflate
		if (typeof inflate === 'number') {
			base_cube.inflate = inflate;
		}
		if (s.mirror === undefined) {
			base_cube.mirror_uv = group.mirror_uv;
		} else {
			base_cube.mirror_uv = s.mirror === true;
		}
		base_cube.addTo(group).init();
		return base_cube;
	}
	function parseBone(b, bones, parent_list) {
		var group = new Group({
			name: b.name,
			origin: b.pivot,
			rotation: b.rotation,
			material: b.material,
			bedrock_binding: b.binding,
			color: Group.all.length%markerColors.length
		}).init()
		group.createUniqueName();
		bones[b.name.toLowerCase()] = group
		if (b.pivot) {
			group.origin[0] *= -1
		}
		group.rotation.forEach(function(br, axis) {
			if (axis !== 2) group.rotation[axis] *= -1
		})
		
		group.mirror_uv = b.mirror === true
		group.reset = b.reset === true

		if (b.cubes) {
			b.cubes.forEach(function(s) {
				parseCube(s, group, b)
			})
		}
		if (b.locators) {
			for (let key in b.locators) {
				let coords, rotation, ignore_inherited_scale;
				if (b.locators[key] instanceof Array) {
					coords = b.locators[key];
				} else {
					coords = b.locators[key].offset;
					rotation = b.locators[key].rotation;
					ignore_inherited_scale = b.locators[key].ignore_inherited_scale;
				}
				coords[0] *= -1;
				if (rotation instanceof Array) {
					rotation[0] *= -1;
					rotation[1] *= -1;
				}
				if (key.substr(0, 6) == '_null_' && b.locators[key] instanceof Array) {
					new NullObject({from: coords, name: key.substr(6)}).addTo(group).init();
				} else {
					new Locator({position: coords, name: key, rotation, ignore_inherited_scale}).addTo(group).init();
				}
			}
		}
		if (b.texture_meshes instanceof Array) {
			b.texture_meshes.forEach(tm => {
				let texture = Texture.all.find(tex => tex.name == tm.texture);
				let texture_mesh = new TextureMesh({
					texture_name: tm.texture,
					texture: texture ? texture.uuid : null,
					origin: tm.position,
					rotation: tm.rotation,
					local_pivot: tm.local_pivot,
					scale: tm.scale,
				})
				texture_mesh.local_pivot[2] *= -1;
				texture_mesh.origin[1] *= -1;

				if (b.pivot) texture_mesh.origin[1] += b.pivot[1];

				texture_mesh.origin[0] *= -1;
				texture_mesh.rotation[0] *= -1;
				texture_mesh.rotation[1] *= -1;
				texture_mesh.addTo(group).init();
			})
		}
		if (b.children) {
			b.children.forEach(function(cg) {
				cg.addTo(group);
			})
		}
		var parent_group = 'root';
		if (b.parent) {
			let match = bones[b.parent.toLowerCase()];
			if (match) {
				parent_group = match;
			} else {
				parent_list.forEach(function(ib) {
					if (ib.name.toLowerCase() === b.parent.toLowerCase()) {
						ib.children && ib.children.length ? ib.children.push(group) : ib.children = [group]
					}
				})
			}
		}
		group.addTo(parent_group)
	}
	export function parseGeometry(data, args = {}) {

		let {description} = data.object;
		let geometry_name = (description.identifier && description.identifier.replace(/^geometry\./, '')) || '';

		if (args.switch_to_existing_tab != false) {
			let existing_tab = isApp && ModelProject.all.find(project => (
				Project !== project && project.export_path == Project.export_path && project.geometry_name == geometry_name
			))
			if (existing_tab) {
				Project.close().then(() =>  {
					existing_tab.select();
				});
				return;
			}
		}

		codec.dispatchEvent('parse', {model: data.object});

		if (!args.import_to_current_project) {
			Project.model_identifier = geometry_name;
			Project.texture_width = 16;
			Project.texture_height = 16;
		} else if (args.collection) {
			args.collection.model_identifier = geometry_name;
		}

		if (typeof description.visible_bounds_width == 'number' && typeof description.visible_bounds_height == 'number') {
			Project.visible_box[0] = Math.max(Project.visible_box[0], description.visible_bounds_width || 0);
			Project.visible_box[1] = Math.max(Project.visible_box[1], description.visible_bounds_height || 0);
			if (description.visible_bounds_offset && typeof description.visible_bounds_offset[1] == 'number') {
				Project.visible_box[2] = description.visible_bounds_offset[1] || 0;
			}
		}

		if (description.texture_width !== undefined) {
			Project.texture_width = description.texture_width;
		}
		if (description.texture_height !== undefined) {
			Project.texture_height = description.texture_height;
		}

		if (data.object.item_display_transforms !== undefined) {
			DisplayMode.loadJSON(data.object.item_display_transforms, DisplayMode.bedrock_defaults)
		}

		var bones = {}

		if (data.object.bones) {
			var included_bones = []
			data.object.bones.forEach(function(b) {
				included_bones.push(b.name)
			})
			data.object.bones.forEach(function(b) {
				parseBone(b, bones, data.object.bones)
			})
		}

		Project.box_uv = Cube.all.filter(cube => cube.box_uv).length > Cube.all.length/2;

		codec.dispatchEvent('parsed', {model: data.object});

		Canvas.updateAllBones()
		setProjectTitle()
		if (isApp && Project.geometry_name) {
			if (Format.id == 'bedrock') Project.BedrockEntityManager.initEntity(args);
			if (Format.id == 'bedrock_block') Project.BedrockBlockManager.initBlock();
		}
		Validator.validate()
		updateSelection()
	}

// Compile

	function compileCube(cube, bone) {
		var template = {
			origin: cube.from.slice(),
			size: cube.size(),
			inflate: cube.inflate||undefined,
		}
		if (cube.box_uv) {
			template = new oneLiner(template);
		}
		template.origin[0] = -(template.origin[0] + template.size[0])

		if (!cube.rotation.allEqual(0)) {
			template.pivot = cube.origin.slice();
			template.pivot[0] *= -1;
			
			template.rotation = cube.rotation.slice();
			template.rotation.forEach(function(br, axis) {
				if (axis != 2) template.rotation[axis] *= -1
			})
		}

		if (cube.box_uv) {
			template.uv = cube.uv_offset;
			if (cube.mirror_uv === !bone.mirror) {
				template.mirror = cube.mirror_uv
			}
		} else {
			template.uv = {};
			for (var key in cube.faces) {
				var face = cube.faces[key];
				if (face.texture !== null) {
					template.uv[key] = new oneLiner({
						uv: [
							face.uv[0],
							face.uv[1],
						],
						uv_size: [
							face.uv_size[0],
							face.uv_size[1],
						]
					});
					if (face.rotation) {
						template.uv[key].uv_rotation = face.rotation;
					}
					if (face.material_name) {
						template.uv[key].material_instance = face.material_name;
					}
					if (key == 'up' || key == 'down') {
						template.uv[key].uv[0] += template.uv[key].uv_size[0];
						template.uv[key].uv[1] += template.uv[key].uv_size[1];
						template.uv[key].uv_size[0] *= -1;
						template.uv[key].uv_size[1] *= -1;
					}
				}
			}
		}
		return template;
	}
	function compileGroup(g) {
		if (g.type !== 'group') return;
		if (g.export == false) {
			function hasChildrenToExport(node) {
				for (let child of node.children) {
					if (child.export == true) return true;
					if ("children" in child) {
						let result = hasChildrenToExport(child);
						if (result) return true;
					}
				}
			}
			if (!hasChildrenToExport(g)) return false;
		}
		if (!settings.export_empty_groups.value && !g.children.find(child => child.export)) return;
		if (g.children.length && g.children.allAre(c => c instanceof BoundingBox)) return;
		//Bone
		var bone = {}
		bone.name = g.name
		if (g.parent.type === 'group') {
			bone.parent = g.parent.name
		}
		bone.pivot = g.origin.slice()
		bone.pivot[0] *= -1
		if (!g.rotation.allEqual(0)) {
			bone.rotation = g.rotation.slice()
			bone.rotation[0] *= -1;
			bone.rotation[1] *= -1;
		}
		if (g.bedrock_binding) {
			bone.binding = g.bedrock_binding
		}
		if (g.reset) {
			bone.reset = true
		}
		if (g.mirror_uv && Project.box_uv) {
			bone.mirror = true
		}
		if (g.material) {
			bone.material = g.material
		}
		// Elements
		var cubes = []
		var locators = {};
		var texture_meshes = [];

		for (var obj of g.children) {
			if (obj.export) {
				if (obj instanceof Cube) {

					let template = compileCube(obj, bone);
					cubes.push(template);

				} else if (obj instanceof Locator || obj instanceof NullObject) {
					let key = obj.name;
					if (obj instanceof NullObject) key = '_null_' + key;
					let offset = obj.position.slice();
					offset[0] *= -1;

					if ((obj.getTypeBehavior('rotatable') && !obj.rotation.allEqual(0)) || obj.ignore_inherited_scale) {
						locators[key] = {
							offset
						};
						if (obj.getTypeBehavior('rotatable')) {
							locators[key].rotation = [
								-obj.rotation[0],
								-obj.rotation[1],
								obj.rotation[2]
							]
						}
						if (obj.ignore_inherited_scale) {
							locators[key].ignore_inherited_scale = true;
						}
					} else {
						locators[key] = offset;
					}
				} else if (obj instanceof TextureMesh) {
					let texmesh = {
						texture: obj.texture_name,
						position: obj.origin.slice(),
					}
					texmesh.position[0] *= -1;
					texmesh.position[1] -= bone.pivot[1];
					texmesh.position[1] *= -1;

					if (!obj.rotation.allEqual(0)) {
						texmesh.rotation = [
							-obj.rotation[0],
							-obj.rotation[1],
							obj.rotation[2]
						]
					}
					if (!obj.local_pivot.allEqual(0)) {
						texmesh.local_pivot = obj.local_pivot.slice();
						texmesh.local_pivot[2] *= -1;
					}
					if (!obj.scale.allEqual(1)) {
						texmesh.scale = obj.scale.slice();
					}
					texture_meshes.push(texmesh);
				}
			}
		}

		if (cubes.length) {
			bone.cubes = cubes
		}
		if (texture_meshes.length) {
			bone.texture_meshes = texture_meshes
		}
		if (Object.keys(locators).length) {
			bone.locators = locators
		}
		return bone;
	}

let entity_file_codec = new Codec('bedrock_entity_file', {
	name: 'Bedrock Entity',
	extension: 'json',
	remember: false,
	support_partial_export: true,
	support_offset: true,
	load_filter: {
		type: 'json',
		extensions: ['json'],
		condition(model) {
			return model.format_version && (model['minecraft:client_entity'] || model['minecraft:attachable'])
		}
	},
	load(content, file, add) {
		let is_attachable = content['minecraft:attachable'] !== undefined;
		let description = (content['minecraft:client_entity'] || content['minecraft:attachable']).description;
		let models = [];
		for (let key in description.geometry) {
			let model_id = description.geometry[key];
			models.push(model_id);
		}
		if (!models[0]) return;

		let path = file.path.split(osfs);
		let name = path.pop().replace(/(\.entity|\.attachable)?\.json$/, '');
		let root_index = path.indexOf(is_attachable ? 'attachables' : 'entity');
		path.splice(root_index);

		let [matched_geo_path, matched_geo_content] = Blockbench.findFileFromContent([
			[...path, 'models', 'entity'].join(osfs),
			[...path, 'models', 'blocks'].join(osfs),
		], {filter_regex: /\.json$/i, priority_regex: new RegExp(name, 'i'), json: true}, (path, content) => {

			if (content['minecraft:geometry'] instanceof Array) {
				let geo = content['minecraft:geometry'].find(geo => {
					return geo.description?.identifier == models[0];
				})
				if (geo) return [path, content];
			} else if (content[models[0]]) {
				return [path, content];
			}
		}) || [];

		if (matched_geo_path) {
			BedrockEntityManager.CurrentContext = {
				geometry: models[0],
				entity_file_path: file.path,
				type: 'entity'
			};
			let codec = matched_geo_content['minecraft:geometry'] ? Codecs.bedrock : Codecs.bedrock_old;
			codec.load(matched_geo_content, {path: matched_geo_path}, false);
			delete BedrockEntityManager.CurrentContext;
		}

		/*let entity_path = findExistingFile([
			[...path, 'models', 'entity', name+'.geo.json'].join(osfs),
			[...path, 'models', 'entity', name+'.json'].join(osfs),
			[...path, 'models', 'block', name+'.geo.json'].join(osfs),
			[...path, 'models', 'block', name+'.json'].join(osfs),
		])

		let matched_geo_path, matched_geo_content;
		function checkGeoFile(geo_path) {
			try {
				var c = fs.readFileSync(geo_path, 'utf-8');
				if (typeof c === 'string') {
					c = autoParseJSON(c, false);
					matched_geo_content = c;

					if (c['minecraft:geometry'] instanceof Array) {
						let geo = c['minecraft:geometry'].find(geo => {
							return geo.description?.identifier == models[0];
						})
						if (geo) return geo;
					} else if (c[models[0]]) {
						return c[models[0]];
					}
				}
			} catch (err) {
				console.error(err);
				return false;
			}
		}
		if (entity_path) {
			if (checkGeoFile(entity_path)) {
				matched_geo_path = entity_path;
			}
		}
		if (!matched_geo_path) {

			let searchFolder = (path) => {
				try {
					let files = fs.readdirSync(path);
					for (let name of files) {
						let new_path = path + osfs + name;
						if (name.match(/\.json$/)) {
							let result = checkGeoFile(new_path);
							if (result) return new_path;
						} else if (!name.includes('.')) {
							let result = searchFolder(new_path);
							if (result) return result;
						}
					}
				} catch (err) {
					console.error(err)
				}
			}
			matched_geo_path = searchFolder([...path, 'models', 'entity'].join(osfs)) || searchFolder([...path, 'models', 'block'].join(osfs));
		}

		if (matched_geo_path) {
			BedrockEntityManager.CurrentContext = {
				geometry: models[0],
				entity_file_path: file.path,
				type: 'entity'
			};
			let codec = matched_geo_content['minecraft:geometry'] ? Codecs.bedrock : Codecs.bedrock_old;
			codec.load(matched_geo_content, {path: matched_geo_path}, false);
			delete BedrockEntityManager.CurrentContext;
		}*/
	},
})

function getFormatVersion() {
	if (Format.display_mode) {
		for (let i in DisplayMode.slots) {
			let key = DisplayMode.slots[i]
			if (Project.display_settings[key] && Project.display_settings[key].export) {
				let data = Project.display_settings[key].export();
				if (data) {
					return '1.21.110';
				}
			}
		}
	}
	for (let cube of Cube.all) {
		if (cube.box_uv) continue;
		for (let fkey in cube.faces) {
			if (cube.faces[fkey].rotation) return '1.21.0';
		}
	}
	if (Group.all.find(group => group.bedrock_binding)) return '1.16.0';
	return '1.12.0';
}

function applyOffset(bones, offset) {
	for (let bone of bones) {
		if (bone.pivot) bone.pivot.V3_add(offset);
		for (let cube of (bone.cubes ?? [])) {
			cube.origin.V3_add(offset);
			cube.pivot?.V3_add(offset);
		}
		if (typeof bone.locators == 'object') {
			for (let id in bone.locators) {
				let locator = bone.locators[id];
				if (locator instanceof Array) {
					locator.V3_add(offset);
				} else if (locator.offset) {
					locator.offset.V3_add(offset);
				}
			}
		}
	}
}

var codec = new Codec('bedrock', {
	name: 'Bedrock Model',
	extension: 'json',
	remember: true,
	multiple_per_file: true,
	support_partial_export: true,
	support_offset: true,
	load_filter: {
		type: 'json',
		extensions: ['json'],
		condition(model) {
			return model['minecraft:geometry'] && model.format_version && VersionUtil.compare(model.format_version, '>=', '1.12.0');
		}
	},
	load(model, file, args = {}) {
		let is_block = Settings.get('default_bedrock_format') == 'block';
		if (file.path) {
			if (file.path.match(/[\\/]models[\\/]blocks[\\/]/)) {
				is_block = true;
			} else if (file.path.match(/[\\/]models[\\/]entity[\\/]/)) {
				is_block = false;
			}
		}
		if (model['minecraft:geometry']?.[0]?.item_display_transforms) {
			is_block = true;
		}
		if (isApp && BedrockEntityManager.CurrentContext?.type == 'entity') {
			is_block = false;
		}
		
		const import_to_current_project = typeof args === "boolean" ? args : args.import_to_current_project;

		if (!import_to_current_project) {
			setupProject(is_block ? block_format : entity_format);
		}

		if (file.path && isApp && this.remember && !file.no_file ) {
			var name = pathToName(file.path, true);
			Project.name = pathToName(name, false);
			Project.export_path = file.path;
			Project.export_codec = 'bedrock';
		}

		this.parse(model, file.path, args)

		if (file.path && isApp && this.remember && !file.no_file ) {
			if (isApp) {
				let no_textures_before = Texture.all.length == 0;
				loadDataFromModelMemory();
				if (!Format.single_texture && no_textures_before && Texture.all.length) {
					Cube.all.forEach(cube => {
						cube.applyTexture(Texture.all[0], true);
					})
				}
			}
			addRecentProject({
				name,
				path: file.path,
				icon: Format.icon
			});
			let project = Project;
			setTimeout(() => {
				if (Project == project) setTimeout(() => updateRecentProjectThumbnail(), 40);
			}, 200)
		}
	},
	compile(options) {
		if (options === undefined) options = {}

		var entitymodel = {}
		var main_tag = {
			format_version: getFormatVersion(),
			'minecraft:geometry': [entitymodel]
		}
		entitymodel.description = {
			identifier: 'geometry.' + (this.context?.model_identifier || Project.geometry_name || 'unknown'),
			texture_width:  Project.texture_width || 16,
			texture_height: Project.texture_height || 16,
		}

		if (options.collection) {

		}

		var bones = []

		var groups = getAllGroups();
		var loose_elements = [];
		Outliner.root.forEach(obj => {
			if (obj instanceof OutlinerElement) {
				loose_elements.push(obj)
			}
		})
		if (loose_elements.length) {
			let group = new Group({
				name: 'bb_main'
			});
			group.children.push(...loose_elements);
			group.createUniqueName();
			groups.splice(0, 0, group);
		}
		groups.forEach((group) => {
			let bone = compileGroup(group);
			if (bone) bones.push(bone)
		})

		if (bones.length && options.visible_box !== false) {

			let visible_box = calculateVisibleBox();
			entitymodel.description.visible_bounds_width = visible_box[0] || 0;
			entitymodel.description.visible_bounds_height = visible_box[1] || 0;
			entitymodel.description.visible_bounds_offset = [0, visible_box[2] || 0 , 0]
		}
		if (bones.length) {
			entitymodel.bones = bones
		}
		let offset = options.offset || this.context?.offset;
		if (offset instanceof Array && offset.allEqual(0) == false) {
			applyOffset(bones, offset.slice().V3_multiply(1, -1, -1));
		}

		let new_display = {};
		for (let i in DisplayMode.slots) {
			let key = DisplayMode.slots[i]
			if (Project.display_settings[key] && Project.display_settings[key].exportBedrock) {
				let data = Project.display_settings[key].exportBedrock();
				if (data) new_display[key] = data;
			}
		}
		if (Object.keys(new_display).length) {
			entitymodel.item_display_transforms = new_display
		}

		this.dispatchEvent('compile', {model: main_tag, options});

		if (options.raw) {
			return main_tag
		} else {
			return autoStringify(main_tag)
		}
	},
	overwrite(content, path, cb) {
		var data, index;
		var model_id = 'geometry.'+(this.context?.model_identifier || Project.geometry_name || 'unknown');
		try {
			data = fs.readFileSync(path, 'utf-8');
			data = autoParseJSON(data, false);
			if (data['minecraft:geometry'] instanceof Array == false) {
				throw 'Incompatible format';
			}
			var i = 0;
			for (let model of data['minecraft:geometry']) {
				if (model.description && model.description.identifier == model_id) {
					index = i;
					break;
				}
				i++;
			}
		} catch (err) {
			var answer = dialog.showMessageBox(currentwindow, {
				type: 'warning',
				buttons: [
					tl('message.bedrock_overwrite_error.overwrite'),
					tl('dialog.cancel')
				],
				title: 'Blockbench',
				message: tl('message.bedrock_overwrite_error.message'),
				detail: err+'',
				noLink: false
			})
			if (answer === 1) {
				return;
			}
		}
		if (data && index !== undefined) {

			if (!data.format_version || VersionUtil.compare(getFormatVersion(), '>', data.format_version)) {
				data.format_version = getFormatVersion();
			}

			data['minecraft:geometry'].forEach(geo => {
				if (geo.bones instanceof Array) {
					geo.bones.forEach(bone => {
						if (bone.cubes instanceof Array) {
							bone.cubes.forEach((cube, ci) => {
								if (cube.uv instanceof Array) {
									bone.cubes[ci] = new oneLiner(cube);
								}
							})
						}
					})
				}
			})

			var model = this.compile({raw: true})['minecraft:geometry'][0]
			if (index != undefined) {
				data['minecraft:geometry'][index] = model
			} else {
				data['minecraft:geometry'].push(model)
			}
			content = autoStringify(data)
		}
		Blockbench.writeFile(path, {content}, cb);
	},
	parse(data, path, args = {}) {
		if (Format != Formats.bedrock && Format != Formats.bedrock_block) Formats.bedrock.select()

		let geometries = [];
		for (let geo of data['minecraft:geometry']) {
			if (typeof geo !== 'object') continue;
			geometries.push({
				object: geo,
				name: geo.description?.identifier || ''
			});
		}
		if (geometries.length === 1) {
			return parseGeometry(geometries[0], args);
		} else if (isApp && BedrockEntityManager.CurrentContext?.geometry) {
			return parseGeometry(geometries.find(geo => geo.name == BedrockEntityManager.CurrentContext.geometry), args);
		}

		geometries.forEach(geo => {
			geo.uuid = guid();

			geo.bonecount = 0;
			geo.cubecount = 0;
			if (geo.object.bones instanceof Array) {
				geo.object.bones.forEach(bone => {
					geo.bonecount++;
					if (bone.cubes instanceof Array) geo.cubecount += bone.cubes.length;
				})
			}
		})

		let selected = null;
		new Dialog({
			id: 'bedrock_model_select',
			title: 'dialog.select_model.title',
			buttons: ['Import', 'dialog.cancel'],
			component: {
				data() {return {
					search_term: '',
					geometries,
					selected: null,
				}},
				computed: {
					filtered_geometries() {
						if (!this.search_term) return this.geometries;
						let term = this.search_term.toLowerCase();
						return this.geometries.filter(geo => {
							return geo.name.toLowerCase().includes(term)
						})
					}
				},
				methods: {
					selectGeometry(geo) {
						this.selected = selected = geo;
					},
					open(geo) {
						Dialog.open.hide();
						parseGeometry(geo, args);
					},
					tl
				},
				template: `
					<div>
						<search-bar v-model="search_term"></search-bar>
						<ul class="list" id="model_select_list">
							<li v-for="geometry in filtered_geometries" :key="geometry.uuid" :class="{selected: geometry == selected}" @click="selectGeometry(geometry)" @dblclick="open(geometry)">
								<p>{{ geometry.name }}</p>
								<label>{{ geometry.bonecount+' ${tl('dialog.select_model.bones')}' }}, {{ geometry.cubecount+' ${tl('dialog.select_model.cubes')}' }}</label>
							</li>
						</ul>
					</div>
				`
			},
			onConfirm() {
				parseGeometry(selected, args);
			}
		}).show();
	},
	fileName() {
		var name = Project.name||'model';
		if (!name.match(/\.geo$/)) {
			name += '.geo';
		}
		return name;
	}
})

codec.parseCube = parseCube;
codec.parseBone = parseBone;
codec.parseGeometry = parseGeometry;
codec.compileCube = compileCube;
codec.compileGroup = compileGroup;


var entity_format = new ModelFormat({
	id: 'bedrock',
	extension: 'json',
	icon: 'icon-format_bedrock',
	category: 'minecraft',
	target: 'Minecraft: Bedrock Edition',
	format_page: {
		content: [
			{type: 'h3', text: tl('mode.start.format.informations')},
			{text: `* ${tl('format.bedrock.info.textures')}`},
			{type: 'h3', text: tl('mode.start.format.resources')},
			{text: `* [Article on modeling and implementation](https://www.blockbench.net/wiki/guides/bedrock-modeling)
					* [Modeling Tutorial Series](https://www.youtube.com/watch?v=U9FLteWmFzg&list=PLvULVkjBtg2SezfUA8kHcPUGpxIS26uJR)`.replace(/\t+/g, '')
			}
		]
	},
	node_name_regex: '\\w.-',
	rotate_cubes: true,
	box_uv: true,
	optional_box_uv: true,
	uv_rotation: true,
	single_texture: true,
	bone_rig: true,
	centered_grid: true,
	animated_textures: true,
	animation_files: true,
	animation_mode: true,
	animation_controllers: true,
	remember_files: ['textures', 'texture_sets', 'animation_files'],
	bone_binding_expression: true,
	molang: true,
	locators: true,
	texture_meshes: true,
	bounding_boxes: true,
	pbr: true,
	codec,
	animation_codec,
	onSetup(project) {
		if (isApp) {
			project.BedrockEntityManager = new BedrockEntityManager(project);
		}
	}
})
Object.defineProperty(entity_format, 'per_texture_uv_size', {
	get: _ => Project.multi_file_ruleset ? true : false
});

var block_format = new ModelFormat({
	id: 'bedrock_block',
	category: 'minecraft',
	extension: 'json',
	icon: 'icon-format_bedrock_block',
	target: 'Minecraft: Bedrock Edition',
	format_page: {
		content: [
			{type: 'h3', text: tl('mode.start.format.informations')},
			{text: `* ${tl('format.bedrock_block.info.size_limit')}`},
			{text: `* ${tl('format.bedrock_block.info.textures')}`},
			{type: 'h3', text: tl('mode.start.format.resources')},
			{text: `* [Article on implementing custom blocks](https://learn.microsoft.com/en-us/minecraft/creator/documents/customblock)
					* [Modeling Tutorial Series](https://www.youtube.com/watch?v=U9FLteWmFzg&list=PLvULVkjBtg2SezfUA8kHcPUGpxIS26uJR)`.replace(/\t+/g, '')
			}
		]
	},
	node_name_regex: '\\w.-',
	show_on_start_screen: true,
	rotate_cubes: true,
	box_uv: false,
	optional_box_uv: true,
	uv_rotation: true,
	single_texture_default: true,
	bone_rig: true,
	centered_grid: true,
	animated_textures: true,
	animation_files: false,
	remember_files: ['textures', 'texture_sets'],
	animation_mode: false,
	display_mode: true,
	texture_meshes: true,
	bounding_boxes: true,
	molang: true,
	pbr: true,
	cube_size_limiter: {
		rotation_affected: true,
		box_marker_size: [30, 30, 30],
		updateBoxMarker() {
			let center = Format.cube_size_limiter.getModelCenter();
			if (three_grid.size_limit_box) three_grid.size_limit_box.position.set(center[0] + center[3], center[1] + center[4], center[2] + center[5]).divideScalar(2);
		},
		getModelCenter(exclude_cubes = []) {
			let cache_key = exclude_cubes.length > 0 ? 'cached_center' : 'cached_center_all'
			if (block_format.cube_size_limiter[cache_key]) {
				return block_format.cube_size_limiter[cache_key];
			}

			let center = [-7, 1, -7, 7, 15, 7];
			Cube.all.forEach(cube => {
				if (exclude_cubes.includes(cube)) return;
				let vertices = block_format.cube_size_limiter.getCubeVertexCoordinates(cube, cube);

				vertices.forEach(array => {
					center[3] = Math.min(center[3], array[0] + 15);		center[0] = Math.max(center[0], array[0] - 15);
					center[4] = Math.min(center[4], array[1] + 15);		center[1] = Math.max(center[1], array[1] - 15);
					center[5] = Math.min(center[5], array[2] + 15);		center[2] = Math.max(center[2], array[2] - 15);
				})
			})
			block_format.cube_size_limiter[cache_key] = center;
			setTimeout(() => {
				delete block_format.cube_size_limiter[cache_key];
			}, 2)
			return center;
		},
		getCubeVertexCoordinates(cube, values) {
			let {from, to, inflate} = values;

			let vertices = [
				[from[0]-inflate, from[1]-inflate, from[2]-inflate],
				[from[0]-inflate, from[1]-inflate, to[2] + inflate],
				[from[0]-inflate, to[1] + inflate, from[2]-inflate],
				[from[0]-inflate, to[1] + inflate, to[2] + inflate],
				[to[0] + inflate, from[1]-inflate, from[2]-inflate],
				[to[0] + inflate, from[1]-inflate, to[2] + inflate],
				[to[0] + inflate, to[1] + inflate, from[2]-inflate],
				[to[0] + inflate, to[1] + inflate, to[2] + inflate]
			];
			vertices.forEach(array => {
				array.V3_subtract(cube.origin)
				let vector = Reusable.vec1.set(...array);
				cube.mesh.localToWorld(vector);
				array.replace(vector.toArray());
			});
			return vertices;
		},
		// Test if it overlaps
		test(cube, values = 0) {
			let from = values.from || cube.from;
			let to = values.to || cube.to;
			let inflate = values.inflate == undefined ? cube.inflate : values.inflate;

			let vertices = block_format.cube_size_limiter.getCubeVertexCoordinates(cube, {from, to, inflate});
			let center = block_format.cube_size_limiter.getModelCenter([cube]);

			let vertex_outside_bounds = vertices.find((v, i) => {
				return (v[0] > center[3]+15 || v[0] < center[0]-15)
					|| (v[1] > center[4]+15 || v[1] < center[1]-15)
					|| (v[2] > center[5]+15 || v[2] < center[2]-15);
			})
			return vertex_outside_bounds !== undefined;
		},
		move(cube, values = 0) {
			let from = values.from || cube.from;
			let to = values.to || cube.to;
			let inflate = values.inflate == undefined ? cube.inflate : values.inflate;

			let vertices = block_format.cube_size_limiter.getCubeVertexCoordinates(cube, {from, to, inflate});
			let center = block_format.cube_size_limiter.getModelCenter([cube]);

			let offset = [0, 0, 0];

			vertices.forEach(v => {
				v.forEach((val, i) => {
					if (val > center[i+3] + 15) offset[i] = Math.max(offset[i], val - (center[i+3] + 15));
					if (val < center[i] - 15) offset[i] = Math.min(offset[i], val - (center[i] - 15));
				})
			})

			let quat = cube.mesh.getWorldQuaternion(Reusable.quat1).invert();
			let required_offset = Reusable.vec2.set(...offset).applyQuaternion(quat).toArray();
			
			from.V3_subtract(required_offset);
			to.V3_subtract(required_offset);
						
		},
		clamp(cube, values = 0, axis, direction) {
			let from = values.from || cube.from;
			let to = values.to || cube.to;
			let inflate = values.inflate == undefined ? cube.inflate : values.inflate;

			let vertices = block_format.cube_size_limiter.getCubeVertexCoordinates(cube, {from, to, inflate});
			let center = block_format.cube_size_limiter.getModelCenter();

			let offset_from = [0, 0, 0];
			let offset_to = [0, 0, 0];

			vertices.forEach((v, vi) => {
				v.forEach((val, i) => {
					if (axis !== undefined && axis !== i) return;
					if ((i == 0 && vi < 4) || (i == 1 && (vi % 4) < 2) || (i == 2 && (vi % 2) < 1)) {
						if (val > center[i+3] + 15) offset_from[i] = Math.max(offset_from[i], val - (center[i+3] + 15));
						if (val < center[i] - 15) offset_from[i] = Math.min(offset_from[i], val - (center[i] - 15));
					} else {
						if (val > center[i+3] + 15) offset_to[i] = Math.max(offset_to[i], val - (center[i+3] + 15));
						if (val < center[i] - 15) offset_to[i] = Math.min(offset_to[i], val - (center[i] - 15));
					}
				})
			})

			let quat = cube.mesh.getWorldQuaternion(Reusable.quat1).invert();
			if (direction !== true) {
				let required_offset_to = Reusable.vec3.set(...offset_to).applyQuaternion(quat).toArray();
				to.V3_subtract(required_offset_to);
			}
			if (direction !== false) {
				let required_offset_from = Reusable.vec2.set(...offset_from).applyQuaternion(quat).toArray();
				from.V3_subtract(required_offset_from);
			}
		}
	},
	codec,
	onSetup(project) {
		if (isApp) {
			project.BedrockBlockManager = new BedrockBlockManager(project);
		}
	}
})
codec.format = entity_format;

BARS.defineActions(function() {
	codec.export_action = new Action({
		id: 'export_bedrock',
		icon: entity_format.icon,
		category: 'file',
		condition: () => Format == entity_format || Format == block_format,
		click: function () {
			codec.export()
		}
	})
})


new ValidatorCheck('bedrock_binding', {
	condition: isApp && {formats: ['bedrock']},
	update_triggers: ['update_selection'],
	run() {
		if (Project.BedrockEntityManager?.client_entity?.type == 'attachable') {
			if (Group.all.length && !Group.all.find(g => g.bedrock_binding)) {
				this.warn({
					message: `The project is an attachable, but no bone is bound to the player. Define a binding on one of the root bones.`,
					buttons: [
						{
							name: 'Bind root bone to player hand',
							icon: 'fa-paperclip',
							click() {
								let root = Outliner.root.find(n => n instanceof Group);
								Undo.initEdit({group: root});
								root.bedrock_binding = 'q.item_slot_to_bone_name(c.item_slot)';
								Undo.finishEdit('Set binding');
								Validator.validate();
							}
						}
					]
				})
			}
		}
	}
})
