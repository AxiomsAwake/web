import { CanvasFrame } from "../../lib/CanvasFrame"
import StateMemory from "../../util/state_memory";
import { setProjectTitle } from "../../interface/interface"
import { getAllGroups } from "../../outliner/types/group"
import { DefaultCameraPresets } from "../../preview/preview"
import { MinecraftEULA } from "../../preview/preview_scenes"
import { TextureGenerator } from "../../texturing/texture_generator"
import { Panel, Panels } from "../../interface/panels";
import { Blockbench } from "../../api";
import { FormResultValue } from "../../interface/form";

type SkinPreset = {
	display_name: string
	pose?: boolean
	model?: string
	model_java?: string
	model_bedrock?: string
	variants?: {
		[key: string]: {
			name: string
			model: string
		}
	}
}
export const skin_presets: Record<string, SkinPreset> = {};

type SkinPoseData = Record<string, ArrayVector3 | {rotation: ArrayVector3, offset: ArrayVector3}>
const DefaultPoses: Record<string, SkinPoseData> = {
	none: {
		Waist: [0, 0, 0],
		Head: [0, 0, 0],
		Body: [0, 0, 0],
		RightArm: [0, 0, 0],
		LeftArm: [0, 0, 0],
		RightLeg: [0, 0, 0],
		LeftLeg: [0, 0, 0],
	},
	natural: {
		Waist: [0, 0, 0],
		Head: [6, -5, 0],
		Body: [0, 0, 0],
		RightArm: [10, 0, 0],
		LeftArm: [-12, 0, 0],
		RightLeg: [-11, 0, 2],
		LeftLeg: [10, 0, -2],
	},
	walking: {
		Waist: [0, 0, 0],
		Head: [-2, 0, 0],
		Body: [0, 0, 0],
		RightArm: [-35, 0, 0],
		LeftArm: [35, 0, 0],
		RightLeg: [42, 0, 2],
		LeftLeg: [-42, 0, -2]
	},
	crouching: {
		Waist: {rotation: [-28, 0, 0], offset: [0, -1, 1]},
		Head: {rotation: [23, 0, 0], offset: [0, -3, 1]},
		Body: {rotation: [0, 0, 0], offset: [0, -1, 1]},
		RightArm: {rotation: [12, 0, 0], offset: [0, -1, 1]},
		LeftArm: {rotation: [-20, 0, 0], offset: [0, -1, 1]},
		RightLeg: [-14, 0, 0],
		LeftLeg: [14, 0, 0],
	},
	sitting: {
		Waist: [0, 0, 0],
		Head: [5.5, 0, 0],
		Body: [0, 0, 0],
		RightArm: [36, 0, 0],
		LeftArm: [36, 0, 0],
		RightLeg: [72, -18, 0],
		LeftLeg: [72, 18, 0]
	},
	jumping: {
		Waist: [0, 0, 0],
		Head: [20, 0, 0],
		Body: [0, 0, 0],
		RightArm: {rotation: [-175, 0, -20], offset: [0, 2, 0]},
		LeftArm: {rotation: [-170, 0, 15], offset: [0, 2, 0]},
		RightLeg: {rotation: [-5, 0, 15], offset: [0, -1, 0]},
		LeftLeg: {rotation: [2.5, 0, -10], offset: [0, 6, -3.75]}
	},
	aiming: {
		Waist: [0, 0, 0],
		Head: [8, -35, 0],
		Body: [-2, 0, 0],
		RightArm: {rotation: [97, -17, -2], offset: [-1, 1, -1]},
		LeftArm: [104, -44, -10],
		RightLeg: {rotation: [2.5, 0, 0], offset: [0, 1, -2]},
		LeftLeg: [-28, 0, 0]
	},
};

export const codec = new Codec('skin_model', {
	name: 'Skin Model',
	remember: false,
	compile(options) {
		if (options === undefined) options = 0;
		type BoneData = {
			name: string
			parent?: string
			pivot?: ArrayVector3
			rotation?: ArrayVector3
			reset?: boolean
			mirror?: boolean
			cubes?: CubeData[]
		}
		type CubeData = {
			origin: ArrayVector3
			size: ArrayVector3
			inflate?: number
		}
		let entitymodel = {
			name: Project.geometry_name.replace(/\./, '_'),
			texturewidth: Project.texture_width,
			textureheight: Project.texture_height,
			external_textures: Texture.all.filter(t => t.pbr_channel == 'color').map(tex => {
				return tex.path.replace(/\\/g, '/').split('textures/')[1];
			}),
			eyes: [
				[5, 5],
				[9, 5]
			],
			bones: undefined as undefined | BoneData[]
		}
		let bones = []

		let groups = getAllGroups();

		groups.forEach(function(g) {
			if (g.type !== 'group') return;
			//Bone
			let bone: BoneData = {
				name: g.name
			}
			bone.name = g.name
			if (g.parent.type === 'group') {
				bone.parent = g.parent.name
			}
			bone.pivot = g.origin.slice()
			bone.pivot[0] *= -1
			if (!g.rotation.allEqual(0)) {
				bone.rotation = [
					-g.rotation[0],
					-g.rotation[1],
					g.rotation[2]
				]
			}
			if (g.reset) bone.reset = true;
			if (g.mirror_uv) bone.mirror = true;

			//Elements
			let cubes = []
			for (let obj of g.children) {
				if (obj.export && obj instanceof Cube) {
					let template = Codecs.bedrock.compileCube(obj, g);
					cubes.push(template)
				}
			}
			if (cubes.length) {
				bone.cubes = cubes
			}
			bones.push(bone)
		})

		if (bones.length) {
			entitymodel.bones = bones
		}
		this.dispatchEvent('compile', {model: entitymodel, options});
		return entitymodel
	},
	// @ts-ignore
	parse(data: any, resolution: number, texture_file: undefined | false | {name: string, path: string, content: string}, pose = true, layer_template) {
		this.dispatchEvent('parse', {model: data});
		Project.texture_width = data.texturewidth || 64;
		Project.texture_height = data.textureheight || 64;
		if (data.texture_resolution_factor) resolution *= data.texture_resolution_factor;

		Interface.Panels.skin_pose.inside_vue.pose = Project.skin_pose = pose ? 'natural' : 'none';

		let bones = {}
		let template_cubes = {};

		if (data.bones) {
			let included_bones = []
			data.bones.forEach(function(b) {
				included_bones.push(b.name)
			})
			data.bones.forEach(function(b, bi) {
				let group = new Group({
					name: b.name,
					origin: b.pivot,
					rotation: (pose && b.pose) ? b.pose : b.rotation
				}).init()
				group.isOpen = true;
				bones[b.name] = group
				if (b.pivot) {
					group.origin[0] *= -1
				}
				group.rotation[0] *= -1;
				group.rotation[1] *= -1;
				
				group.mirror_uv = b.mirror === true
				group.reset = b.reset === true
				group.skin_original_origin = group.origin.slice() as ArrayVector3;

				if (b.cubes) {
					b.cubes.forEach(function(cube) {

						let base_cube = Codecs.bedrock.parseCube(cube, group);
						template_cubes[Cube.all.indexOf(base_cube)] = cube;

					})
				}
				if (b.children) {
					b.children.forEach(function(cg) {
						cg.addTo(group)
					})
				}
				let parent_group: 'root' | OutlinerNode = 'root';
				if (b.parent) {
					if (bones[b.parent]) {
						parent_group = bones[b.parent]
					} else {
						data.bones.forEach(function(ib) {
							if (ib.name === b.parent) {
								ib.children && ib.children.length ? ib.children.push(group) : ib.children = [group]
							}
						})
					}
				}
				group.addTo(parent_group)
			})
		}
		if (!Cube.all.find(cube => cube.box_uv)) {
			Project.box_uv = false;
		}
		let texture: Texture | undefined;
		if (typeof texture_file == 'object') {
			texture = new Texture().fromFile(texture_file).add(false);
		} else if (texture_file != false && resolution) {
			texture = generateTemplate(
				Project.texture_width*resolution,
				Project.texture_height*resolution,
				template_cubes,
				data.name,
				data.eyes,
				layer_template
			)
		}
		for (let index in template_cubes) {
			if (template_cubes[index].visibility === false) {
				Cube.all[index].visibility = false;
			}
		}
		if (texture) {
			texture.load_callback = function() {
				Modes.options.paint.select();
			}
		}
		if (data.camera_angle) {
			// @ts-ignore
			Preview.selected.loadAnglePreset(DefaultCameraPresets.find(p => p.id == data.camera_angle))
		}
		Canvas.updateAllBones()
		Canvas.updateVisibility()
		setProjectTitle()
		updateSelection()
	},
})
codec.export = null;
codec.rebuild = function(model_id: string, pose?: string, pose_data?: SkinPoseData) {
	let [preset_id, variant] = model_id.split('.');
	let preset = skin_presets[preset_id];
	let model_raw = preset.model || (variant == 'java' ? preset.model_java : preset.model_bedrock) || preset.variants[variant].model;
	let model = JSON.parse(model_raw);
	// @ts-ignore
	codec.parse(model, undefined, true, pose && pose !== 'none');
	if (pose_data) {
		loadPose(pose_data);
		Panels.skin_pose.inside_vue.pose = Project.skin_pose = pose ?? '';
	} else if (pose && pose !== 'none' && pose !== 'natural') {
		setTimeout(() => {
			setDefaultPose(pose);
		}, 1)
	}
}
codec.getPoseData = getPoseData;


export const format = new ModelFormat('skin', {
	icon: 'icon-player',
	category: 'minecraft',
	target: ['Minecraft: Java Edition', 'Minecraft: Bedrock Edition'],
	format_page: {
		content: [
			{type: 'h3', text: tl('mode.start.format.informations')},
			{text: `* ${tl('format.skin.info.skin')}
					* ${tl('format.skin.info.model')}`.replace(/\t+/g, '')
			},
			{type: 'h3', text: tl('mode.start.format.resources')},
			{text: `* [Skin Design Tutorial](https://youtu.be/xC81Q3HGraE)`}
		]
	},
	can_convert_to: false,
	model_identifier: false,
	bone_rig: true,
	box_uv: true,
	centered_grid: true,
	single_texture: true,
	integer_size: true,
	rotate_cubes: false,
	edit_mode: false,
	pose_mode: true,
	codec
})
format.new = function() {
	skin_dialog.show();
	return true;
}
skin_presets;


function setDefaultPose(pose_id: string) {
	let angles = DefaultPoses[pose_id];
	loadPose(angles);
	Panels.skin_pose.inside_vue.pose = pose_id;
	Project.skin_pose = pose_id;
}
function loadPose(pose_data: SkinPoseData) {
	Panels.skin_pose.inside_vue.pose = '';
	Group.all.forEach(group => {
		if (!group.skin_original_origin) return;

		type BoneData = {rotation: ArrayVector3, offset: ArrayVector3};
		let bone_data: BoneData | ArrayVector3 = pose_data[group.name]
			|| pose_data[group.name.replace(/\s/g, '')]
			|| {rotation: [0, 0, 0], offset: [0, 0, 0]};
		if (bone_data instanceof Array) {
			bone_data = {rotation: bone_data as ArrayVector3, offset: [0, 0, 0]};
		}
		let offset: ArrayVector3 = group.skin_original_origin.slice().V3_subtract(group.origin);
		offset.V3_add(bone_data.offset);
		
		group.extend({rotation: bone_data.rotation});
		group.origin.V3_add(offset);
		let child_cubes = group.children.filter(c => c instanceof Cube);
		for (let cube of child_cubes) {
			cube.origin.V3_add(offset);
			cube.from.V3_add(offset);
			cube.to.V3_add(offset);
		}
	});
	Canvas.updateView({
		groups: Group.all,
		group_aspects: {transform: true},
		elements: Outliner.elements,
		element_aspects: {transform: true},
		selection: true
	})
}
function getPoseData(): SkinPoseData {
	const data: SkinPoseData = {};
	for (let group of Group.all) {
		if (!group.skin_original_origin) continue;
		let offset = group.origin.slice().V3_subtract(group.skin_original_origin);
		let rotation = group.rotation.slice() as ArrayVector3;
		if (offset.allEqual(0) == false) {
			data[group.name] = {
				offset, rotation
			}
		} else if (rotation.allEqual(0) == false) {
			data[group.name] = rotation;
		}
	}
	return data;
}

export function generateTemplate(width = 64, height = 64, cubes, name = 'name', eyes, layer_template): Texture {

	let texture = new Texture({
		internal: true,
		name: name+'.png'
	})

	let canvas = document.createElement('canvas')
	let ctx = canvas.getContext('2d');
	canvas.width = width;
	canvas.height = height;

	if (Project.box_uv) {
		Cube.all.forEach((cube, i) => {
			let template_cube = cubes[i];
			if (layer_template || !template_cube.layer) {
				TextureGenerator.paintCubeBoxTemplate(cube, texture, canvas, null, template_cube.layer);
			}
		})
	} else if (cubes[0] && !cubes[0].layer) {
		ctx.fillStyle = TextureGenerator.face_data.up.c1;
		ctx.fillRect(0, 0, width, height)
		ctx.fillStyle = TextureGenerator.face_data.up.c2;
		ctx.fillRect(1, 1, width-2, height-2)
	}
	if (eyes) {
		let res_multiple = canvas.width/Project.texture_width;
		ctx.fillStyle = '#cdefff';
		eyes.forEach(eye => {
			ctx.fillRect(
				eye[0]*res_multiple,
				eye[1]*res_multiple,
				(eye[2]||2)*res_multiple,
				(eye[3]||2)*res_multiple
			)
		})
	}
	let dataUrl = canvas.toDataURL();
	texture.fromDataURL(dataUrl).add(false);
	return texture;
}

export const model_options: Record<string, string> = {};
let selected_model = '';
export const skin_dialog = new Dialog({
	title: tl('dialog.skin.title'),
	id: 'skin',
	form: {
		model: {
			label: 'dialog.skin.model',
			type: 'select',
			options: model_options
		},
		game_edition: {
			label: 'dialog.skin.variant',
			type: 'inline_select',
			default: 'java_edition',
			options: {
				java_edition: 'Java Edition',
				bedrock_edition: 'Bedrock Edition',
			},
			condition(form: Record<string, FormResultValue>) {
				return !!skin_presets[form.model as string].model_bedrock;
			}
		},
		variant: {
			label: 'dialog.skin.variant',
			type: 'select',
			options() {
				return (selected_model && skin_presets[selected_model].variants) || {}
			},
			condition(form) {
				return !!skin_presets[form.model].variants;
			}
		},
		resolution: {label: 'dialog.create_texture.resolution', type: 'select', value: 1, options: {
			1: 'generic.default',
			16: '16x',
			32: '32x',
			64: '64x',
			128: '128x',
		}},
		resolution_warning: {
			type: 'info', text: 'dialog.skin.high_res_texture',
			condition: (form) => form.resolution > 16 && (form.model == 'steve' || form.model == 'alex')
		},
		texture_source: {
			label: 'dialog.skin.texture_source',
			type: 'select',
			options: {
				template: 'dialog.skin.texture_source.template',
				load_texture: navigator.onLine ? 'dialog.skin.texture_source.load_texture' : undefined,
				upload_texture: 'dialog.skin.texture_file',
			}
		},
		texture_file: {
			label: 'dialog.skin.texture_file',
			condition: result => result.texture_source == 'upload_texture',
			type: 'file',
			extensions: ['png'],
			readtype: 'image',
			filetype: 'PNG',
			return_as: 'file'
		},
		pose: {type: 'checkbox', label: 'dialog.skin.pose', value: true, condition: form => (!!skin_presets[form.model].pose)},
		layer_template: {type: 'checkbox', label: 'dialog.skin.layer_template', value: false}
	},
	onFormChange(result) {
		selected_model = result.model as string;
		let variants = skin_presets[result.model as string].variants;
		if (variants) {
			for (let key in variants) {
				if (!result.variant || !variants[result.variant as string]) {
					result.variant = key;
					skin_dialog.setFormValues({variant: key}, false);
					break;
				}
			}
		}
	},
	onConfirm: function(result) {
		if (result.model == 'flat_texture') {
			if (result.texture) {
				Codecs.image.load(result.texture);
			} else {
				Formats.image.new();
			}

		} else {
			if (newProject(format)) {
				let preset = skin_presets[result.model];
				let raw_model: string;
				if (preset.model_bedrock) {
					raw_model = result.game_edition == 'java_edition' ? preset.model_java : preset.model_bedrock;
				} else if (preset.variants) {
					raw_model = preset.variants[result.variant].model;
				} else {
					raw_model = preset.model;
				}
				let model = JSON.parse(raw_model);
				let resolution = result.resolution;
				if (resolution == 1) {
					resolution = model.default_resolution ?? 16;
				}
				let texture: string | undefined | false;
				if (result.texture_source == 'upload_texture') {
					texture = result.texture_file;
				} else if (result.texture_source == 'load_texture') {
					if (!model.external_textures) {
						Blockbench.showQuickMessage('This skin model does not support loading textures from Minecraft at the moment', 3000);
					} else if (!navigator.onLine) {
						Blockbench.showQuickMessage('Failed to load skin texture from Minecraft. Check your internet connection.', 3000);
					} else {
						texture = false;
					}
				}
				// @ts-ignore
				codec.parse(model, resolution / 16, texture, result.pose, result.layer_template);
				Project.skin_model = result.model;
				if (preset.model_bedrock) {
					Project.skin_model += '.' + (result.game_edition == 'java_edition' ? 'java' : 'bedrock');
				} else if (preset.variants) {
					Project.skin_model += '.' + result.variant;
				}
				if (result.texture_source == 'load_texture' && navigator.onLine) {
					MinecraftEULA.promptUser('skin').then(async function(accepted) {
						if (accepted != true) return;
						if (!model.external_textures) return;
						for (let path of model.external_textures) {
							let frame = new CanvasFrame();
							let resource_path = `https://raw.githubusercontent.com/Mojang/bedrock-samples/preview/resource_pack/textures/${path}?raw=true`;
							let load_promise;
							if (path.endsWith('.tga')) {
								load_promise = fetch(resource_path)
									.then(res => res.arrayBuffer())
									.then(buffer => frame.loadFromTGA(new Uint8Array(buffer)));
							} else {
								load_promise = frame.loadFromURL(resource_path);
							}
							load_promise.then(() => {
								let dataUrl = frame.canvas.toDataURL();
								let texture = new Texture({
									internal: true,
									name: pathToName(path, true)
								});
								texture.fromDataURL(dataUrl).add(false);
							});
						}
					});
				}
			}
		}
	},
	onCancel() {
		Blockbench.Format = 0;
		Settings.updateSettingsInProfiles();
	}
});
// @ts-ignore
format.setup_dialog = skin_dialog;

type SkinPose = {
	name: string
	data: SkinPoseData
}
StateMemory.init('skin_poses', 'array');

BARS.defineActions(function() {
	new Mode('pose', {
		icon: 'emoji_people',
		default_tool: 'rotate_tool',
		category: 'navigate',
		condition: () => Format && Format.pose_mode,
	})

	new Action('toggle_skin_layer', {
		icon: 'layers_clear',
		category: 'edit',
		condition: {formats: ['skin']},
		click: function () {
			let edited = [];
			Cube.all.forEach(cube => {
				if (cube.name.toLowerCase().includes('layer')) {
					edited.push(cube);
				}
			})
			if (!edited.length) return;
			Undo.initEdit({elements: edited});
			let value = !edited[0].visibility;
			edited.forEach(cube => {
				cube.visibility = value;
			})
			Undo.finishEdit('Toggle skin layer');
			Canvas.updateVisibility()
		}
	})
	new Action('convert_minecraft_skin_variant', {
		icon: 'compare_arrows',
		category: 'edit',
		condition: {formats: ['skin'], method: () => !!Group.all.find(g => g.name == 'Right Arm')},
		click() {
			let is_slim = Cube.all.find(c => c.name.match(/arm/i)).size(0) == 3;
			new Dialog('convert_minecraft_skin_variant', {
				title: 'action.convert_minecraft_skin_variant',
				form: {
					model: {
						label: 'dialog.skin.model',
						type: 'select',
						value: is_slim ? 'steve' : 'alex',
						options: {
							steve: skin_presets.steve.display_name,
							alex: skin_presets.alex.display_name,
						}
					},
					adjust_texture: {
						label: 'dialog.convert_skin.adjust_texture',
						type: 'checkbox',
						value: true,
					}
				},
				onConfirm(result) {
					let right_arm = Group.all.find(g => g.name == 'Right Arm')?.children?.filter(el => el instanceof Cube) ?? [];
					let left_arm = Group.all.find(g => g.name == 'Left Arm')?.children?.filter(el => el instanceof Cube) ?? [];
					let elements = right_arm.concat(left_arm);
					Undo.initEdit({elements});
					for (let cube of right_arm) {
						cube.to[0] = result.model == 'alex' ? 7 : 8;
					}
					for (let cube of left_arm) {
						cube.from[0] = result.model == 'alex' ? -7 : -8;
					}
					Canvas.updateView({elements: right_arm.concat(left_arm), element_aspects: {geometry: true, uv: true}, selection: true});
					Undo.finishEdit('Convert Minecraft skin model');

					if (result.adjust_texture) {
						let textures = Texture.all.filter(tex => tex.selected || tex.multi_selected);
						if (!textures.length) textures = [Texture.getDefault()]
						if (!textures[0]) return;
						
						const arm_uv_positions: [number, number][] = [
							[40, 16],
							[40, 32],
							[32, 48],
							[48, 48],
						];
						type Translation = {area: [number, number, number, number], offset: [number, number]};
						let translations: Translation[];
						if (result.model == 'alex') {
							translations = [
								{area: [6, 0, 10, 16], offset: [-1, 0]},
								{area: [9, 0, 2, 4], offset: [-1, 0]},
								{area: [13, 4, 2, 12], offset: [-1, 0]},
							];
						} else {
							translations = [
								{area: [5, 0, 10, 16], offset: [1, 0]},
								{area: [9, 0, 2, 4], offset: [1, 0]},
								{area: [13, 4, 2, 12], offset: [1, 0]},
							];
						}
						Undo.initEdit({textures, bitmap: true});
						for (let texture of textures) {
							if (texture.layers_enabled) {
								texture.layers_enabled = false;
								texture.selected_layer = null;
								texture.layers.empty();
							}
							texture.edit(() => {
								let ctx = texture.ctx;
								for (let position of arm_uv_positions) {
									for (let translation of translations) {
										let data = ctx.getImageData(
											position[0] + translation.area[0],
											position[1] + translation.area[1],
											translation.area[2],
											translation.area[3],
										);
										ctx.putImageData(data,
											position[0] + translation.area[0] + translation.offset[0],
											position[1] + translation.area[1] + translation.offset[1]
										);
									}
									if (result.model == 'alex') {
										ctx.clearRect(position[0] + 10, position[1] + 0, 2, 4);
										ctx.clearRect(position[0] + 14, position[1] + 4, 2, 12);
									}
								}
							}, {no_undo: true});
						}
						UVEditor.vue.layer = null;
						updateSelection();
						Undo.finishEdit('Convert Minecraft skin texture');
					}
				}
			}).show();
		}
	})
	new Action('export_minecraft_skin', {
		icon: 'icon-player',
		category: 'file',
		condition: () => Format == format && !!Texture.all[0],
		click: function () {
			Texture.all[0].save(true);
		}
	})
	
	let explode_skin_model = new Toggle('explode_skin_model', {
		icon: () => 'open_in_full',
		category: 'edit',
		condition: {formats: ['skin']},
		default: false,
		onChange(exploded_view) {
			Undo.initEdit({elements: Cube.all, exploded_view: !exploded_view});
			Cube.all.forEach(cube => {
				let center = [
					cube.from[0] + (cube.to[0] - cube.from[0]) / 2,
					cube.from[1],
					cube.from[2] + (cube.to[2] - cube.from[2]) / 2,
				]
				let offset = cube.name.toLowerCase().includes('leg') ? 1 : 0.5;
				center.V3_multiply(exploded_view ? offset : -offset/(1+offset));
				cube.from.V3_add(center as ArrayVector3);
				cube.to.V3_add(center as ArrayVector3);
			})
			Project.exploded_view = exploded_view;
			Undo.finishEdit(exploded_view ? 'Explode skin model' : 'Revert exploding skin model', {elements: Cube.all, exploded_view: exploded_view});
			Canvas.updateView({elements: Cube.all, element_aspects: {geometry: true}});
			this.setIcon(this.icon);
		}
	})
	Blockbench.on('select_project', () => {
		explode_skin_model.value = !!Project.exploded_view;
		explode_skin_model.updateEnabledState();
	})

	
	new Action('custom_skin_poses', {
		icon: 'format_list_bulleted',
		category: 'view',
		condition: {formats: ['skin'], modes: ['pose']},
		click(e) {
			new Menu(this.children()).open(e.target as HTMLElement);
		},
		children() {
			let options = [];
			let memory_list = StateMemory.get('skin_poses') as SkinPose[];
			memory_list.forEach((pose: SkinPose, i: number) => {
				let option = {
					name: pose.name,
					icon: 'accessibility',
					id: i.toString(),
					click() {
						loadPose(pose.data);
					},
					children: [
						{icon: 'update', name: 'action.custom_skin_poses.update', description: 'action.custom_skin_poses.update.desc', click() {
							pose.data = getPoseData();
							StateMemory.save('skin_poses');
						}},
						{icon: 'delete', name: 'generic.delete', click() {
							memory_list.remove(pose);
							StateMemory.save('skin_poses');
						}}
					]
				}
				options.push(option);
			})
			
			options.push(
				'_',
				'add_custom_skin_pose'
			);
			return options;
		}
	})
	new Action('add_custom_skin_pose', {
		icon: 'add',
		category: 'view',
		condition: {formats: ['skin'], modes: ['pose']},
		click(e) {
			Blockbench.textPrompt('generic.name', 'new pose', value => {
				let pose: SkinPose = {
					name: value,
					data: getPoseData()
				};
				let memory_list = StateMemory.get('skin_poses') as SkinPose[];
				memory_list.push(pose);
				StateMemory.save('skin_poses');
			})
		}
	})
})

Interface.definePanels(function() {
	new Panel('skin_pose', {
		icon: 'icon-player',
		condition: {modes: ['pose']},
		default_position: {
			slot: 'right_bar',
			float_position: [0, 0],
			float_size: [300, 80],
			height: 80,
			sidebar_index: 1,
		},
		toolbars: [
			new Toolbar('skin_pose', {
				children: [
					'custom_skin_poses',
					'add_custom_skin_pose'
				]
			})
		],
		component: {
			data() {return {
				pose: 'default'
			}},
			methods: {
				setPose(pose) {
					setDefaultPose(pose);
				}
			},
			template: `
				<div>
					<ul id="skin_pose_selector">
						<li :class="{selected: pose == 'none'}" @click="setPose('none')" title="${tl('panel.skin_pose.none')}"><div class="pose_icon" style="mask-image: url('./assets/poses/none.svg');"/></li>
						<li :class="{selected: pose == 'natural'}" @click="setPose('natural')" title="${tl('panel.skin_pose.natural')}"><div class="pose_icon" style="mask-image: url('./assets/poses/natural.svg');"/></li>
						<li :class="{selected: pose == 'walking'}" @click="setPose('walking')" title="${tl('panel.skin_pose.walking')}"><div class="pose_icon" style="mask-image: url('./assets/poses/walking.svg');"/></li>
						<li :class="{selected: pose == 'crouching'}" @click="setPose('crouching')" title="${tl('panel.skin_pose.crouching')}"><div class="pose_icon" style="mask-image: url('./assets/poses/crouching.svg');"/></li>
						<li :class="{selected: pose == 'sitting'}" @click="setPose('sitting')" title="${tl('panel.skin_pose.sitting')}"><div class="pose_icon" style="mask-image: url('./assets/poses/sitting.svg');"/></li>
						<li :class="{selected: pose == 'jumping'}" @click="setPose('jumping')" title="${tl('panel.skin_pose.jumping')}"><div class="pose_icon" style="mask-image: url('./assets/poses/jumping.svg');"/></li>
						<li :class="{selected: pose == 'aiming'}" @click="setPose('aiming')" title="${tl('panel.skin_pose.aiming')}"><div class="pose_icon" style="mask-image: url('./assets/poses/aiming.svg');"/></li>
					</ul>
				</div>
			`
		}
	})
})

// Source: https://github.com/Mojang/bedrock-samples/, licensed under the Minecraft EULA
// With modifications for usability

// Clipbench.setText(compileJSON(Codecs.skin_model.compile({raw: false})).replace(/\n/g, '\n\t'))

skin_presets.steve = {
	display_name: 'Player - Wide',
	pose: true,
	model: `{
		"name": "steve",
		"texturewidth": 64,
		"textureheight": 64,
		"eyes": [
			[9, 11],
			[13, 11]
		],
		"bones": [
			{
				"name": "Waist",
				"color": 0,
				"pivot": [0, 12, 0],
				"pose": [0, 0, 0]
			},
			{
				"name": "Head",
				"parent": "Waist",
				"color": 1,
				"pivot": [0, 24, 0],
				"pose": [-6, 5, 0],
				"cubes": [
					{"name": "Head", "origin": [-4, 24, -4], "size": [8, 8, 8], "uv": [0, 0]},
					{"name": "Hat Layer", "visibility": false, "origin": [-4, 24, -4], "size": [8, 8, 8], "uv": [32, 0], "inflate": 0.5, "layer": true}
				]
			},
			{
				"name": "Body",
				"parent": "Waist",
				"color": 3,
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "Body", "origin": [-4, 12, -2], "size": [8, 12, 4], "uv": [16, 16]},
					{"name": "Body Layer", "visibility": false, "origin": [-4, 12, -2], "size": [8, 12, 4], "uv": [16, 32], "inflate": 0.25, "layer": true}
				]
			},
			{
				"name": "Right Arm",
				"parent": "Waist",
				"color": 5,
				"pivot": [-5, 22, 0],
				"pose": [-10, 0, 0],
				"cubes": [
					{"name": "Right Arm", "origin": [-8, 12, -2], "size": [4, 12, 4], "uv": [40, 16]},
					{"name": "Right Arm Layer", "visibility": false, "origin": [-8, 12, -2], "size": [4, 12, 4], "uv": [40, 32], "inflate": 0.25, "layer": true}
				]
			},
			{
				"name": "Left Arm",
				"parent": "Waist",
				"color": 0,
				"pivot": [5, 22, 0],
				"pose": [12, 0, 0],
				"cubes": [
					{"name": "Left Arm", "origin": [4, 12, -2], "size": [4, 12, 4], "uv": [32, 48]},
					{"name": "Left Arm Layer", "visibility": false, "origin": [4, 12, -2], "size": [4, 12, 4], "uv": [48, 48], "inflate": 0.25, "layer": true}
				]
			},
			{
				"name": "Right Leg",
				"color": 6,
				"pivot": [-1.9, 12, 0],
				"pose": [11, 0, 2],
				"cubes": [
					{"name": "Right Leg", "origin": [-3.9, 0, -2], "size": [4, 12, 4], "uv": [0, 16]},
					{"name": "Right Leg Layer", "visibility": false, "origin": [-3.9, 0, -2], "size": [4, 12, 4], "uv": [0, 32], "inflate": 0.25, "layer": true}
				]
			},
			{
				"name": "Left Leg",
				"color": 7,
				"pivot": [1.9, 12, 0],
				"pose": [-10, 0, -2],
				"cubes": [
					{"name": "Left Leg", "origin": [-0.1, 0, -2], "size": [4, 12, 4], "uv": [16, 48]},
					{"name": "Left Leg Layer", "visibility": false, "origin": [-0.1, 0, -2], "size": [4, 12, 4], "uv": [0, 48], "inflate": 0.25, "layer": true}
				]
			}
		]
	}`
};
skin_presets.alex = {
	display_name: 'Player - Slim',
	pose: true,
	model_java: `{
		"name": "alex",
		"texturewidth": 64,
		"textureheight": 64,
		"eyes": [
			[9, 11],
			[13, 11]
		],
		"bones": [
			{
				"name": "Waist",
				"color": 0,
				"pivot": [0, 12, 0],
				"pose": [0, 0, 0]
			},
			{
				"name": "Head",
				"parent": "Waist",
				"color": 1,
				"pivot": [0, 24, 0],
				"pose": [-6, 5, 0],
				"cubes": [
					{"name": "Head", "origin": [-4, 24, -4], "size": [8, 8, 8], "uv": [0, 0]},
					{"name": "Hat Layer", "visibility": false, "origin": [-4, 24, -4], "size": [8, 8, 8], "uv": [32, 0], "inflate": 0.5, "layer": true}
				]
			},
			{
				"name": "Body",
				"parent": "Waist",
				"color": 3,
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "Body", "origin": [-4, 12, -2], "size": [8, 12, 4], "uv": [16, 16]},
					{"name": "Body Layer", "visibility": false, "origin": [-4, 12, -2], "size": [8, 12, 4], "uv": [16, 32], "inflate": 0.25, "layer": true}
				]
			},
			{
				"name": "Right Arm",
				"parent": "Waist",
				"color": 5,
				"pivot": [-5, 22, 0],
				"pose": [-10, 0, 0],
				"cubes": [
					{"name": "Right Arm", "origin": [-7, 12, -2], "size": [3, 12, 4], "uv": [40, 16]},
					{"name": "Right Arm Layer", "visibility": false, "origin": [-7, 12, -2], "size": [3, 12, 4], "uv": [40, 32], "inflate": 0.25, "layer": true}
				]
			},
			{
				"name": "Left Arm",
				"parent": "Waist",
				"color": 0,
				"pivot": [5, 22, 0],
				"pose": [12, 0, 0],
				"cubes": [
					{"name": "Left Arm", "origin": [4, 12, -2], "size": [3, 12, 4], "uv": [32, 48]},
					{"name": "Left Arm Layer", "visibility": false, "origin": [4, 12, -2], "size": [3, 12, 4], "uv": [48, 48], "inflate": 0.25, "layer": true}
				]
			},
			{
				"name": "Right Leg",
				"color": 6,
				"pivot": [-1.9, 12, 0],
				"pose": [11, 0, 2],
				"cubes": [
					{"name": "Right Leg", "origin": [-3.9, 0, -2], "size": [4, 12, 4], "uv": [0, 16]},
					{"name": "Right Leg Layer", "visibility": false, "origin": [-3.9, 0, -2], "size": [4, 12, 4], "uv": [0, 32], "inflate": 0.25, "layer": true}
				]
			},
			{
				"name": "Left Leg",
				"color": 7,
				"pivot": [1.9, 12, 0],
				"pose": [-10, 0, -2],
				"cubes": [
					{"name": "Left Leg", "origin": [-0.1, 0, -2], "size": [4, 12, 4], "uv": [16, 48]},
					{"name": "Left Leg Layer", "visibility": false, "origin": [-0.1, 0, -2], "size": [4, 12, 4], "uv": [0, 48], "inflate": 0.25, "layer": true}
				]
			}
		]
	}`,
	model_bedrock: `{
		"name": "alex",
		"texturewidth": 64,
		"textureheight": 64,
		"eyes": [
			[9, 11],
			[13, 11]
		],
		"bones": [
			{
				"name": "Waist",
				"color": 0,
				"pivot": [0, 12, 0],
				"pose": [0, 0, 0]
			},
			{
				"name": "Head",
				"parent": "Waist",
				"color": 1,
				"pivot": [0, 24, 0],
				"pose": [-6, 5, 0],
				"cubes": [
					{"name": "Head", "origin": [-4, 24, -4], "size": [8, 8, 8], "uv": [0, 0]},
					{"name": "Hat Layer", "visibility": false, "origin": [-4, 24, -4], "size": [8, 8, 8], "uv": [32, 0], "inflate": 0.5, "layer": true}
				]
			},
			{
				"name": "Body",
				"parent": "Waist",
				"color": 3,
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "Body", "origin": [-4, 12, -2], "size": [8, 12, 4], "uv": [16, 16]},
					{"name": "Body Layer", "visibility": false, "origin": [-4, 12, -2], "size": [8, 12, 4], "uv": [16, 32], "inflate": 0.25, "layer": true}
				]
			},
			{
				"name": "Right Arm",
				"parent": "Waist",
				"color": 5,
				"pivot": [-5, 21.5, 0],
				"pose": [-10, 0, 0],
				"cubes": [
					{"name": "Right Arm", "origin": [-7, 11.5, -2], "size": [3, 12, 4], "uv": [40, 16]},
					{"name": "Right Arm Layer", "visibility": false, "origin": [-7, 11.5, -2], "size": [3, 12, 4], "uv": [40, 32], "inflate": 0.25, "layer": true}
				]
			},
			{
				"name": "Left Arm",
				"parent": "Waist",
				"color": 0,
				"pivot": [5, 21.5, 0],
				"pose": [12, 0, 0],
				"cubes": [
					{"name": "Left Arm", "origin": [4, 11.5, -2], "size": [3, 12, 4], "uv": [32, 48]},
					{"name": "Left Arm Layer", "visibility": false, "origin": [4, 11.5, -2], "size": [3, 12, 4], "uv": [48, 48], "inflate": 0.25, "layer": true}
				]
			},
			{
				"name": "Right Leg",
				"color": 6,
				"pivot": [-1.9, 12, 0],
				"pose": [11, 0, 2],
				"cubes": [
					{"name": "Right Leg", "origin": [-3.9, 0, -2], "size": [4, 12, 4], "uv": [0, 16]},
					{"name": "Right Leg Layer", "visibility": false, "origin": [-3.9, 0, -2], "size": [4, 12, 4], "uv": [0, 32], "inflate": 0.25, "layer": true}
				]
			},
			{
				"name": "Left Leg",
				"color": 7,
				"pivot": [1.9, 12, 0],
				"pose": [-10, 0, -2],
				"cubes": [
					{"name": "Left Leg", "origin": [-0.1, 0, -2], "size": [4, 12, 4], "uv": [16, 48]},
					{"name": "Left Leg Layer", "visibility": false, "origin": [-0.1, 0, -2], "size": [4, 12, 4], "uv": [0, 48], "inflate": 0.25, "layer": true}
				]
			}
		]
	}`
};

skin_presets.flat_texture = {
	display_name: 'Texture',
	model: `{
		"name": "flat_texture",
		"camera_angle": "top",
		"texturewidth": 16,
		"textureheight": 16,
		"bones": [
			{
				"name": "block",
				"pivot": [0, 0, 0],
				"cubes": [
					{
						"origin": [-8, 0, -8],
						"size": [16, 1, 16],
						"layer": true,
						"uv": {
							"up": {"uv": [16, 16], "uv_size": [-16, -16]}
						}
					}
				]
			}
		]
	}`
};
skin_presets.block = {
	display_name: 'Block',
	model: `{
		"name": "block",
		"texturewidth": 16,
		"textureheight": 16,
		"bones": [
			{
				"name": "block",
				"pivot": [0, 0, 0],
				"cubes": [
					{
						"origin": [-8, 0, -8],
						"size": [16, 16, 16],
						"uv": {
							"north": {"uv": [0, 0], "uv_size": [16, 16]},
							"east": {"uv": [0, 0], "uv_size": [16, 16]},
							"south": {"uv": [0, 0], "uv_size": [16, 16]},
							"west": {"uv": [0, 0], "uv_size": [16, 16]},
							"up": {"uv": [16, 16], "uv_size": [-16, -16]},
							"down": {"uv": [16, 16], "uv_size": [-16, -16]}
						}
					}
				]
			}
		]
	}`
};

skin_presets.allay = {
	display_name: 'Allay',
	model: `{
		"name": "allay",
		"external_textures": ["entity/allay/allay.png"],
		"texturewidth": 32,
		"textureheight": 32,
		"eyes": [
			[6, 7, 1, 2],
			[8, 7, 1, 2]
		],
		"bones": [
			{
				"name": "root",
				"pivot": [0, 0, 0]
			},
			{
				"name": "head",
				"parent": "root",
				"pivot": [0, 4, 0],
				"cubes": [
					{"origin": [-2.5, 4.01, -2.5], "size": [5, 5, 5], "uv": [0, 0]}
				]
			},
			{
				"name": "body",
				"parent": "root",
				"pivot": [0, 4, 0],
				"cubes": [
					{"origin": [-1.5, 0, -1], "size": [3, 4, 2], "uv": [0, 10]},
					{"origin": [-1.5, -1, -1], "size": [3, 5, 2], "inflate": -0.2, "uv": [0, 16]}
				]
			},
			{
				"name": "rightItem",
				"parent": "body",
				"pivot": [0, -1, -2],
				"rotation": [-80, 0, 0]
			},
			{
				"name": "right_arm",
				"parent": "body",
				"pivot": [-1.75, 3.5, 0],
				"cubes": [
					{"origin": [-2.5, 0, -1], "size": [1, 4, 2], "uv": [23, 0]}
				]
			},
			{
				"name": "left_arm",
				"parent": "body",
				"pivot": [1.75, 3.5, 0],
				"cubes": [
					{"origin": [1.5, 0, -1], "size": [1, 4, 2], "uv": [23, 6]}
				]
			},
			{
				"name": "left_wing",
				"parent": "body",
				"pivot": [0.5, 3, 1],
				"cubes": [
					{"origin": [0.5, -2, 1], "size": [0, 5, 8], "uv": [16, 14], "mirror": true}
				]
			},
			{
				"name": "right_wing",
				"parent": "body",
				"pivot": [-0.5, 3, 1],
				"cubes": [
					{"origin": [-0.5, -2, 1], "size": [0, 5, 8], "uv": [16, 14]}
				]
			}
		]
	}`
}
skin_presets.armadillo = {
	display_name: 'Armadillo',
	model: `{
		"name": "armadillo",
		"external_textures": ["entity/armadillo.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"eyes": [
			[44, 19, 1, 1],
			[48, 19, 1, 1]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [0, 3, 4],
				"cubes": [
					{"origin": [-4, 2, -6], "size": [8, 8, 12], "inflate": 0.3, "uv": [0, 20]},
					{"origin": [-4, 2, -6], "size": [8, 8, 12], "uv": [0, 40]}
				]
			},
			{
				"name": "tail",
				"parent": "body",
				"pivot": [0, 6, 5],
				"rotation": [29, 0, 0],
				"cubes": [
					{"origin": [-0.5, 0.08645, 5.09326], "size": [1, 6, 1], "uv": [44, 53]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 5, -7],
				"cubes": [
					{"origin": [-1.5, 1, -8], "size": [3, 5, 2], "pivot": [0, 5, -7], "rotation": [-22.5, 0, 0], "uv": [43, 15]}
				]
			},
			{
				"name": "right_ear",
				"parent": "head",
				"pivot": [-1, 6, -7],
				"cubes": [
					{"origin": [-3.5, 4, -7.6], "size": [2, 5, 0], "pivot": [-1.5, 6, -7.6], "rotation": [10.80524, -22.13991, -4.11405], "uv": [43, 10]}
				]
			},
			{
				"name": "left_ear",
				"parent": "head",
				"pivot": [1, 7, -7],
				"cubes": [
					{"origin": [1.5, 4, -7.6], "size": [2, 5, 0], "pivot": [1.5, 6, -7.6], "rotation": [10.80524, 22.13991, 4.11405], "uv": [47, 10]}
				]
			},
			{
				"name": "right_hind_leg",
				"pivot": [-2, 3, 4],
				"cubes": [
					{"origin": [-3, 0, 3], "size": [2, 3, 2], "uv": [51, 31]}
				]
			},
			{
				"name": "left_hind_leg",
				"pivot": [2, 3, 4],
				"cubes": [
					{"origin": [1, 0, 3], "size": [2, 3, 2], "uv": [42, 31]}
				]
			},
			{
				"name": "right_front_leg",
				"pivot": [-2, 3, -4],
				"cubes": [
					{"origin": [-3, 0, -5], "size": [2, 3, 2], "uv": [51, 43]}
				]
			},
			{
				"name": "left_front_leg",
				"pivot": [2, 3, -4],
				"cubes": [
					{"origin": [1, 0, -5], "size": [2, 3, 2], "uv": [42, 43]}
				]
			},
			{
				"name": "body_rolled_up",
				"pivot": [0, 0, 27],
				"cubes": [
					{"origin": [-5, 0, 21], "size": [10, 10, 10], "uv": [0, 0]}
				]
			}
		]
	}`
}
skin_presets.armadillo_baby = {
	display_name: 'Armadillo Baby',
	model: `{
		"name": "armadillo_baby",
		"texturewidth": 64,
		"textureheight": 64,
		"external_textures": ["entity/armadillo/armadillo_baby.png"],
		"eyes": [
			[22, 21, 1, 1],
			[27, 21, 1, 1]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [0, 4, 0.5],
				"cubes": [
					{"origin": [-2.5, 2, -3], "size": [5, 4, 7], "inflate": 0.3, "uv": [0, 0]},
					{"origin": [-2.5, 2, -2.5], "size": [5, 4, 6], "uv": [0, 11]}
				]
			},
			{
				"name": "tail",
				"parent": "body",
				"pivot": [0, 4, 3.9],
				"cubes": [
					{"origin": [-0.5, 2, 2.9], "size": [1, 1, 4], "pivot": [0, 2.5, 4.9], "rotation": [-60, 0, 0], "uv": [22, 11]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 4, -2.7],
				"cubes": [
					{"origin": [-1, 4, -6.7], "size": [2, 2, 4], "pivot": [1, 4, -2.7], "rotation": [42.5, 0, 0], "uv": [20, 17]}
				]
			},
			{
				"name": "right_ear",
				"parent": "head",
				"pivot": [-1, 5, -4.75],
				"rotation": [25, -6.5, -3],
				"cubes": [
					{"origin": [-2.9, 4, -4.5], "size": [2, 3, 0], "uv": [28, 8], "mirror": true}
				]
			},
			{
				"name": "left_ear",
				"parent": "head",
				"pivot": [0.9, 5.1957, -4.75],
				"rotation": [25, 6.5, 3],
				"cubes": [
					{"origin": [0.9, 4, -4.5], "size": [2, 3, 0], "uv": [28, 8]}
				]
			},
			{
				"name": "right_hind_leg",
				"pivot": [-1.5, 2, 2.5],
				"cubes": [
					{"origin": [-2.5, 0, 1.5], "size": [2, 2, 2], "uv": [20, 27], "mirror": true}
				]
			},
			{
				"name": "left_hind_leg",
				"pivot": [1.5, 2, 2.5],
				"cubes": [
					{"origin": [0.5, 0, 1.5], "size": [2, 2, 2], "uv": [24, 4]}
				]
			},
			{
				"name": "right_front_leg",
				"pivot": [1.5, 2, -1.5],
				"cubes": [
					{"origin": [0.5, 0, -2.5], "size": [2, 2, 2], "uv": [20, 23]}
				]
			},
			{
				"name": "left_front_leg",
				"pivot": [-1.5, 2, -1.5],
				"cubes": [
					{"origin": [-2.5, 0, -2.5], "size": [2, 2, 2], "uv": [24, 0], "mirror": true}
				]
			},
			{
				"name": "body_rolled_up",
				"pivot": [0, 3.3, 16.5],
				"cubes": [
					{"origin": [-3, 0.3, 13.5], "size": [6, 6, 6], "inflate": 0.3, "uv": [0, 25]}
				]
			}
		]
	}`
}
skin_presets.armor_main = {
	display_name: 'Armor (Main)',
	pose: true,
	model: `{
		"name": "armor_main",
		"external_textures": ["models/armor/iron_1.png"],
		"texturewidth": 64,
		"textureheight": 32,
		"bones": [
			{
				"name": "Head",
				"color": 1,
				"pivot": [0, 24, 0],
				"pose": [-6, 5, 0],
				"cubes": [
					{"name": "Helmet", "origin": [-4, 24, -4], "size": [8, 8, 8], "uv": [0, 0], "inflate": 1},
					{"name": "Hat Layer", "visibility": false, "origin": [-4, 24, -4], "size": [8, 8, 8], "uv": [32, 0], "inflate": 1.5, "layer": true}
				]
			},
			{
				"name": "Body",
				"color": 3,
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "Chestplate", "origin": [-4, 12, -2], "size": [8, 12, 4], "uv": [16, 16], "inflate": 1.01}
				]
			},
			{
				"name": "Right Arm",
				"color": 5,
				"pivot": [-5, 22, 0],
				"pose": [-10, 0, 0],
				"cubes": [
					{"name": "Right Arm Armor", "origin": [-8, 12, -2], "size": [4, 12, 4], "uv": [40, 16], "inflate": 1}
				]
			},
			{
				"name": "Left Arm",
				"color": 0,
				"pivot": [5, 22, 0],
				"pose": [12, 0, 0],
				"cubes": [
					{"name": "Left Arm Armor", "origin": [4, 12, -2], "size": [4, 12, 4], "uv": [40, 16], "inflate": 1, "mirror": true}
				]
			},
			{
				"name": "Right Leg",
				"color": 6,
				"pivot": [-1.9, 12, 0],
				"pose": [11, 0, 2],
				"cubes": [
					{"name": "Right Boot", "origin": [-3.9, 0, -2], "size": [4, 12, 4], "uv": [0, 16], "inflate": 1.0}
				]
			},
			{
				"name": "Left Leg",
				"color": 7,
				"pivot": [1.9, 12, 0],
				"pose": [-10, 0, -2],
				"cubes": [
					{"name": "Left Boot", "origin": [-0.1, 0, -2], "size": [4, 12, 4], "uv": [0, 16], "inflate": 1.0, "mirror": true}
				]
			}
		]
	}`
};
skin_presets.armor_leggings = {
	display_name: 'Armor (Leggings)',
	pose: true,
	model: `{
		"name": "armor_leggings",
		"external_textures": ["models/armor/iron_2.png"],
		"texturewidth": 64,
		"textureheight": 32,
		"bones": [
			{
				"name": "Body",
				"color": 3,
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "Belt", "origin": [-4, 12, -2], "size": [8, 12, 4], "uv": [16, 16], "inflate": 0.51}
				]
			},
			{
				"name": "Right Leg",
				"color": 6,
				"pivot": [-1.9, 12, 0],
				"pose": [11, 0, 2],
				"cubes": [
					{"name": "Right Leg Armor", "origin": [-3.9, 0, -2], "size": [4, 12, 4], "uv": [0, 16], "inflate": 0.5}
				]
			},
			{
				"name": "Left Leg",
				"color": 7,
				"pivot": [1.9, 12, 0],
				"pose": [-10, 0, -2],
				"cubes": [
					{"name": "Left Leg Armor", "origin": [-0.1, 0, -2], "size": [4, 12, 4], "uv": [0, 16], "inflate": 0.5, "mirror": true}
				]
			}
		]
	}`
};
skin_presets.armor_baby = {
	display_name: 'Armor (Baby)',
	pose: true,
	model: `{
		"name": "humanoid_baby.armor.boots",
		"texturewidth": 64,
		"textureheight": 64,
		"external_textures": ["models/armor/diamond_baby.png"],
		"bones": [
			{
				"name": "Body",
				"pivot": [0, 6, -1],
				"cubes": [
					{"origin": [-3, 4, -1], "size": [6, 5, 3], "inflate": 0.3, "uv": [0, 17], "name": "Body Chestplate"},
					{"origin": [-3, 4, -1], "size": [6, 5, 3], "inflate": 0.27, "uv": [0, 33], "name": "Body Legging"}
				]
			},
			{
				"name": "Head",
				"pivot": [0, 9, 0.5],
				"cubes": [
					{"origin": [-4.5, 9, -4], "size": [9, 8, 8.3], "inflate": 0.3, "uv": [0, 0]}
				]
			},
			{
				"name": "LeftLeg",
				"pivot": [1.5, 4, 0.5],
				"cubes": [
					{"origin": [0, 0.2, -1.002], "size": [3, 1, 3], "inflate": 0.5, "uv": [0, 29], "name": "LeftLeg Boot"},
					{"origin": [0, 0.2, -1.002], "size": [3, 4, 3], "inflate": 0.3, "uv": [18, 24], "name": "LeftLeg Legging"}
				]
			},
			{
				"name": "RightLeg",
				"pivot": [-1.5, 4, 0.5],
				"cubes": [
					{"origin": [-3, 0.21, -1.004], "size": [3, 1, 3], "inflate": 0.5, "uv": [0, 25], "mirror": true, "name": "RightLeg Boot"},
					{"origin": [-3, 0.2, -1], "size": [3, 4, 3], "inflate": 0.3, "uv": [18, 17], "name": "RightLeg Legging"}
				]
			},
			{
				"name": "RightArm",
				"pivot": [-4, 9, 0.5],
				"cubes": [
					{"origin": [-5, 4.3, -0.97], "size": [2, 5, 3], "inflate": 0.3, "uv": [30, 25]}
				]
			},
			{
				"name": "LeftArm",
				"pivot": [4, 9, 0.5],
				"cubes": [
					{"origin": [3, 4.3, -1.03], "size": [2, 5, 3], "inflate": 0.3, "uv": [30, 17]}
				]
			}
		]
	}`
};
skin_presets.armor_stand = {
	display_name: 'Armor Stand',
	model: `{
		"name": "armor_stand",
		"external_textures": ["entity/armor_stand.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "Baseplate",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "baseplate", "origin": [-6, 0, -6], "size": [12, 1, 12], "uv": [0, 32]}
				]
			},
			{
				"name": "Waist",
				"parent": "baseplate",
				"pivot": [0, 12, 0]
			},
			{
				"name": "Body",
				"parent": "waist",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "body", "origin": [-6, 21, -1.5], "size": [12, 3, 3], "uv": [0, 26]},
					{"name": "body", "origin": [-3, 14, -1], "size": [2, 7, 2], "uv": [16, 0]},
					{"name": "body", "origin": [1, 14, -1], "size": [2, 7, 2], "uv": [48, 16]},
					{"name": "body", "origin": [-4, 12, -1], "size": [8, 2, 2], "uv": [0, 48]}
				]
			},
			{
				"name": "Head",
				"parent": "body",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "head", "origin": [-1, 24, -1], "size": [2, 7, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "LeftArm",
				"parent": "body",
				"pivot": [5, 22, 0],
				"mirror": true,
				"cubes": [
					{"name": "LeftArm", "origin": [5, 12, -1], "size": [2, 12, 2], "uv": [32, 16]}
				]
			},
			{
				"name": "LeftLeg",
				"parent": "body",
				"pivot": [1.9, 12, 0],
				"mirror": true,
				"cubes": [
					{"name": "LeftLeg", "origin": [0.9, 1, -1], "size": [2, 11, 2], "uv": [40, 16]}
				]
			},
			{
				"name": "RightArm",
				"parent": "body",
				"pivot": [-5, 22, 0],
				"cubes": [
					{"name": "RightArm", "origin": [-7, 12, -1], "size": [2, 12, 2], "uv": [24, 0]}
				]
			},
			{
				"name": "RightLeg",
				"parent": "body",
				"pivot": [-1.9, 12, 0],
				"cubes": [
					{"name": "RightLeg", "origin": [-2.9, 1, -1], "size": [2, 11, 2], "uv": [8, 0]}
				]
			}
		]
	}`
};
skin_presets.axolotl = {
	display_name: 'Axolotl',
	model: `{
		"name": "axolotl",
		"external_textures": ["entity/axolotl/axolotl_lucy.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"eyes": [
			[4, 8, 2, 1],
			[12, 8, 2, 1]
		],
		"bones": [
			{
				"name": "root",
				"pivot": [0, -4, 0]
			},
			{
				"name": "body",
				"parent": "root",
				"pivot": [0, 3, 4],
				"cubes": [
					{"origin": [-4, 0, -5], "size": [8, 4, 10], "uv": [0, 11]},
					{"origin": [0, 0, -5], "size": [0, 5, 9], "uv": [2, 17]}
				]
			},
			{
				"name": "right_arm",
				"parent": "body",
				"pivot": [-4, 1, -4],
				"rotation": [0, -90, 90],
				"cubes": [
					{"origin": [-6, -4, -4], "size": [3, 5, 0], "uv": [2, 13]}
				]
			},
			{
				"name": "right_leg",
				"parent": "body",
				"pivot": [-4, 1, 4],
				"rotation": [0, 90, 90],
				"cubes": [
					{"origin": [-5, -4, 4], "size": [3, 5, 0], "uv": [2, 13]}
				]
			},
			{
				"name": "left_arm",
				"parent": "body",
				"pivot": [4, 1, -4],
				"rotation": [0, 90, -90],
				"cubes": [
					{"origin": [3, -4, -4], "size": [3, 5, 0], "uv": [2, 13]}
				]
			},
			{
				"name": "left_leg",
				"parent": "body",
				"pivot": [4, 1, 4],
				"rotation": [0, -90, -90],
				"cubes": [
					{"origin": [2, -4, 4], "size": [3, 5, 0], "uv": [2, 13]}
				]
			},
			{
				"name": "tail",
				"parent": "body",
				"pivot": [0, 2, 4],
				"cubes": [
					{"origin": [0, 0, 4], "size": [0, 5, 12], "uv": [2, 19]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 2, -5],
				"reset": true,
				"cubes": [
					{"origin": [-4, 0, -10], "size": [8, 5, 5], "uv": [0, 1]}
				]
			},
			{
				"name": "left_gills",
				"parent": "head",
				"pivot": [4, 2, -6],
				"cubes": [
					{"origin": [4, 0, -6], "size": [3, 7, 0], "uv": [11, 40]}
				]
			},
			{
				"name": "right_gills",
				"parent": "head",
				"pivot": [-4, 2, -6],
				"cubes": [
					{"origin": [-7, 0, -6], "size": [3, 7, 0], "uv": [0, 40]}
				]
			},
			{
				"name": "top_gills",
				"parent": "head",
				"pivot": [0, 5, -6],
				"cubes": [
					{"origin": [-4, 5, -6], "size": [8, 3, 0], "uv": [3, 37]}
				]
			}
		]
	}`
};
skin_presets.axolotl_baby = {
	display_name: 'Axolotl Baby',
	model: `{
		"name": "axolotl_baby",
		"texturewidth": 32,
		"textureheight": 32,
		"external_textures": ["entity/axolotl/axolotl_lucy_baby.png"],
		"eyes": [
			[3, 13, 2, 1],
			[9, 13, 2, 1]
		],
		"bones": [
			{
				"name": "root",
				"pivot": [0, 0, 0]
			},
			{
				"name": "body",
				"parent": "root",
				"pivot": [0, 1.25, 1.75],
				"cubes": [
					{"origin": [-2, 0, -1], "size": [4, 2, 6], "uv": [0, 0]},
					{"origin": [0, 0, -1], "size": [0, 3, 5], "uv": [0, 12]}
				]
			},
			{
				"name": "right_arm",
				"parent": "body",
				"pivot": [-2, 1, 0.5],
				"cubes": [
					{"origin": [-5, 1, 0], "size": [3, 0, 1], "uv": [20, 16]}
				]
			},
			{
				"name": "right_leg",
				"parent": "body",
				"pivot": [-2, 1, 3.5],
				"rotation": [0, 90, 90],
				"cubes": [
					{"origin": [-2, 1, 3], "size": [3, 0, 1], "pivot": [-2, 1, 3.5], "rotation": [-90, 0, 90], "uv": [20, 14]}
				]
			},
			{
				"name": "left_arm",
				"parent": "body",
				"pivot": [2, 1, 0.5],
				"cubes": [
					{"origin": [2, 1, 0], "size": [3, 0, 1], "uv": [20, 13]}
				]
			},
			{
				"name": "left_leg",
				"parent": "body",
				"pivot": [2, 1, 3.5],
				"cubes": [
					{"origin": [2, 1, 3], "size": [3, 0, 1], "uv": [20, 14]}
				]
			},
			{
				"name": "tail",
				"parent": "body",
				"pivot": [0, 1.5, 5],
				"cubes": [
					{"origin": [0, 0, 4], "size": [0, 3, 8], "uv": [10, 9]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 1, -1],
				"cubes": [
					{"origin": [-3, 0, -5], "size": [6, 3, 4], "uv": [0, 8]}
				]
			},
			{
				"name": "left_gills",
				"parent": "head",
				"pivot": [3, 1.5, -3],
				"cubes": [
					{"origin": [3, 0, -3], "size": [3, 5, 0], "uv": [20, 8]}
				]
			},
			{
				"name": "right_gills",
				"parent": "head",
				"pivot": [-3, 1.5, -3],
				"cubes": [
					{"origin": [-6, 0, -3], "size": [3, 5, 0], "uv": [20, 3]}
				]
			},
			{
				"name": "top_gills",
				"parent": "head",
				"pivot": [0, 3, -3],
				"cubes": [
					{"origin": [-3, 3, -3], "size": [6, 3, 0], "uv": [20, 0]}
				]
			}
		]
	}`
};
skin_presets.bamboo_raft = {
	display_name: 'Bamboo Raft',
	model: `{
		"name": "",
		"external_textures": ["entity/boat/bamboo_raft.png"],
		"texturewidth": 128,
		"textureheight": 64,
		"bones": [
			{
				"name": "raft",
				"pivot": [0, 1, -2],
				"rotation": [90, -90, 0],
				"cubes": [
					{"origin": [-14, -11, 1], "size": [28, 20, 4], "uv": [0, 0]},
					{"origin": [-14, -9, -3], "size": [28, 16, 4], "uv": [0, 0]}
				]
			},
			{
				"name": "paddle_left",
				"pivot": [-11.5, 12, 1],
				"rotation": [-50, -75, 0],
				"cubes": [
					{"origin": [-12.5, 11, -4.5], "size": [2, 2, 18], "uv": [0, 24]},
					{"origin": [-12.51, 10, 8.5], "size": [1, 6, 7], "uv": [0, 24]}
				]
			},
			{
				"name": "paddle_right",
				"pivot": [7.5, 12, 0],
				"rotation": [-50, 75, 0],
				"cubes": [
					{"origin": [5.5, 11, -5.5], "size": [2, 2, 18], "uv": [40, 24]},
					{"origin": [6.51, 10, 7.5], "size": [1, 6, 7], "uv": [40, 24]}
				]
			}
		]
	}`
};
skin_presets.banner = {
	display_name: 'Banner',
	model: `{
		"name": "banner_base",
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "stand",
				"pivot": [0, 0, 0],
				"cubes": [
					{"origin": [-10, 42, 0], "size": [20, 2, 2], "uv": [0, 42]},
					{"origin": [-1, 0, 0], "size": [2, 42, 2], "uv": [44, 0]}
				]
			},
			{
				"name": "banner",
				"parent": "stand",
				"pivot": [0, 44, 0],
				"rotation": [-2, 0, 0],
				"cubes": [
					{"origin": [-10, 4, -1], "size": [20, 40, 1], "uv": [0, 0]}
				]
			}
		]
	}`
};
skin_presets.bat = {
	display_name: 'Bat',
	pose: true,
	variants: {	
		new: {
			name: 'New',
			model: `{
				"name": "bat_v2",
				"external_textures": ["entity/bat_v2.png"],
				"texturewidth": 32,
				"textureheight": 32,
				"eyes": [
					[1, 10, 2, 1],
					[5, 10, 2, 1]
				],
				"bones": [
					{
						"name": "Head",
						"pivot": [0, 7, 0],
						"cubes": [
							{"origin": [-2, 7, -1], "size": [4, 3, 2], "uv": [0, 7]}
						]
					},
					{
						"name": "rightEar",
						"parent": "Head",
						"pivot": [-1.5, 9, 0],
						"cubes": [
							{"origin": [-4, 8, 0], "size": [3, 5, 0], "uv": [1, 15]}
						]
					},
					{
						"name": "leftEar",
						"parent": "Head",
						"pivot": [1.1, 10, 0],
						"cubes": [
							{"origin": [1, 8, 0], "size": [3, 5, 0], "uv": [8, 15]}
						]
					},
					{
						"name": "body",
						"pivot": [0, 7, 0],
						"cubes": [
							{"origin": [-1.5, 2, -1], "size": [3, 5, 2], "uv": [0, 0]}
						]
					},
					{
						"name": "feet",
						"parent": "body",
						"pivot": [0, 2, 0],
						"cubes": [
							{"origin": [-1.5, 0, 0], "size": [3, 2, 0], "uv": [16, 16]}
						]
					},
					{
						"name": "rightWing",
						"parent": "body",
						"pivot": [-1.5, 7, 0],
						"cubes": [
							{"origin": [-3.5, 2, 0], "size": [2, 7, 0], "uv": [12, 0]}
						]
					},
					{
						"name": "rightWingTip",
						"parent": "rightWing",
						"pivot": [-3.5, 7, 0],
						"cubes": [
							{"origin": [-9.5, 1, 0], "size": [6, 8, 0], "uv": [16, 0]}
						]
					},
					{
						"name": "leftWing",
						"parent": "body",
						"pivot": [1.5, 7, 0],
						"cubes": [
							{"origin": [1.5, 2, 0], "size": [2, 7, 0], "uv": [12, 7]}
						]
					},
					{
						"name": "leftWingTip",
						"parent": "leftWing",
						"pivot": [3.5, 7, 0],
						"cubes": [
							{"origin": [3.5, 1, 0], "size": [6, 8, 0], "uv": [16, 8]}
						]
					}
				]
			}`
		},
		old: {
			name: 'Classic',
			model: `{
				"name": "bat",
				"external_textures": ["entity/bat.png"],
				"texturewidth": 64,
				"textureheight": 64,
				"bones": [
					{
						"name": "Head",
						"pivot": [0, 24, 0],
						"cubes": [
							{"name": "Head", "origin": [-3, 21, -3], "size": [6, 6, 6], "uv": [0, 0]}
						]
					},
					{
						"name": "rightEar",
						"parent": "Head",
						"pivot": [0, 24, 0],
						"cubes": [
							{"name": "rightEar", "origin": [-4, 26, -2], "size": [3, 4, 1], "uv": [24, 0]}
						]
					},
					{
						"name": "leftEar",
						"parent": "Head",
						"pivot": [0, 24, 0],
						"mirror": true,
						"cubes": [
							{"name": "leftEar", "origin": [1, 26, -2], "size": [3, 4, 1], "uv": [24, 0]}
						]
					},
					{
						"name": "body",
						"pivot": [0, 24, 0],
						"rotation": [30, 0, 0],
						"cubes": [
							{"name": "body", "origin": [-3, 8, -3], "size": [6, 12, 6], "uv": [0, 16]},
							{"name": "body", "origin": [-5, -8, 0], "size": [10, 16, 1], "uv": [0, 34]}
						]
					},
					{
						"name": "rightWing",
						"parent": "body",
						"pivot": [0, 24, 0],
						"pose": [0, -10, 0],
						"cubes": [
							{"name": "rightWing", "origin": [-12, 7, 1.5], "size": [10, 16, 1], "uv": [42, 0]}
						]
					},
					{
						"name": "rightWingTip",
						"parent": "rightWing",
						"pivot": [-12, 23, 1.5],
						"pose": [0, -15, 0],
						"cubes": [
							{"name": "rightWingTip", "origin": [-20, 10, 1.5], "size": [8, 12, 1], "uv": [24, 16]}
						]
					},
					{
						"name": "leftWing",
						"parent": "body",
						"pivot": [0, 24, 0],
						"pose": [0, 10, 0],
						"mirror": true,
						"cubes": [
							{"name": "leftWing", "origin": [2, 7, 1.5], "size": [10, 16, 1], "uv": [42, 0]}
						]
					},
					{
						"name": "leftWingTip",
						"parent": "leftWing",
						"pivot": [12, 23, 1.5],
						"pose": [0, 15, 0],
						"mirror": true,
						"cubes": [
							{"name": "leftWingTip", "origin": [12, 10, 1.5], "size": [8, 12, 1], "uv": [24, 16]}
						]
					}
				]
			}`
		},
	}
};
skin_presets.bed = {
	display_name: 'Bed',
	model_bedrock: `{
		"name": "bed",
		"external_textures": ["entity/bed/white.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "bed",
				"pivot": [0, 0, 0],
				"rotation": [-90, 0, 0],
				"cubes": [
					{"origin": [-8, -16, -9], "size": [16, 32, 6], "uv": [0, 0]},
					{"origin": [-8, -16, -3], "size": [3, 3, 3], "uv": [0, 44]},
					{"origin": [5, 13, -3], "size": [3, 3, 3], "uv": [12, 38]},
					{"origin": [-8, 13, -3], "size": [3, 3, 3], "uv": [0, 38]},
					{"origin": [5, -16, -3], "size": [3, 3, 3], "uv": [12, 44]}
				]
			},
			{
				"name": "Layer",
				"parent": "bed",
				"cubes": [
					{"origin": [-5, 15, -3], "size": [10, 1, 3], "uv": [38, 2], "layer": true},
					{"origin": [-5, -16, -3], "size": [10, 1, 3], "uv": [38, 38], "layer": true},
					{"origin": [7, -13, -3], "size": [1, 26, 3], "uv": [52, 6], "layer": true},
					{"origin": [-8, -13, -3], "size": [1, 26, 3], "uv": [44, 6], "layer": true}
				]
			}
		]
	}`,
	model_java: `{
		"name": "bed",
		"external_textures": ["entity/bed/white.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "bed",
				"pivot": [0, 0, 0],
				"rotation": [-90, 0, 0],
				"cubes": [
					{"origin": [-8, 0, -9], "size": [16, 16, 6], "uv": [0, 0]},
					{"origin": [-8, -16, -9], "size": [16, 16, 6], "uv": [0, 22]}
				]
			},
			{
				"name": "leg0",
				"pivot": [-6.5, 1.5, -14.5],
				"cubes": [
					{"origin": [-8, 0, -16], "size": [3, 3, 3], "uv": [50, 0]}
				]
			},
			{
				"name": "leg1",
				"pivot": [-6.5, 1.5, 14.5],
				"rotation": [0, 90, 0],
				"cubes": [
					{"origin": [-8, 0, 13], "size": [3, 3, 3], "uv": [50, 6]}
				]
			},
			{
				"name": "leg2",
				"pivot": [6.5, 1.5, -14.5],
				"rotation": [0, -90, 0],
				"cubes": [
					{"origin": [5, 0, -16], "size": [3, 3, 3], "uv": [50, 12]}
				]
			},
			{
				"name": "leg3",
				"pivot": [6.5, 1.5, 14.5],
				"rotation": [0, 180, 0],
				"cubes": [
					{"origin": [5, 0, 13], "size": [3, 3, 3], "uv": [50, 18]}
				]
			}
		]
	}`
};
skin_presets.bee = {
	display_name: 'Bee',
	model: `{
		"name": "bee",
		"external_textures": ["entity/bee/bee.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"eyes": [
			[10, 13, 2, 3],
			[15, 13, 2, 3]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [0.5, 5, 0],
				"cubes": [
					{"name": "body", "origin": [-3, 2, -5], "size": [7, 7, 10], "uv": [0, 0]},
					{"name": "body", "origin": [-2, 7, -8], "size": [1, 2, 3], "uv": [2, 3]},
					{"name": "body", "origin": [2, 7, -8], "size": [1, 2, 3], "uv": [2, 0]}
				]
			},
			{
				"name": "stinger",
				"parent": "body",
				"pivot": [0.5, 6, 1],
				"cubes": [
					{"name": "stinger", "origin": [0.5, 5, 5], "size": [0, 1, 2], "uv": [26, 7]}
				]
			},
			{
				"name": "rightwing_bone",
				"parent": "body",
				"pivot": [-1, 9, -3],
				"rotation": [15, -15, 0],
				"cubes": [
					{"name": "rightwing_bone", "origin": [-10, 9, -3], "size": [9, 0, 6], "uv": [0, 18]}
				]
			},
			{
				"name": "leftwing_bone",
				"parent": "body",
				"pivot": [2, 9, -3],
				"rotation": [15, 15, 0],
				"cubes": [
					{"name": "leftwing_bone", "origin": [2, 9, -3], "size": [9, 0, 6], "uv": [9, 24]}
				]
			},
			{
				"name": "leg_front",
				"parent": "body",
				"pivot": [2, 2, -2],
				"cubes": [
					{"name": "leg_front", "origin": [-3, 0, -2], "size": [7, 2, 0], "uv": [26, 1]}
				]
			},
			{
				"name": "leg_mid",
				"parent": "body",
				"pivot": [2, 2, 0],
				"cubes": [
					{"name": "leg_mid", "origin": [-3, 0, 0], "size": [7, 2, 0], "uv": [26, 3]}
				]
			},
			{
				"name": "leg_back",
				"parent": "body",
				"pivot": [2, 2, 2],
				"cubes": [
					{"name": "leg_back", "origin": [-3, 0, 2], "size": [7, 2, 0], "uv": [26, 5]}
				]
			}
		]
	}`
};
skin_presets.bee_baby = {
	display_name: 'Bee Baby',
	model: `{
		"name": "bee_baby",
		"texturewidth": 32,
		"textureheight": 32,
		"external_textures": ["entity/bee/bee_baby.png"],
		"eyes": [
			[4, 7, 2, 2],
			[8, 7, 2, 2]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [0, 4.33333, -1.85667],
				"cubes": [
					{"origin": [-2, 1, -2], "size": [4, 4, 5], "uv": [0, 0]},
					{"origin": [1, 4, -4.02], "size": [1, 2, 2], "uv": [6, 12]},
					{"origin": [-2, 4, -4.05], "size": [1, 2, 2], "uv": [0, 12]}
				]
			},
			{
				"name": "stinger",
				"parent": "body",
				"pivot": [0, 2.5, 3],
				"cubes": [
					{"origin": [0, 2, 3], "size": [0, 1, 1], "uv": [13, 2]}
				]
			},
			{
				"name": "rightwing_bone",
				"parent": "body",
				"pivot": [-1, 5, -1],
				"rotation": [12.5, 20, 0],
				"cubes": [
					{"origin": [-4, 5, -1], "size": [3, 0, 3], "uv": [3, 9]}
				]
			},
			{
				"name": "leftwing_bone",
				"parent": "body",
				"pivot": [1, 5, -1],
				"rotation": [12.5, -20, 0],
				"cubes": [
					{"origin": [1, 5, -1], "size": [3, 0, 3], "uv": [-3, 9], "mirror": true}
				]
			},
			{
				"name": "leg_front",
				"parent": "body",
				"pivot": [0, 1, 0],
				"cubes": [
					{"origin": [-1.5, 0, 0], "size": [3, 1, 0], "uv": [13, 0]}
				]
			},
			{
				"name": "leg_mid",
				"parent": "body",
				"pivot": [0, 1, 1],
				"cubes": [
					{"origin": [-1.5, 0, 1], "size": [3, 1, 0], "uv": [13, 1]}
				]
			},
			{
				"name": "leg_back",
				"parent": "body",
				"pivot": [0, 1, 2],
				"cubes": [
					{"origin": [-1.5, 0, 2], "size": [3, 1, 0], "uv": [13, 2]}
				]
			}
		]
	}`
};
skin_presets.bell = {
	display_name: 'Bell',
	model: `{
		"name": "bell",
		"external_textures": ["entity/bell.png"],
		"texturewidth": 32,
		"textureheight": 32,
		"bones": [
			{
				"name": "bell",
				"pivot": [0, 11, 0],
				"cubes": [
					{"name": "cube", "origin": [-4, 2, -4], "size": [8, 2, 8], "uv": [0, 13]},
					{"name": "cube", "origin": [-3, 4, -3], "size": [6, 7, 6], "uv": [0, 0]}
				]
			}
		]
	}`
};
skin_presets.blaze = {
	display_name: 'Blaze',
	model: `{
		"name": "blaze",
		"texturewidth": 64,
		"textureheight": 32,
		"eyes": [
			[9, 11],
			[13, 11]
		],
		"bones": [
			{
				"name": "upperBodyParts0",
				"pivot": [8, 26, -3],
				"cubes": [
					{"name": "upperBodyParts0", "origin": [8, 18, -3], "size": [2, 8, 2], "uv": [0, 16]}
				]
			},
			{
				"name": "upperBodyParts1",
				"pivot": [-10, 26, 1],
				"cubes": [
					{"name": "upperBodyParts1", "origin": [-10, 18, 1], "size": [2, 8, 2], "uv": [0, 16]}
				]
			},
			{
				"name": "upperBodyParts2",
				"pivot": [1, 26, 8],
				"cubes": [
					{"name": "upperBodyParts2", "origin": [1, 18, 8], "size": [2, 8, 2], "uv": [0, 16]}
				]
			},
			{
				"name": "upperBodyParts3",
				"pivot": [-3, 26, -10],
				"cubes": [
					{"name": "upperBodyParts3", "origin": [-3, 18, -10], "size": [2, 8, 2], "uv": [0, 16]}
				]
			},
			{
				"name": "upperBodyParts4",
				"pivot": [5, 18, -1],
				"cubes": [
					{"name": "upperBodyParts4", "origin": [5, 10, -1], "size": [2, 8, 2], "uv": [0, 16]}
				]
			},
			{
				"name": "upperBodyParts5",
				"pivot": [-7, 18, -1],
				"cubes": [
					{"name": "upperBodyParts5", "origin": [-7, 10, -1], "size": [2, 8, 2], "uv": [0, 16]}
				]
			},
			{
				"name": "upperBodyParts6",
				"pivot": [-1, 18, 5],
				"cubes": [
					{"name": "upperBodyParts6", "origin": [-1, 10, 5], "size": [2, 8, 2], "uv": [0, 16]}
				]
			},
			{
				"name": "upperBodyParts7",
				"pivot": [-1, 18, -7],
				"cubes": [
					{"name": "upperBodyParts7", "origin": [-1, 10, -7], "size": [2, 8, 2], "uv": [0, 16]}
				]
			},
			{
				"name": "upperBodyParts8",
				"pivot": [3, 8, 2],
				"cubes": [
					{"name": "upperBodyParts8", "origin": [3, 0, 2], "size": [2, 8, 2], "uv": [0, 16]}
				]
			},
			{
				"name": "upperBodyParts9",
				"pivot": [-5, 8, -4],
				"cubes": [
					{"name": "upperBodyParts9", "origin": [-5, 0, -4], "size": [2, 8, 2], "uv": [0, 16]}
				]
			},
			{
				"name": "upperBodyParts10",
				"pivot": [-4, 8, 3],
				"cubes": [
					{"name": "upperBodyParts10", "origin": [-4, 0, 3], "size": [2, 8, 2], "uv": [0, 16]}
				]
			},
			{
				"name": "upperBodyParts11",
				"pivot": [2, 8, -5],
				"cubes": [
					{"name": "upperBodyParts11", "origin": [2, 0, -5], "size": [2, 8, 2], "uv": [0, 16]}
				]
			},
			{
				"name": "Head",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "Head", "origin": [-4, 20, -4], "size": [8, 8, 8], "uv": [0, 0]}
				]
			}
		]
	}`
};
skin_presets.boat = {
	display_name: 'Boat',
	model: `{
		"name": "boat",
		"external_textures": ["entity/boat/boat_oak.png"],
		"texturewidth": 128,
		"textureheight": 64,
		"bones": [
			{
				"name": "bottom",
				"pivot": [0, 18, 0],
				"rotation": [90, 0, 0],
				"mirror": true,
				"cubes": [
					{"name": "bottom", "origin": [-14, 10, 0], "size": [28, 16, 3], "uv": [0, 0]}
				]
			},
			{
				"name": "front",
				"pivot": [15, 24, 0],
				"rotation": [0, 90, 0],
				"mirror": true,
				"cubes": [
					{"name": "front", "origin": [7, 21, -1], "size": [16, 6, 2], "uv": [0, 27]}
				]
			},
			{
				"name": "back",
				"pivot": [-15, 24, 0],
				"rotation": [0, -90, 0],
				"mirror": true,
				"cubes": [
					{"name": "back", "origin": [-24, 21, -1], "size": [18, 6, 2], "uv": [0, 19]}
				]
			},
			{
				"name": "right",
				"pivot": [0, 24, -9],
				"rotation": [0, -180, 0],
				"mirror": true,
				"cubes": [
					{"name": "right", "origin": [-14, 21, -10], "size": [28, 6, 2], "uv": [0, 35]}
				]
			},
			{
				"name": "left",
				"pivot": [0, 24, 9],
				"mirror": true,
				"cubes": [
					{"name": "left", "origin": [-14, 21, 8], "size": [28, 6, 2], "uv": [0, 43]}
				]
			},
			{
				"name": "paddle_left",
				"pivot": [-2.5, 28, 9],
				"rotation": [-30, 0, 0],
				"mirror": true,
				"cubes": [
					{"name": "paddle_left", "origin": [-3.5, 27, 3.5], "size": [2, 2, 18], "uv": [62, 0]},
					{"name": "paddle_left", "origin": [-2.51, 26, 17.5], "size": [1, 6, 7], "uv": [62, 0]}
				]
			},
			{
				"name": "paddle_right",
				"pivot": [-2.5, 28, -9],
				"rotation": [-30, 180, 0],
				"mirror": true,
				"cubes": [
					{"name": "paddle_right", "origin": [-3.5, 27, -14.5], "size": [2, 2, 18], "uv": [62, 20]},
					{"name": "paddle_right", "origin": [-3.49, 26, -0.5], "size": [1, 6, 7], "uv": [62, 20]}
				]
			}
		]
	}`
};
skin_presets.bogged = {
	display_name: 'Bogged',
	model: `{
		"name": "bogged",
		"external_textures": ["entity/skeleton/bogged.png"],
		"texturewidth": 64,
		"textureheight": 32,
		"eyes": [
			[9, 12, 2, 1],
			[13, 12, 2, 1]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [0, 24, 0],
				"cubes": [
					{"origin": [-4, 12, -2], "size": [8, 12, 4], "uv": [16, 16]}
				]
			},
			{
				"name": "waist",
				"pivot": [0, 12, 0]
			},
			{
				"name": "head",
				"pivot": [0, 24, 0],
				"cubes": [
					{"origin": [-4, 24, -4], "size": [8, 8, 8], "uv": [0, 0]}
				]
			},
			{
				"name": "mushrooms",
				"parent": "head",
				"pivot": [3, 31.5, 3],
				"cubes": [
					{"origin": [-6, 31, -3], "size": [6, 4, 0], "pivot": [-3, 32.5, -3], "rotation": [0, -45, 0], "uv": [50, 22]},
					{"origin": [-6, 31, -3], "size": [6, 4, 0], "pivot": [-3, 32.5, -3], "rotation": [0, 45, 0], "uv": [50, 22]},
					{"origin": [0, 31, 3], "size": [6, 4, 0], "pivot": [3, 31.5, 3], "rotation": [0, 45, 0], "uv": [50, 16]},
					{"origin": [0, 31, 3], "size": [6, 4, 0], "pivot": [3, 31.5, 3], "rotation": [0, -45, 0], "uv": [50, 16]},
					{"origin": [-5, 25, 3], "size": [6, 5, 0], "pivot": [-2, 25, 3], "rotation": [-90, 0, 45], "uv": [50, 27]},
					{"origin": [-5, 25, 3], "size": [6, 5, 0], "pivot": [-2, 25, 3], "rotation": [-90, 0, 135], "uv": [50, 27]}
				]
			},
			{
				"name": "hat",
				"pivot": [0, 24, 0],
				"cubes": [
					{"origin": [-4, 24, -4], "size": [8, 8, 8], "inflate": 0.2, "uv": [32, 0], "layer": true}
				]
			},
			{
				"name": "rightArm",
				"pivot": [-5, 22, 0],
				"cubes": [
					{"origin": [-6, 12, -1], "size": [2, 12, 2], "uv": [40, 16]}
				]
			},
			{
				"name": "rightItem",
				"parent": "rightArm",
				"pivot": [-6, 15, 1]
			},
			{
				"name": "leftArm",
				"pivot": [5, 22, 0],
				"mirror": true,
				"cubes": [
					{"origin": [4, 12, -1], "size": [2, 12, 2], "uv": [40, 16], "mirror": true}
				]
			},
			{
				"name": "leftItem",
				"parent": "leftArm",
				"pivot": [6, 15, 1]
			},
			{
				"name": "rightLeg",
				"pivot": [-2, 12, 0],
				"cubes": [
					{"origin": [-3, 0, -1], "size": [2, 12, 2], "uv": [0, 16]}
				]
			},
			{
				"name": "leftLeg",
				"pivot": [2, 12, 0],
				"mirror": true,
				"cubes": [
					{"origin": [1, 0, -1], "size": [2, 12, 2], "uv": [0, 16], "mirror": true}
				]
			}
		]
	}`
};
skin_presets.bogged_layer = {
	display_name: 'Bogged/Stray Layer',
	model: `{
		"name": "bogged_layer",
		"external_textures": ["entity/skeleton/bogged_clothes.png"],
		"texturewidth": 64,
		"textureheight": 32,
		"eyes": [
			[9, 12, 2, 1],
			[13, 12, 2, 1]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [0, 24, 0],
				"cubes": [
					{"origin": [-4, 12, -2], "size": [8, 12, 4], "uv": [16, 16]}
				]
			},
			{
				"name": "leftArm",
				"parent": "body",
				"pivot": [5, 22, 0],
				"mirror": true,
				"cubes": [
					{"origin": [4, 12, -2], "size": [4, 12, 4], "uv": [40, 16], "mirror": true}
				]
			},
			{
				"name": "head",
				"pivot": [0, 24, 0],
				"cubes": [
					{"origin": [-4, 24, -4], "size": [8, 8, 8], "uv": [0, 0]}
				]
			},
			{
				"name": "hat",
				"pivot": [0, 24, 0],
				"cubes": [
					{"origin": [-4, 24, -4], "size": [8, 8, 8], "inflate": 0.5, "uv": [32, 0], "layer": true, "visibility": false}
				]
			},
			{
				"name": "rightArm",
				"pivot": [-5, 22, 0],
				"cubes": [
					{"origin": [-8, 12, -2], "size": [4, 12, 4], "uv": [40, 16]}
				]
			},
			{
				"name": "rightLeg",
				"pivot": [-1.9, 12, 0],
				"cubes": [
					{"origin": [-3.9, 0, -2], "size": [4, 12, 4], "uv": [0, 16]}
				]
			},
			{
				"name": "leftLeg",
				"pivot": [1.9, 12, 0],
				"mirror": true,
				"cubes": [
					{"origin": [-0.1, 0, -2], "size": [4, 12, 4], "uv": [0, 16], "mirror": true}
				]
			}
		]
	}`
};
skin_presets.breeze = {
	display_name: 'Breeze',
	model: `{
		"name": "breeze",
		"external_textures": ["entity/breeze/breeze.png"],
		"texturewidth": 32,
		"textureheight": 32,
		"eyes": [
			[7, 14, 3, 1],
			[14, 14, 3, 1],
			[6, 29, 5, 1],
			[15, 29, 5, 1]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [0, 0, 0]
			},
			{
				"name": "rods",
				"parent": "body",
				"pivot": [0, 16, 0],
				"cubes": [
					{"origin": [-1, 11, -6], "size": [2, 8, 2], "pivot": [0, 19, -3], "rotation": [22.5, 0, 0], "uv": [0, 17]},
					{"origin": [-3.59808, 11, -1.5], "size": [2, 8, 2], "pivot": [-2.59808, 19, 1.5], "rotation": [-157.5, 60, 180], "uv": [0, 17]},
					{"origin": [1.59808, 11, -1.5], "size": [2, 8, 2], "pivot": [2.59808, 19, 1.5], "rotation": [-157.5, -60, 180], "uv": [0, 17]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 20, 0],
				"cubes": [
					{"origin": [-4, 20, -4], "size": [8, 8, 8], "uv": [0, 0]}
				]
			},
			{
				"name": "eyes",
				"parent": "head",
				"pivot": [0, 20, 0],
				"cubes": [
					{"origin": [-5, 22, -4.2], "size": [10, 3, 4], "uv": [4, 24], "layer": true}
				]
			}
		]
	}`
}
skin_presets.breeze_tornado = {
	display_name: 'Breeze Tornado',
	model: `{
		"name": "breeze_wind",
		"external_textures": ["entity/breeze/breeze_wind.png"],
		"texturewidth": 128,
		"textureheight": 128,
		"bones": [
			{
				"name": "tornado_body",
				"pivot": [0, 0, 0]
			},
			{
				"name": "tornado_bottom",
				"parent": "tornado_body",
				"pivot": [0, 0, 0],
				"cubes": [
					{"origin": [-2.5, 0, -2.5], "size": [5, 7, 5], "uv": [1, 83]}
				]
			},
			{
				"name": "tornado_mid",
				"parent": "tornado_bottom",
				"pivot": [0, 7, 0],
				"cubes": [
					{"origin": [-2.5, 7, -2.5], "size": [5, 6, 5], "uv": [49, 71]},
					{"origin": [-4, 7, -4], "size": [8, 6, 8], "uv": [78, 32]},
					{"origin": [-6, 7, -6], "size": [12, 6, 12], "uv": [74, 28]}
				]
			},
			{
				"name": "tornado_top",
				"parent": "tornado_mid",
				"pivot": [0, 13, 0],
				"cubes": [
					{"origin": [-2.5, 13, -2.5], "size": [5, 8, 5], "uv": [105, 57]},
					{"origin": [-6, 13, -6], "size": [12, 8, 12], "uv": [6, 6]},
					{"origin": [-9, 13, -9], "size": [18, 8, 18], "uv": [0, 0]}
				]
			}
		]
	}`
}
skin_presets.camel = {
	display_name: 'Camel',
	model: `{
		"name": "camel",
		"external_textures": ["entity/camel/camel.png"],
		"texturewidth": 128,
		"textureheight": 128,
		"eyes": [
			[26, 8, 3, 1],
			[34, 8, 3, 1]
		],
		"bones": [
			{
				"name": "root",
				"pivot": [0, 0, 0]
			},
			{
				"name": "body",
				"parent": "root",
				"pivot": [0.5, 20, 9.5],
				"cubes": [
					{"origin": [-7.5, 20, -14], "size": [15, 12, 27], "uv": [0, 25]}
				]
			},
			{
				"name": "saddle",
				"parent": "body",
				"pivot": [0.5, 20, 9.5],
				"cubes": [
					{"name": "saddle layer", "origin": [-4.5, 32, -6], "size": [9, 5, 11], "inflate": 0.1, "layer": true, "visibility": false, "uv": [74, 64]},
					{"name": "saddle layer", "origin": [-3.5, 37, -6], "size": [7, 3, 11], "inflate": 0.1, "layer": true, "visibility": false, "uv": [92, 114]},
					{"name": "saddle layer", "origin": [-7.5, 20, -14], "size": [15, 12, 27], "inflate": 0.1, "layer": true, "visibility": false, "uv": [0, 89]}
				]
			},
			{
				"name": "tail",
				"parent": "body",
				"pivot": [0, 29, 13],
				"cubes": [
					{"origin": [-1.5, 15, 13], "size": [3, 14, 0], "pivot": [0, 29, 13], "rotation": [0, 180, 0], "uv": [122, 0]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0.5, 25, -10],
				"cubes": [
					{"origin": [-3.5, 22, -25], "size": [7, 8, 19], "uv": [60, 24]},
					{"origin": [-3.5, 30, -25], "size": [7, 14, 7], "uv": [21, 0]},
					{"origin": [-2.5, 39, -31], "size": [5, 5, 6], "uv": [50, 0]}
				]
			},
			{
				"name": "bridle",
				"parent": "head",
				"pivot": [0.5, 25, -10],
				"cubes": [
					{"name": "bridle layer", "origin": [-3.5, 22, -25], "size": [7, 8, 19], "inflate": 0.1, "uv": [60, 87], "layer": true, "visibility": false},
					{"name": "bridle layer", "origin": [-3.5, 30, -25], "size": [7, 14, 7], "inflate": 0.1, "uv": [21, 64], "layer": true, "visibility": false},
					{"name": "bridle layer", "origin": [-2.5, 39, -31.1], "size": [5, 5, 6], "inflate": 0.1, "uv": [50, 64], "layer": true, "visibility": false},
					{"origin": [2.5, 40, -28], "size": [1, 2, 2], "uv": [74, 70]},
					{"origin": [-3.5, 40, -28], "size": [1, 2, 2], "uv": [74, 70], "mirror": true}
				]
			},
			{
				"name": "left_ear",
				"parent": "head",
				"pivot": [3, 43, -19.5],
				"cubes": [
					{"origin": [3, 42.5, -20.5], "size": [3, 1, 2], "uv": [45, 0]}
				]
			},
			{
				"name": "right_ear",
				"parent": "head",
				"pivot": [-3, 43, -19.5],
				"cubes": [
					{"origin": [-6, 42.5, -20.5], "size": [3, 1, 2], "uv": [67, 0]}
				]
			},
			{
				"name": "reins",
				"parent": "head",
				"pivot": [3.7, 41, -27],
				"cubes": [
					{"name": "reins layer", "origin": [3.7, 34, -27], "size": [0, 7, 15], "uv": [98, 42], "layer": true, "visibility": false},
					{"name": "reins layer", "origin": [-3.7, 34, -12], "size": [7.4, 7, 0], "uv": [84, 57], "layer": true, "visibility": false},
					{"name": "reins layer", "origin": [-3.7, 34, -27], "size": [0, 7, 15], "uv": [98, 42], "layer": true, "visibility": false}
				]
			},
			{
				"name": "hump",
				"parent": "body",
				"pivot": [0.5, 32, 0],
				"cubes": [
					{"origin": [-4.5, 32, -6], "size": [9, 5, 11], "uv": [74, 0]}
				]
			},
			{
				"name": "right_front_leg",
				"parent": "root",
				"pivot": [-4.9, 23, -10.5],
				"cubes": [
					{"origin": [-7.4, 0, -13], "size": [5, 21, 5], "uv": [0, 26]}
				]
			},
			{
				"name": "left_front_leg",
				"parent": "root",
				"pivot": [4.9, 23, -10.5],
				"cubes": [
					{"origin": [2.4, 0, -13], "size": [5, 21, 5], "uv": [0, 0]}
				]
			},
			{
				"name": "left_hind_leg",
				"parent": "root",
				"pivot": [4.9, 23, 9.5],
				"cubes": [
					{"origin": [2.4, 0, 7], "size": [5, 21, 5], "uv": [58, 16]}
				]
			},
			{
				"name": "right_hind_leg",
				"parent": "root",
				"pivot": [-4.9, 23, 9.5],
				"cubes": [
					{"origin": [-7.4, 0, 7], "size": [5, 21, 5], "uv": [94, 16]}
				]
			}
		]
	}`
};
skin_presets.camel_baby = {
	display_name: 'Camel Baby',
	model: `{
		"name": "camel_baby",
		"texturewidth": 64,
		"textureheight": 64,
		"external_textures": ["entity/camel/camel_baby.png"],
		"eyes": [
			[3, 6, 2, 1],
			[10, 6, 2, 1]
		],
		"bones": [
			{
				"name": "root",
				"pivot": [0, 0, 0]
			},
			{
				"name": "body",
				"parent": "root",
				"pivot": [0, 17, 0],
				"cubes": [
					{"origin": [-4.5, 13, -8], "size": [9, 8, 16], "uv": [0, 14]}
				]
			},
			{
				"name": "tail",
				"parent": "body",
				"pivot": [0, 18.5, 8.05],
				"cubes": [
					{"origin": [-1.5, 10, 8.05], "size": [3, 9, 0], "uv": [50, 38]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 16, -7.5],
				"cubes": [
					{"origin": [-2.5, 14, -15], "size": [5, 5, 7], "uv": [20, 0]},
					{"origin": [-2.5, 19, -15], "size": [5, 9, 5], "uv": [0, 0]},
					{"origin": [-2.5, 24, -18], "size": [5, 4, 3], "uv": [0, 14]}
				]
			},
			{
				"name": "right_ear",
				"parent": "head",
				"pivot": [-2.5, 27, -11.5],
				"cubes": [
					{"origin": [-5.5, 26.5, -12.5], "size": [3, 1, 2], "uv": [37, 0]}
				]
			},
			{
				"name": "left_ear",
				"parent": "head",
				"pivot": [2.5, 27, -11.5],
				"cubes": [
					{"origin": [2.5, 26.5, -12.5], "size": [3, 1, 2], "uv": [47, 0]}
				]
			},
			{
				"name": "right_front_leg",
				"parent": "root",
				"pivot": [-2.9, 12.5, -5.5],
				"cubes": [
					{"origin": [-4.4, 0, -7], "size": [3, 13, 3], "uv": [36, 14]}
				]
			},
			{
				"name": "left_front_leg",
				"parent": "root",
				"pivot": [2.9, 12.5, -5.5],
				"cubes": [
					{"origin": [1.4, 0, -7], "size": [3, 13, 3], "uv": [48, 14]}
				]
			},
			{
				"name": "left_hind_leg",
				"parent": "root",
				"pivot": [2.9, 12.5, 5.5],
				"cubes": [
					{"origin": [1.4, 0, 4], "size": [3, 13, 3], "uv": [12, 38]}
				]
			},
			{
				"name": "right_hind_leg",
				"parent": "root",
				"pivot": [-3, 12.5, 5.5],
				"cubes": [
					{"origin": [-4.4, 0, 4], "size": [3, 13, 3], "uv": [0, 38]}
				]
			}
		]
	}`
};
skin_presets.cat = {
	display_name: 'Cat',
	model: `{
		"name": "cat",
		"external_textures": ["entity/cat/calico.png"],
		"texturewidth": 64,
		"textureheight": 32,
		"bones": [
			{
				"name": "body",
				"pivot": [0, 7, 1]
			},
			{
				"name": "belly",
				"parent": "body",
				"pivot": [0, 7, 1],
				"rotation": [90, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-2, -1, -2], "size": [4, 16, 6], "uv": [20, 0]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 9, -9],
				"cubes": [
					{"name": "head", "origin": [-2.5, 7, -12], "size": [5, 4, 5], "uv": [0, 0]},
					{"name": "head", "origin": [-1.5, 7.01562, -13], "size": [3, 2, 2], "uv": [0, 24]},
					{"name": "head", "origin": [-2, 11, -9], "size": [1, 1, 2], "uv": [0, 10]},
					{"name": "head", "origin": [1, 11, -9], "size": [1, 1, 2], "uv": [6, 10]}
				]
			},
			{
				"name": "tail1",
				"parent": "body",
				"pivot": [0, 9, 8],
				"rotation": [45, 0, 0],
				"cubes": [
					{"name": "tail1", "origin": [-0.5, 1, 8], "size": [1, 8, 1], "uv": [0, 15]}
				]
			},
			{
				"name": "tail2",
				"parent": "tail1",
				"pivot": [0, 1, 8],
				"rotation": [45, 0, 0],
				"cubes": [
					{"name": "tail2", "origin": [-0.5, -7, 8], "size": [1, 8, 1], "uv": [4, 15]}
				]
			},
			{
				"name": "backLegL",
				"parent": "body",
				"pivot": [1.1, 6, 7],
				"cubes": [
					{"name": "backLegL", "origin": [0.1, 0, 6], "size": [2, 6, 2], "uv": [8, 13]}
				]
			},
			{
				"name": "backLegR",
				"parent": "body",
				"pivot": [-1.1, 6, 7],
				"cubes": [
					{"name": "backLegR", "origin": [-2.1, 0, 6], "size": [2, 6, 2], "uv": [8, 13]}
				]
			},
			{
				"name": "frontLegL",
				"parent": "body",
				"pivot": [1.2, 10, -4],
				"cubes": [
					{"name": "frontLegL", "origin": [0.2, 0.2, -5], "size": [2, 10, 2], "uv": [40, 0]}
				]
			},
			{
				"name": "frontLegR",
				"parent": "body",
				"pivot": [-1.2, 10, -4],
				"cubes": [
					{"name": "frontLegR", "origin": [-2.2, 0.2, -5], "size": [2, 10, 2], "uv": [40, 0]}
				]
			}
		]
	}`
};
skin_presets.cat_baby = {
	display_name: 'Kitten / Cat Baby',
	model: `{
		"name": "cat_baby",
		"texturewidth": 32,
		"textureheight": 32,
		"external_textures": ["entity/cat/calico_baby.png"],
		"eyes": [
			[5, 5, 1, 1],
			[7, 5, 1, 1]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [0, 0, 0]
			},
			{
				"name": "belly",
				"parent": "body",
				"pivot": [0, 3.5, 0.5],
				"cubes": [
					{"origin": [-2, 2, -3], "size": [4, 3, 7], "uv": [0, 8]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 4, -3.125],
				"cubes": [
					{"origin": [-2.5, 3, -6], "size": [5, 4, 4], "uv": [0, 0]},
					{"origin": [-2, 7, -4], "size": [1, 1, 2], "uv": [18, 0]},
					{"origin": [1, 7, -4], "size": [1, 1, 2], "uv": [24, 0]},
					{"origin": [-1.5, 3, -7], "size": [3, 2, 1], "uv": [18, 3]}
				]
			},
			{
				"name": "tail1",
				"parent": "body",
				"pivot": [0, 4.89303, 3.91511],
				"rotation": [-32.5, 0, 0],
				"cubes": [
					{"origin": [-0.5, 4, 4], "size": [1, 1, 5], "uv": [0, 18]}
				]
			},
			{
				"name": "backLegL",
				"parent": "body",
				"pivot": [1, 2, 2.5],
				"cubes": [
					{"origin": [0.5, 0, 1.5], "size": [1, 2, 2], "uv": [18, 22]}
				]
			},
			{
				"name": "backLegR",
				"parent": "body",
				"pivot": [-1, 2, 2.5],
				"cubes": [
					{"origin": [-1.5, 0, 1.5], "size": [1, 2, 2], "uv": [12, 22]}
				]
			},
			{
				"name": "frontLegL",
				"parent": "body",
				"pivot": [1, 2, -1.5],
				"cubes": [
					{"origin": [0.5, 0, -2.5], "size": [1, 2, 2], "uv": [18, 18]}
				]
			},
			{
				"name": "frontLegR",
				"parent": "body",
				"pivot": [-1, 2, -1.5],
				"cubes": [
					{"origin": [-1.5, 0, -2.5], "size": [1, 2, 2], "uv": [12, 18]}
				]
			}
		]
	}`
};
skin_presets.cape_elytra = {
	display_name: 'Cape + Elytra',
	model: `{
		"name": "cape and elytra",
		"external_textures": ["models/armor/elytra.png"],
		"texturewidth": 64,
		"textureheight": 32,
		"bones": [
			{
				"name": "cape",
				"pivot": [9, 24, 3],
				"rotation": [0, 180, 0],
				"cubes": [
					{"origin": [4, 8, 3], "size": [10, 16, 1], "uv": [0, 0]}
				]
			},
			{
				"name": "elytra",
				"pivot": [-18, 24, 1]
			},
			{
				"name": "left_wing",
				"parent": "elytra",
				"pivot": [-18, 4, 1],
				"cubes": [
					{"origin": [-18, 4, 1], "size": [10, 20, 2], "uv": [22, 0]}
				]
			},
			{
				"name": "right_wing",
				"parent": "elytra",
				"pivot": [-18, 4, 1],
				"mirror": true,
				"cubes": [
					{"origin": [-28, 4, 1], "size": [10, 20, 2], "uv": [22, 0], "mirror": true}
				]
			}
		]
	}`
};
skin_presets.chest = {
	display_name: 'Chest',
	model: `{
		"name": "chest",
		"external_textures": ["entity/chest/normal.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "chest",
				"pivot": [0, 8, 0],
				"rotation": [0, 0, -180],
				"cubes": [
					{"name": "cube", "origin": [-1, 5, 7], "size": [2, 4, 1], "uv": [0, 0]},
					{"name": "cube", "origin": [-7, 2, -7], "size": [14, 5, 14], "uv": [0, 0]},
					{"name": "cube", "origin": [-7, 6, -7], "size": [14, 10, 14], "uv": [0, 19]}
				]
			}
		]
	}`
};
skin_presets.chest_left = {
	display_name: 'Chest Left',
	model: `{
		"name": "chest_left",
		"external_textures": ["entity/chest/double_normal.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "chest",
				"pivot": [0, 8, 0],
				"rotation": [0, 0, -180],
				"cubes": [
					{"name": "cube", "origin": [-9, 5, 7], "size": [2, 4, 1], "uv": [0, 0]},
					{"name": "cube", "origin": [-8, 2, -7], "size": [15, 5, 14], "uv": [0, 0]},
					{"name": "cube", "origin": [-8, 6, -7], "size": [15, 10, 14], "uv": [0, 19]}
				]
			}
		]
	}`
};
skin_presets.chest_right = {
	display_name: 'Chest Right',
	model: `{
		"name": "chest_right",
		"external_textures": ["entity/chest/double_normal.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "chest",
				"pivot": [0, 8, 0],
				"rotation": [0, 0, -180],
				"cubes": [
					{"name": "cube", "origin": [7, 5, 7], "size": [2, 4, 1], "uv": [0, 0]},
					{"name": "cube", "origin": [-7, 2, -7], "size": [15, 5, 14], "uv": [0, 0]},
					{"name": "cube", "origin": [-7, 6, -7], "size": [15, 10, 14], "uv": [0, 19]}
				]
			}
		]
	}`
};
skin_presets.chicken = {
	display_name: 'Chicken',
	variants: {
		regular: {
			name: 'Regular',
			model: `{
				"name": "chicken",
				"external_textures": ["entity/chicken/chicken.png"],
				"texturewidth": 64,
				"textureheight": 32,
				"bones": [
					{
						"name": "body",
						"pivot": [0, 8, 0],
						"rotation": [90, 0, 0],
						"cubes": [
							{"name": "body", "origin": [-3, 4, -3], "size": [6, 8, 6], "uv": [0, 9]}
						]
					},
					{
						"name": "head",
						"pivot": [0, 9, -4],
						"cubes": [
							{"name": "head", "origin": [-2, 9, -6], "size": [4, 6, 3], "uv": [0, 0]}
						]
					},
					{
						"name": "comb",
						"parent": "head",
						"pivot": [0, 9, -4],
						"cubes": [
							{"name": "comb", "origin": [-1, 9, -7], "size": [2, 2, 2], "uv": [14, 4]}
						]
					},
					{
						"name": "beak",
						"parent": "head",
						"pivot": [0, 9, -4],
						"cubes": [
							{"name": "beak", "origin": [-2, 11, -8], "size": [4, 2, 2], "uv": [14, 0]}
						]
					},
					{
						"name": "leg0",
						"pivot": [-2, 5, 1],
						"cubes": [
							{"name": "leg0", "origin": [-3, 0, -2], "size": [3, 5, 3], "uv": [26, 0]}
						]
					},
					{
						"name": "leg1",
						"pivot": [1, 5, 1],
						"cubes": [
							{"name": "leg1", "origin": [0, 0, -2], "size": [3, 5, 3], "uv": [26, 0]}
						]
					},
					{
						"name": "wing0",
						"pivot": [-3, 11, 0],
						"cubes": [
							{"name": "wing0", "origin": [-4, 7, -3], "size": [1, 4, 6], "uv": [24, 13]}
						]
					},
					{
						"name": "wing1",
						"pivot": [3, 11, 0],
						"cubes": [
							{"name": "wing1", "origin": [3, 7, -3], "size": [1, 4, 6], "uv": [24, 13]}
						]
					}
				]
			}`
		},
		cold: {
			name: 'Cold',
			model: `{
				"name": "chicken_cold",
				"external_textures": ["entity/chicken/chicken_cold.png"],
				"texturewidth": 64,
				"textureheight": 32,
				"bones": [
					{
						"name": "body",
						"pivot": [0, 8, 0],
						"cubes": [
							{"origin": [-3, 12, 5], "size": [6, 8, 6], "pivot": [0, 8, 8], "rotation": [90, 0, 0], "uv": [0, 9]},
							{"origin": [0, 10, 7], "size": [0, 3, 5], "pivot": [0, 8, 8], "rotation": [90, 0, 0], "uv": [38, 9]}
						]
					},
					{
						"name": "head",
						"pivot": [0, 9, -4],
						"cubes": [
							{"origin": [-2, 9, -6], "size": [4, 6, 3], "uv": [0, 0]},
							{"origin": [-3, 13, -6.015], "size": [6, 3, 4], "uv": [44, 0]}
						]
					},
					{
						"name": "comb",
						"parent": "head",
						"pivot": [0, 9, -4],
						"cubes": [
							{"origin": [-1, 9, -7], "size": [2, 2, 2], "uv": [14, 4]}
						]
					},
					{
						"name": "beak",
						"parent": "head",
						"pivot": [0, 9, -4],
						"cubes": [
							{"origin": [-2, 11, -8], "size": [4, 2, 2], "uv": [14, 0]}
						]
					},
					{
						"name": "leg0",
						"pivot": [-2, 5, 1],
						"cubes": [
							{"origin": [-3, 0, -2], "size": [3, 5, 3], "uv": [26, 0]}
						]
					},
					{
						"name": "leg1",
						"pivot": [1, 5, 1],
						"cubes": [
							{"origin": [0, 0, -2], "size": [3, 5, 3], "uv": [26, 0]}
						]
					},
					{
						"name": "wing0",
						"pivot": [-3, 11, 0],
						"cubes": [
							{"origin": [-4, 7, -3], "size": [1, 4, 6], "uv": [24, 13]}
						]
					},
					{
						"name": "wing1",
						"pivot": [3, 11, 0],
						"cubes": [
							{"origin": [3, 7, -3], "size": [1, 4, 6], "uv": [24, 13]}
						]
					}
				]
			}`
		}
	}
};
skin_presets.chicken_baby = {
	display_name: 'Chick / Chicken Baby',
	model: `{
		"name": "chicken_baby",
		"texturewidth": 16,
		"textureheight": 16,
		"external_textures": ["entity/chicken/chicken_temperate_baby.png"],
		"eyes": [
			[4, 5, 1, 1],
			[7, 5, 1, 1]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [0, 3.75, -1.25],
				"cubes": [
					{"origin": [-2, 2, -2], "size": [4, 4, 4], "uv": [0, 0]},
					{"origin": [-1, 3, -3], "size": [2, 1, 1], "uv": [10, 8]}
				]
			},
			{
				"name": "leg0",
				"pivot": [-1, 2, 0.5],
				"cubes": [
					{"origin": [-1.5, 0, 0.5], "size": [1, 2, 0], "uv": [0, 2]},
					{"origin": [-1.5, 0, -0.5], "size": [1, 0, 1], "uv": [0, 0]}
				]
			},
			{
				"name": "leg1",
				"pivot": [1, 2, 0.5],
				"cubes": [
					{"origin": [0.5, 0, 0.5], "size": [1, 2, 0], "uv": [2, 2]},
					{"origin": [0.5, 0, -0.5], "size": [1, 0, 1], "uv": [0, 1]}
				]
			},
			{
				"name": "wing0",
				"pivot": [-2, 4, 0],
				"cubes": [
					{"origin": [-3, 4, -1], "size": [1, 0, 2], "uv": [4, 8]}
				]
			},
			{
				"name": "wing1",
				"pivot": [2, 4, 0],
				"cubes": [
					{"origin": [2, 4, -1], "size": [1, 0, 2], "uv": [6, 8]}
				]
			}
		]
	}`
};
skin_presets.cod = {
	display_name: 'Cod',
	model: `{
		"name": "cod",
		"external_textures": ["entity/fish/cod.png"],
		"texturewidth": 32,
		"textureheight": 32,
		"bones": [
			{
				"name": "body",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-1, 0, 1], "size": [2, 4, 7], "uv": [0, 0]},
					{"name": "body", "origin": [0, 4, 0], "size": [0, 1, 6], "uv": [20, -6]},
					{"name": "body", "origin": [0, -1, 3], "size": [0, 1, 2], "uv": [22, -1]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 2, 0],
				"cubes": [
					{"name": "head", "origin": [-0.9992, 1.0008, -3], "size": [2, 3, 1], "uv": [0, 0]},
					{"name": "head", "origin": [-1, 0, -2], "size": [2, 4, 3], "uv": [11, 0]}
				]
			},
			{
				"name": "leftFin",
				"parent": "body",
				"pivot": [1, 1, 0],
				"rotation": [0, 0, 35],
				"cubes": [
					{"name": "leftFin", "origin": [1, 0, 0], "size": [2, 1, 2], "uv": [24, 4]}
				]
			},
			{
				"name": "rightFin",
				"parent": "body",
				"pivot": [-1, 1, 0],
				"rotation": [0, 0, -35],
				"cubes": [
					{"name": "rightFin", "origin": [-3, 0, 0], "size": [2, 1, 2], "uv": [24, 1]}
				]
			},
			{
				"name": "tailfin",
				"parent": "body",
				"pivot": [0, 0, 8],
				"cubes": [
					{"name": "tailfin", "origin": [0, 0, 8], "size": [0, 4, 6], "uv": [20, 1]}
				]
			},
			{
				"name": "waist",
				"parent": "body",
				"pivot": [0, 0, 0]
			}
		]
	}`
};
skin_presets.copper_golem = {
	display_name: 'Copper Golem',
	model: `{
		"name": "copper_golem",
		"texturewidth": 64,
		"textureheight": 64,
		"eyes": [
			[11, 12],
			[15, 12]
		],
		"bones": [
			{
				"name": "root",
				"pivot": [1, 0, 0]
			},
			{
				"name": "body",
				"parent": "root",
				"pivot": [0, 5, 0],
				"cubes": [
					{"origin": [-4, 5, -3], "size": [8, 6, 6], "uv": [0, 15]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 11, 0],
				"cubes": [
					{"origin": [-4, 11, -5], "size": [8, 5, 10], "uv": [0, 0]},
					{"origin": [-1, 10, -6], "size": [2, 3, 2], "uv": [56, 0]},
					{"origin": [-1, 16, -1], "size": [2, 4, 2], "uv": [37, 8]},
					{"origin": [-2, 20, -2], "size": [4, 4, 4], "uv": [37, 0]}
				]
			},
			{
				"name": "right_arm",
				"parent": "body",
				"pivot": [-4, 11, 0],
				"cubes": [
					{"origin": [-7, 2, -2], "size": [3, 10, 4], "uv": [36, 16]}
				]
			},
			{
				"name": "rightItem",
				"parent": "right_arm",
				"pivot": [-5, 3.6, -1]
			},
			{
				"name": "left_arm",
				"parent": "body",
				"pivot": [4, 11, 0],
				"cubes": [
					{"origin": [4, 2, -2], "size": [3, 10, 4], "uv": [50, 16]}
				]
			},
			{
				"name": "right_leg",
				"parent": "root",
				"pivot": [-2, 5, 0],
				"cubes": [
					{"origin": [-3.9, 0, -1.99], "size": [4, 5, 4], "uv": [0, 27]}
				]
			},
			{
				"name": "left_leg",
				"parent": "root",
				"pivot": [2, 5, 0],
				"cubes": [
					{"origin": [-0.1, 0, -2], "size": [4, 5, 4], "uv": [16, 27]}
				]
			}
		]
	}`
}
skin_presets.cow = {
	display_name: 'Cow',
	variants: {
		new: {
			name: 'Regular',
			model: `{
				"name": "cow",
				"external_textures": ["entity/cow/cow.png"],
				"texturewidth": 64,
				"textureheight": 64,
				"eyes": [
					[7, 9],
					[11, 9]
				],
				"bones": [
					{
						"name": "root",
						"pivot": [0, 0, -1]
					},
					{
						"name": "head",
						"parent": "root",
						"pivot": [0, 20, -9],
						"cubes": [
							{"origin": [-4, 16, -15], "size": [8, 8, 6], "uv": [0, 0]},
							{"origin": [-3, 16, -16], "size": [6, 3, 1], "uv": [1, 33]},
							{"origin": [-5, 22, -14], "size": [1, 3, 1], "uv": [22, 0]},
							{"origin": [4, 22, -14], "size": [1, 3, 1], "uv": [22, 0]}
						]
					},
					{
						"name": "body",
						"parent": "root",
						"pivot": [0, 19, 1],
						"cubes": [
							{"origin": [-6, 29, 14], "size": [12, 18, 10], "pivot": [0, 18, 20], "rotation": [90, 0, 0], "uv": [18, 4]},
							{"origin": [-2, 29, 13], "size": [4, 6, 1], "pivot": [0, 18, 20], "rotation": [90, 0, 0], "uv": [52, 0]}
						]
					},
					{
						"name": "leg0",
						"parent": "root",
						"pivot": [-4, 12, 6],
						"cubes": [
							{"origin": [-6, 0, 4], "size": [4, 12, 4], "uv": [0, 16]}
						]
					},
					{
						"name": "leg1",
						"parent": "root",
						"pivot": [4, 12, 6],
						"mirror": true,
						"cubes": [
							{"origin": [2, 0, 4], "size": [4, 12, 4], "uv": [0, 16], "mirror": true}
						]
					},
					{
						"name": "leg2",
						"parent": "root",
						"pivot": [-4, 12, -7],
						"cubes": [
							{"origin": [-6, 0, -8], "size": [4, 12, 4], "uv": [0, 16]}
						]
					},
					{
						"name": "leg3",
						"parent": "root",
						"pivot": [4, 12, -7],
						"mirror": true,
						"cubes": [
							{"origin": [2, 0, -8], "size": [4, 12, 4], "uv": [0, 16], "mirror": true}
						]
					}
				]
			}`
		},
		cold: {
			name: 'Cold',
 			model: `{
				"name": "cow_cold",
				"external_textures": ["entity/cow/cow_cold.png"],
				"texturewidth": 64,
				"textureheight": 64,
				"eyes": [
					[7, 9],
					[11, 9]
				],
				"bones": [
					{
						"name": "root",
						"pivot": [0, 0, -1]
					},
					{
						"name": "head",
						"parent": "root",
						"pivot": [0, 20, -9],
						"cubes": [
							{"origin": [-4, 16, -15], "size": [8, 8, 6], "uv": [0, 0]},
							{"origin": [-6, 21, -13], "size": [2, 6, 2], "pivot": [-4.5, 22.5, -12.5], "rotation": [90, 0, 0], "uv": [0, 32]},
							{"origin": [-3, 16, -16], "size": [6, 3, 1], "uv": [9, 33]},
							{"origin": [4, 19.5, -14.5], "size": [2, 6, 2], "pivot": [5.5, 22.5, -14], "rotation": [90, 0, 0], "uv": [0, 32], "mirror": true}
						]
					},
					{
						"name": "body",
						"parent": "root",
						"pivot": [0, 19, 1],
						"cubes": [
							{"origin": [-6, 29, 14], "size": [12, 18, 10], "inflate": 0.5, "pivot": [0, 18, 20], "rotation": [90, 0, 0], "uv": [20, 32]},
							{"origin": [-6, 29, 14], "size": [12, 18, 10], "pivot": [0, 18, 20], "rotation": [90, 0, 0], "uv": [18, 4]},
							{"origin": [-2, 29, 13], "size": [4, 6, 1], "pivot": [0, 18, 20], "rotation": [90, 0, 0], "uv": [52, 0]}
						]
					},
					{
						"name": "leg0",
						"parent": "root",
						"pivot": [-4, 12, 6],
						"cubes": [
							{"origin": [-6, 0, 4], "size": [4, 12, 4], "uv": [0, 16]}
						]
					},
					{
						"name": "leg1",
						"parent": "root",
						"pivot": [4, 12, 6],
						"mirror": true,
						"cubes": [
							{"origin": [2, 0, 4], "size": [4, 12, 4], "uv": [0, 16], "mirror": true}
						]
					},
					{
						"name": "leg2",
						"parent": "root",
						"pivot": [-4, 12, -7],
						"cubes": [
							{"origin": [-6, 0, -8], "size": [4, 12, 4], "uv": [0, 16]}
						]
					},
					{
						"name": "leg3",
						"parent": "root",
						"pivot": [4, 12, -7],
						"mirror": true,
						"cubes": [
							{"origin": [2, 0, -8], "size": [4, 12, 4], "uv": [0, 16], "mirror": true}
						]
					}
				]
			}`
		},
		warm: {
			name: 'Warm',
 			model: `{
				"name": "cow_warm",
				"external_textures": ["entity/cow/cow_warm.png"],
				"texturewidth": 64,
				"textureheight": 64,
				"eyes": [
					[7, 9],
					[11, 9]
				],
				"bones": [
					{
						"name": "root",
						"pivot": [0, 0, -1]
					},
					{
						"name": "head",
						"parent": "root",
						"pivot": [0, 20, -9],
						"cubes": [
							{"origin": [-4, 16, -15], "size": [8, 8, 6], "uv": [0, 0]},
							{"origin": [-8, 21, -14], "size": [4, 2, 2], "uv": [27, 0]},
							{"origin": [-8, 23, -14], "size": [2, 2, 2], "uv": [39, 0]},
							{"origin": [4, 21, -14], "size": [4, 2, 2], "uv": [27, 0], "mirror": true},
							{"origin": [6, 23, -14], "size": [2, 2, 2], "uv": [39, 0], "mirror": true},
							{"origin": [-3, 16, -16], "size": [6, 3, 1], "uv": [1, 33]}
						]
					},
					{
						"name": "body",
						"parent": "root",
						"pivot": [0, 19, 1],
						"cubes": [
							{"origin": [-6, 29, 14], "size": [12, 18, 10], "pivot": [0, 18, 20], "rotation": [90, 0, 0], "uv": [18, 4]},
							{"origin": [-2, 29, 13], "size": [4, 6, 1], "pivot": [0, 18, 20], "rotation": [90, 0, 0], "uv": [52, 0]}
						]
					},
					{
						"name": "leg0",
						"parent": "root",
						"pivot": [-4, 12, 6],
						"cubes": [
							{"origin": [-6, 0, 4], "size": [4, 12, 4], "uv": [0, 16]}
						]
					},
					{
						"name": "leg1",
						"parent": "root",
						"pivot": [4, 12, 6],
						"mirror": true,
						"cubes": [
							{"origin": [2, 0, 4], "size": [4, 12, 4], "uv": [0, 16], "mirror": true}
						]
					},
					{
						"name": "leg2",
						"parent": "root",
						"pivot": [-4, 12, -7],
						"cubes": [
							{"origin": [-6, 0, -8], "size": [4, 12, 4], "uv": [0, 16]}
						]
					},
					{
						"name": "leg3",
						"parent": "root",
						"pivot": [4, 12, -7],
						"mirror": true,
						"cubes": [
							{"origin": [2, 0, -8], "size": [4, 12, 4], "uv": [0, 16], "mirror": true}
						]
					}
				]
			}`
		},
		old: {
			name: 'Classic',
 			model: `{
				"name": "cow",
				"texturewidth": 64,
				"textureheight": 32,
				"eyes": [
					[7, 9],
					[11, 9]
				],
				"bones": [
					{
						"name": "body",
						"pivot": [0, 19, 2],
						"rotation": [90, 0, 0],
						"cubes": [
							{"name": "body", "origin": [-6, 11, -5], "size": [12, 18, 10], "uv": [18, 4]},
							{"name": "body", "origin": [-2, 11, -6], "size": [4, 6, 1], "uv": [52, 0]}
						]
					},
					{
						"name": "head",
						"pivot": [0, 20, -8],
						"cubes": [
							{"name": "head", "origin": [-4, 16, -14], "size": [8, 8, 6], "uv": [0, 0]},
							{"name": "head", "origin": [-5, 22, -12], "size": [1, 3, 1], "uv": [22, 0]},
							{"name": "head", "origin": [4, 22, -12], "size": [1, 3, 1], "uv": [22, 0]}
						]
					},
					{
						"name": "leg0",
						"pivot": [-4, 12, 7],
						"cubes": [
							{"name": "leg0", "origin": [-6, 0, 5], "size": [4, 12, 4], "uv": [0, 16]}
						]
					},
					{
						"name": "leg1",
						"pivot": [4, 12, 7],
						"mirror": true,
						"cubes": [
							{"name": "leg1", "origin": [2, 0, 5], "size": [4, 12, 4], "uv": [0, 16]}
						]
					},
					{
						"name": "leg2",
						"pivot": [-4, 12, -6],
						"cubes": [
							{"name": "leg2", "origin": [-6, 0, -7], "size": [4, 12, 4], "uv": [0, 16]}
						]
					},
					{
						"name": "leg3",
						"pivot": [4, 12, -6],
						"mirror": true,
						"cubes": [
							{"name": "leg3", "origin": [2, 0, -7], "size": [4, 12, 4], "uv": [0, 16]}
						]
					}
				]
			}`
		}
	}
};
skin_presets.cow_baby = {
	display_name: 'Cow Baby',
	model: `{
		"name": "cow_baby",
		"texturewidth": 64,
		"textureheight": 64,
		"external_textures": ["entity/cow/cow_temperate_baby.png"],
		"eyes": [
			[5, 25, 1, 1],
			[10, 25, 1, 1]
		],
		"bones": [
			{
				"name": "root",
				"pivot": [0, 0, 0]
			},
			{
				"name": "head",
				"parent": "root",
				"pivot": [0, 10.43096, -5.16667],
				"cubes": [
					{"origin": [-3, 9, -10], "size": [6, 6, 5], "uv": [0, 18]},
					{"origin": [3, 14, -9], "size": [1, 2, 1], "uv": [8, 29]},
					{"origin": [-4, 14, -9], "size": [1, 2, 1], "uv": [4, 29], "mirror": true},
					{"origin": [-2, 9, -11], "size": [4, 3, 1], "uv": [12, 29]}
				]
			},
			{
				"name": "body",
				"parent": "root",
				"pivot": [0, 9, 0],
				"cubes": [
					{"origin": [-4, 6, -6], "size": [8, 6, 12], "uv": [0, 0]}
				]
			},
			{
				"name": "leg0",
				"parent": "root",
				"pivot": [-2.475, 6, 3.5],
				"cubes": [
					{"origin": [-3.975, 0, 2], "size": [3, 6, 3], "uv": [22, 27]}
				]
			},
			{
				"name": "leg1",
				"parent": "root",
				"pivot": [2.475, 6, 3.5],
				"cubes": [
					{"origin": [0.975, 0, 2], "size": [3, 6, 3], "uv": [34, 27]}
				]
			},
			{
				"name": "leg2",
				"parent": "root",
				"pivot": [-2.475, 6, -3.5],
				"cubes": [
					{"origin": [-3.975, 0, -5], "size": [3, 6, 3], "uv": [22, 18]}
				]
			},
			{
				"name": "leg3",
				"parent": "root",
				"pivot": [2.475, 6, -3.5],
				"cubes": [
					{"origin": [0.975, 0, -5], "size": [3, 6, 3], "uv": [34, 18]}
				]
			}
		]
	}`
};
skin_presets.creaking = {
	display_name: 'Creaking',
	model: `{
		"name": "creaking",
		"external_textures": ["entity/creaking/creaking.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"eyes": [
			[6, 8, 3, 1],
			[9, 10, 3, 1],
			[7, 13, 3, 1]
		],
		"bones": [
			{
				"name": "root",
				"pivot": [0, 0, 0]
			},
			{
				"name": "Waist",
				"parent": "root",
				"pivot": [-1, 19, 0]
			},
			{
				"name": "head",
				"parent": "Waist",
				"pivot": [-4, 30, 0],
				"cubes": [
					{"origin": [-7, 30, -3], "size": [6, 10, 6], "uv": [0, 0]},
					{"origin": [-7, 40, -3], "size": [6, 3, 6], "uv": [28, 31]},
					{"origin": [-1, 29, 0], "size": [9, 14, 0], "uv": [12, 40]},
					{"origin": [-16, 30, 0], "size": [9, 14, 0], "uv": [34, 12]}
				]
			},
			{
				"name": "Body",
				"parent": "Waist",
				"pivot": [-1, 26, 1],
				"cubes": [
					{"origin": [-1, 16, -2], "size": [6, 13, 5], "uv": [0, 16]},
					{"origin": [-7, 23, -2], "size": [6, 7, 5], "uv": [24, 0]}
				]
			},
			{
				"name": "RightArm",
				"parent": "Waist",
				"pivot": [-8, 28.5, 1.5],
				"cubes": [
					{"origin": [-10, 9, 0], "size": [3, 21, 3], "uv": [22, 13]},
					{"origin": [-10, 5, 0], "size": [3, 4, 3], "uv": [46, 0]}
				]
			},
			{
				"name": "LeftArm",
				"parent": "Waist",
				"pivot": [5, 28, 0.5],
				"cubes": [
					{"origin": [5, 13, -1], "size": [3, 16, 3], "uv": [30, 40]},
					{"origin": [5, 29, -1], "size": [3, 4, 3], "uv": [52, 12]},
					{"origin": [5, 9, -1], "size": [3, 4, 3], "uv": [52, 19]}
				]
			},
			{
				"name": "LeftLeg",
				"parent": "root",
				"pivot": [1.5, 16, 0.5],
				"cubes": [
					{"origin": [0, 0, -1], "size": [3, 16, 3], "uv": [42, 40]},
					{"origin": [0, 0.3, -4], "size": [5, 0, 9], "uv": [45, 55]}
				]
			},
			{
				"name": "RightLeg",
				"parent": "root",
				"pivot": [-1, 17.5, 0.5],
				"cubes": [
					{"origin": [-4, 0, -1], "size": [3, 19, 3], "uv": [0, 34]},
					{"origin": [-6, 0.3, -4], "size": [5, 0, 9], "uv": [45, 46]},
					{"origin": [-4, 19, -1], "size": [3, 3, 3], "uv": [12, 34]}
				]
			}
		]
	}`
};
skin_presets.creeper = {
	display_name: 'Creeper',
	model: `{
		"name": "creeper",
		"external_textures": ["entity/creeper/creeper.png"],
		"texturewidth": 64,
		"textureheight": 32,
		"eyes": [
			[9, 10],
			[13, 10]
		],
		"bones": [
			{
				"name": "Body",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "Body", "origin": [-4, 6, -2], "size": [8, 12, 4], "uv": [16, 16]}
				]
			},
			{
				"name": "Head",
				"parent": "Body",
				"pivot": [0, 18, 0],
				"cubes": [
					{"name": "Head", "origin": [-4, 18, -4], "size": [8, 8, 8], "uv": [0, 0]}
				]
			},
			{
				"name": "leg0",
				"parent": "Body",
				"pivot": [-2, 6, 4],
				"cubes": [
					{"name": "leg0", "origin": [-4, 0, 2], "size": [4, 6, 4], "uv": [0, 16]}
				]
			},
			{
				"name": "leg1",
				"parent": "Body",
				"pivot": [2, 6, 4],
				"cubes": [
					{"name": "leg1", "origin": [0, 0, 2], "size": [4, 6, 4], "uv": [0, 16]}
				]
			},
			{
				"name": "leg2",
				"parent": "Body",
				"pivot": [-2, 6, -4],
				"cubes": [
					{"name": "leg2", "origin": [-4, 0, -6], "size": [4, 6, 4], "uv": [0, 16]}
				]
			},
			{
				"name": "leg3",
				"parent": "Body",
				"pivot": [2, 6, -4],
				"cubes": [
					{"name": "leg3", "origin": [0, 0, -6], "size": [4, 6, 4], "uv": [0, 16]}
				]
			}
		]
	}`
};
skin_presets.cushion = {
	display_name: 'Cushion',
	model: `{
		"name": "cushion",
		"texturewidth": 64,
		"textureheight": 64,
		"external_textures": ["entity/cushion/white_cushion.png"],
		"bones": [
			{
				"name": "cushion",
				"pivot": [23, 0, -7],
				"cubes": [
					{"origin": [-8, -0.125, -8], "size": [16, 4, 16], "inflate": -0.01, "uv": [0, 0]}
				]
			}
		]
	}`
};
skin_presets.dolphin = {
	display_name: 'Dolphin',
	pose: true,
	model_bedrock: `{
		"name": "dolphin",
		"external_textures": ["entity/dolphin.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "body",
				"pivot": [0, 0, -3],
				"cubes": [
					{"name": "body", "origin": [-4, 0, -3], "size": [8, 7, 13], "uv": [0, 13]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 0, -3],
				"cubes": [
					{"name": "head", "origin": [-4, 0, -9], "size": [8, 7, 6], "uv": [0, 0]}
				]
			},
			{
				"name": "nose",
				"parent": "head",
				"pivot": [0, 0, -13],
				"cubes": [
					{"name": "nose", "origin": [-1, 0, -13], "size": [2, 2, 4], "uv": [0, 13]}
				]
			},
			{
				"name": "tail",
				"parent": "body",
				"pivot": [0, 2.5, 11],
				"pose": [-5, 0, 0],
				"cubes": [
					{"name": "tail", "origin": [-2, 0, 10], "size": [4, 5, 11], "uv": [0, 33]}
				]
			},
			{
				"name": "tail_fin",
				"parent": "tail",
				"pivot": [0, 2.5, 20],
				"pose": [-8, 0, 0],
				"cubes": [
					{"name": "tail_fin", "origin": [-5, 2, 19], "size": [10, 1, 6], "uv": [0, 49]}
				]
			},
			{
				"name": "back_fin",
				"parent": "body",
				"pivot": [0, 7, 2],
				"rotation": [-30, 0, 0],
				"cubes": [
					{"name": "back_fin", "origin": [-0.5, 6.25, 1], "size": [1, 5, 4], "uv": [29, 0]}
				]
			},
			{
				"name": "left_fin",
				"parent": "body",
				"pivot": [3, 1, -1],
				"rotation": [0, -25, 20],
				"cubes": [
					{"name": "left_fin", "origin": [3, 1, -2.5], "size": [8, 1, 4], "uv": [40, 0]}
				]
			},
			{
				"name": "right_fin",
				"parent": "body",
				"pivot": [-3, 1, -1],
				"rotation": [0, 25, -20],
				"cubes": [
					{"name": "right_fin", "origin": [-11, 1, -2.5], "size": [8, 1, 4], "uv": [40, 6]}
				]
			}
		]
	}`,
	model_java: `{
		"name": "dolphin",
		"external_textures": ["entity/dolphin.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "body",
				"pivot": [0, 0, -3],
				"cubes": [
					{"name": "body", "origin": [-4, 0, -3], "size": [8, 7, 13], "uv": [22, 0]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 0, -3],
				"cubes": [
					{"name": "head", "origin": [-4, 0, -9], "size": [8, 7, 6], "uv": [0, 0]}
				]
			},
			{
				"name": "nose",
				"parent": "head",
				"pivot": [0, 0, -13],
				"cubes": [
					{"name": "nose", "origin": [-1, 0, -13], "size": [2, 2, 4], "uv": [0, 13]}
				]
			},
			{
				"name": "tail",
				"parent": "body",
				"pivot": [0, 2.5, 11],
				"pose": [-5, 0, 0],
				"cubes": [
					{"name": "tail", "origin": [-2, 0, 10], "size": [4, 5, 11], "uv": [0, 19]}
				]
			},
			{
				"name": "tail_fin",
				"parent": "tail",
				"pivot": [0, 2.5, 20],
				"pose": [-8, 0, 0],
				"cubes": [
					{"name": "tail_fin", "origin": [-5, 2, 19], "size": [10, 1, 6], "uv": [19, 20]}
				]
			},
			{
				"name": "back_fin",
				"parent": "body",
				"pivot": [0, 7, 2],
				"rotation": [60, 0, 0],
				"cubes": [
					{"name": "back_fin", "origin": [-0.5, 3.75, 1.5], "size": [1, 4, 5], "uv": [51, 0]}
				]
			},
			{
				"name": "left_fin",
				"parent": "body",
				"pivot": [3, 2, 2],
				"rotation": [55, 0, 107],
				"cubes": [
					{"name": "left_fin", "origin": [3, 2, 0.5], "size": [1, 4, 7], "uv": [48, 20]}
				]
			},
			{
				"name": "right_fin",
				"parent": "body",
				"pivot": [-3, 2, 2],
				"rotation": [55, 0, -107],
				"cubes": [
					{"name": "left_fin", "origin": [-4, 2, 0.5], "size": [1, 4, 7], "uv": [48, 20], "mirror": true}
				]
			}
		]
	}`
};
skin_presets.dolphin_baby = {
	display_name: 'Dolphin Baby',
	model: `{
		"name": "dolphin_baby",
		"texturewidth": 64,
		"textureheight": 64,
		"external_textures": ["entity/dolphin/dolphin_baby.png"],
		"eyes": [
			[1, 7, 1, 1],
			[12, 7, 1, 1]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [-1, 0, -3],
				"cubes": [
					{"origin": [-3, 0, -4], "size": [6, 5, 8], "uv": [20, 0]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 1.5, -4],
				"cubes": [
					{"origin": [-3, 0, -8], "size": [6, 5, 4], "uv": [0, 0]}
				]
			},
			{
				"name": "nose",
				"parent": "head",
				"pivot": [0, 1, -8],
				"cubes": [
					{"origin": [-1, 0, -10], "size": [2, 2, 2], "uv": [0, 9]}
				]
			},
			{
				"name": "tail",
				"parent": "body",
				"pivot": [0, 1.5, 4],
				"cubes": [
					{"origin": [-2, 0, 4], "size": [4, 3, 7], "uv": [0, 13]}
				]
			},
			{
				"name": "tail_fin",
				"parent": "tail",
				"pivot": [0, 1.5, 10],
				"cubes": [
					{"origin": [-4, 1, 9], "size": [8, 1, 4], "uv": [22, 13]}
				]
			},
			{
				"name": "back_fin",
				"parent": "body",
				"pivot": [0, 3.5, -2.7],
				"rotation": [50, 0, 0],
				"cubes": [
					{"origin": [-0.5, 1.5, -1.7], "size": [1, 3, 4], "uv": [42, 0]}
				]
			},
			{
				"name": "left_fin",
				"parent": "body",
				"pivot": [1.8, 1.65001, -2.6],
				"rotation": [50, 0, 97.5],
				"cubes": [
					{"origin": [1.3, 0.15001, -3.1], "size": [1, 3, 6], "uv": [34, 18]}
				]
			},
			{
				"name": "right_fin",
				"parent": "body",
				"pivot": [-1.8, 1.65001, -2.6],
				"rotation": [50, 0, -97.5],
				"cubes": [
					{"origin": [-2.3, 0.15001, -3.1], "size": [1, 3, 6], "uv": [48, 18], "mirror": true}
				]
			}
		]
	}`
};
skin_presets.donkey_baby = {
	display_name: 'Donkey / Mule Baby',
	model: `{
		"name": "donkeymule",
		"texturewidth": 64,
		"textureheight": 64,
		"external_textures": ["entity/horse2/donkey_baby.png"],
		"eyes": [
			[3, 10, 1, 1],
			[20, 10, 1, 1]
		],
		"bones": [
			{
				"name": "root",
				"pivot": [-1, 0, -3]
			},
			{
				"name": "Body",
				"parent": "root",
				"pivot": [0, 10, 0],
				"cubes": [
					{"origin": [-4, 8, -7], "size": [8, 6, 14], "uv": [0, 13]}
				]
			},
			{
				"name": "Tail",
				"parent": "root",
				"pivot": [0, 11.5, 6.5],
				"cubes": [
					{"origin": [-1.5, 10.5, 6], "size": [3, 3, 8], "pivot": [0, 12.5, 6.5], "rotation": [-42.5, 0, 0], "uv": [24, 33]}
				]
			},
			{
				"name": "LegBL",
				"parent": "root",
				"pivot": [2.5, 6.5, 5.5],
				"cubes": [
					{"origin": [1, 0, 4], "size": [3, 8, 3], "uv": [12, 44]}
				]
			},
			{
				"name": "LegBR",
				"parent": "root",
				"pivot": [-2.5, 6.5, 5.5],
				"cubes": [
					{"origin": [-4, 0, 4], "size": [3, 8, 3], "uv": [0, 44]}
				]
			},
			{
				"name": "LegFL",
				"parent": "root",
				"pivot": [2.5, 6.5, -5.5],
				"cubes": [
					{"origin": [1, 0, -7], "size": [3, 8, 3], "uv": [12, 33]}
				]
			},
			{
				"name": "LegFR",
				"parent": "root",
				"pivot": [-2.5, 6.5, -5.5],
				"cubes": [
					{"origin": [-4, 0, -7], "size": [3, 8, 3], "uv": [0, 33]}
				]
			},
			{
				"name": "Neck",
				"parent": "root",
				"pivot": [0, 13, -5],
				"cubes": [
					{"origin": [-2, 12, -8], "size": [4, 8, 4], "pivot": [0, 14, -5], "rotation": [22.5, 0, 0], "uv": [30, 9]}
				]
			},
			{
				"name": "Head",
				"parent": "Neck",
				"pivot": [0, 19, -7],
				"cubes": [
					{"origin": [-3, 19.6, -15.4], "size": [6, 4, 9], "pivot": [0, 20, -7], "rotation": [22.5, 0, 0], "uv": [0, 0]}
				]
			},
			{
				"name": "left_ear",
				"parent": "Head",
				"pivot": [2.5, 20.5, -9],
				"rotation": [27.5, 0, 27.5],
				"cubes": [
					{"origin": [0.03825, 21.28679, -8.59042], "size": [2, 7, 1], "uv": [0, 0]}
				]
			},
			{
				"name": "right_ear",
				"parent": "Head",
				"pivot": [-2.5, 20.5, -9],
				"rotation": [27.5, 0, -27.5],
				"cubes": [
					{"origin": [-2.03825, 21.28679, -8.59042], "size": [2, 7, 1], "uv": [22, 0], "mirror": true}
				]
			}
		]
	}`
}
skin_presets.enderdragon = {
	display_name: 'Ender Dragon',
	pose: true,
	model: `{
		"name": "enderdragon",
		"texturewidth": 256,
		"textureheight": 256,
		"bones": [
			{
				"name": "neck",
				"pivot": [0, 7, -8],
				"pose": [-5, 0, 0],
				"cubes": [
					{"name": "neck", "origin": [-5, 2, -18], "size": [10, 10, 10], "uv": [192, 104]},
					{"name": "neck", "origin": [-1, 12, -16], "size": [2, 4, 6], "uv": [48, 0]}
				]
			},
			{
				"name": "neck2",
				"parent": "neck",
				"pivot": [0, 7, -18],
				"pose": [5, 0, 0],
				"cubes": [
					{"name": "neck", "origin": [-5, 2, -28], "size": [10, 10, 10], "uv": [192, 104]},
					{"name": "neck", "origin": [-1, 12, -26], "size": [2, 4, 6], "uv": [48, 0]}
				]
			},
			{
				"name": "neck3",
				"parent": "neck2",
				"pivot": [0, 7, -28],
				"pose": [5, 0, 0],
				"cubes": [
					{"name": "neck", "origin": [-5, 2, -38], "size": [10, 10, 10], "uv": [192, 104]},
					{"name": "neck", "origin": [-1, 12, -36], "size": [2, 4, 6], "uv": [48, 0]}
				]
			},
			{
				"name": "neck4",
				"parent": "neck3",
				"pivot": [0, 7, -38],
				"pose": [5, 0, 0],
				"cubes": [
					{"name": "neck", "origin": [-5, 2, -48], "size": [10, 10, 10], "uv": [192, 104]},
					{"name": "neck", "origin": [-1, 12, -46], "size": [2, 4, 6], "uv": [48, 0]}
				]
			},
			{
				"name": "neck5",
				"parent": "neck4",
				"pivot": [0, 7, -48],
				"pose": [5, 0, 0],
				"cubes": [
					{"name": "neck", "origin": [-5, 2, -58], "size": [10, 10, 10], "uv": [192, 104]},
					{"name": "neck", "origin": [-1, 12, -56], "size": [2, 4, 6], "uv": [48, 0]}
				]
			},
			{
				"name": "head",
				"parent": "neck5",
				"pivot": [0, 7, -58],
				"pose": [5, 0, 0],
				"cubes": [
					{"name": "head", "origin": [-6, 3, -88], "size": [12, 5, 16], "uv": [176, 44]},
					{"name": "head", "origin": [-8, -1, -74], "size": [16, 16, 16], "uv": [112, 30]},
					{"name": "head", "origin": [-5, 15, -68], "size": [2, 4, 6], "uv": [0, 0], "mirror": true},
					{"name": "head", "origin": [-5, 8, -86], "size": [2, 2, 4], "uv": [112, 0], "mirror": true},
					{"name": "head", "origin": [3, 15, -68], "size": [2, 4, 6], "uv": [0, 0]},
					{"name": "head", "origin": [3, 8, -86], "size": [2, 2, 4], "uv": [112, 0]}
				]
			},
			{
				"name": "jaw",
				"parent": "head",
				"pivot": [0, 3, -71],
				"pose": [15, 0, 0],
				"cubes": [
					{"name": "jaw", "origin": [-6, -1, -88], "size": [12, 4, 16], "uv": [176, 65]}
				]
			},
			{
				"name": "body",
				"pivot": [0, 20, 8],
				"cubes": [
					{"name": "body", "origin": [-12, -4, -8], "size": [24, 24, 64], "uv": [0, 0]},
					{"name": "body", "origin": [-1, 20, -2], "size": [2, 6, 12], "uv": [220, 53]},
					{"name": "body", "origin": [-1, 20, 18], "size": [2, 6, 12], "uv": [220, 53]},
					{"name": "body", "origin": [-1, 20, 38], "size": [2, 6, 12], "uv": [220, 53]}
				]
			},
			{
				"name": "wing",
				"pivot": [-12, 19, 2],
				"pose": [0, 10, 10],
				"cubes": [
					{"name": "wing", "origin": [-68, 15, -2], "size": [56, 8, 8], "uv": [112, 88]},
					{"name": "wing", "origin": [-68, 19, 4], "size": [56, 0, 56], "uv": [-56, 88], "inflate": 0.01}
				]
			},
			{
				"name": "wingtip",
				"parent": "wing",
				"pivot": [-68, 19, 0],
				"pose": [0, 0, -20],
				"cubes": [
					{"name": "wingtip", "origin": [-124, 17, 0], "size": [56, 4, 4], "uv": [112, 136]},
					{"name": "wingtip", "origin": [-124, 19, 4], "size": [56, 0, 56], "uv": [-56, 144], "inflate": 0.01}
				]
			},
			{
				"name": "wing1",
				"pivot": [12, 19, 2],
				"pose": [0, -10, -10],
				"mirror": true,
				"cubes": [
					{"name": "wing1", "origin": [12, 15, -2], "size": [56, 8, 8], "uv": [112, 88]},
					{"name": "wing1", "origin": [12, 19, 4], "size": [56, 0, 56], "uv": [-56, 88], "inflate": 0.01}
				]
			},
			{
				"name": "wingtip1",
				"parent": "wing1",
				"pivot": [68, 19, 0],
				"pose": [0, 0, 20],
				"mirror": true,
				"cubes": [
					{"name": "wingtip1", "origin": [68, 17, 0], "size": [56, 4, 4], "uv": [112, 136]},
					{"name": "wingtip1", "origin": [68, 19, 4], "size": [56, 0, 56], "uv": [-56, 144], "inflate": 0.01}
				]
			},
			{
				"name": "rearleg",
				"pivot": [-16, 8, 42],
				"rotation": [60, 0, 0],
				"cubes": [
					{"name": "rearleg", "origin": [-24, -20, 34], "size": [16, 32, 16], "uv": [0, 0]}
				]
			},
			{
				"name": "rearlegtip",
				"parent": "rearleg",
				"pivot": [-16, -20, 43],
				"rotation": [25, 0, 0],
				"cubes": [
					{"name": "rearlegtip", "origin": [-22, -52, 36], "size": [12, 32, 12], "uv": [196, 0]}
				]
			},
			{
				"name": "rearfoot",
				"parent": "rearlegtip",
				"pivot": [-16, -52, 41],
				"rotation": [45, 0, 0],
				"cubes": [
					{"name": "rearfoot", "origin": [-25, -58, 21], "size": [18, 6, 24], "uv": [112, 0]}
				]
			},
			{
				"name": "rearleg1",
				"pivot": [16, 8, 42],
				"rotation": [60, 0, 0],
				"mirror": true,
				"cubes": [
					{"name": "rearleg1", "origin": [8, -20, 34], "size": [16, 32, 16], "uv": [0, 0]}
				]
			},
			{
				"name": "rearlegtip1",
				"parent": "rearleg1",
				"pivot": [16, -20, 43],
				"rotation": [25, 0, 0],
				"mirror": true,
				"cubes": [
					{"name": "rearlegtip", "origin": [10, -52, 36], "size": [12, 32, 12], "uv": [196, 0]}
				]
			},
			{
				"name": "rearfoot1",
				"parent": "rearlegtip1",
				"pivot": [16, -52, 41],
				"rotation": [45, 0, 0],
				"mirror": true,
				"cubes": [
					{"name": "rearfoot", "origin": [7, -58, 21], "size": [18, 6, 24], "uv": [112, 0]}
				]
			},
			{
				"name": "frontleg",
				"pivot": [-12, 4, 2],
				"rotation": [65, 0, 0],
				"cubes": [
					{"name": "frontleg", "origin": [-16, -16, -2], "size": [8, 24, 8], "uv": [112, 104]}
				]
			},
			{
				"name": "frontlegtip",
				"parent": "frontleg",
				"pivot": [-12, -16, 2],
				"rotation": [-20, 0, 0],
				"cubes": [
					{"name": "frontlegtip", "origin": [-15, -39, -1], "size": [6, 24, 6], "uv": [226, 138]}
				]
			},
			{
				"name": "frontfoot",
				"parent": "frontlegtip",
				"pivot": [-12, -38, 2],
				"rotation": [45, 0, 0],
				"cubes": [
					{"name": "frontfoot", "origin": [-16, -42, -10], "size": [8, 4, 16], "uv": [144, 104]}
				]
			},
			{
				"name": "frontleg1",
				"pivot": [12, 4, 2],
				"rotation": [65, 0, 0],
				"mirror": true,
				"cubes": [
					{"name": "frontleg1", "origin": [8, -16, -2], "size": [8, 24, 8], "uv": [112, 104]}
				]
			},
			{
				"name": "frontlegtip1",
				"parent": "frontleg1",
				"pivot": [12, -16, 2],
				"rotation": [-20, 0, 0],
				"mirror": true,
				"cubes": [
					{"name": "frontlegtip", "origin": [9, -39, -1], "size": [6, 24, 6], "uv": [226, 138]}
				]
			},
			{
				"name": "frontfoot1",
				"parent": "frontlegtip1",
				"pivot": [12, -38, 2],
				"rotation": [45, 0, 0],
				"mirror": true,
				"cubes": [
					{"name": "frontfoot", "origin": [8, -42, -10], "size": [8, 4, 16], "uv": [144, 104]}
				]
			},
			{
				"name": "tail",
				"pivot": [0, 14, 56],
				"cubes": [
					{"name": "tail", "origin": [-5, 9, 56], "size": [10, 10, 10], "uv": [192, 104]},
					{"name": "tail", "origin": [-1, 19, 58], "size": [2, 4, 6], "uv": [48, 0]}
				]
			},
			{
				"name": "tail2",
				"parent": "tail",
				"pivot": [0, 14, 66],
				"pose": [1, 0, 0],
				"cubes": [
					{"name": "tail", "origin": [-5, 9, 66], "size": [10, 10, 10], "uv": [192, 104]},
					{"name": "tail", "origin": [-1, 19, 68], "size": [2, 4, 6], "uv": [48, 0]}
				]
			},
			{
				"name": "tail3",
				"parent": "tail2",
				"pivot": [0, 14, 76],
				"pose": [1, 0, 0],
				"cubes": [
					{"name": "tail", "origin": [-5, 9, 76], "size": [10, 10, 10], "uv": [192, 104]},
					{"name": "tail", "origin": [-1, 19, 78], "size": [2, 4, 6], "uv": [48, 0]}
				]
			},
			{
				"name": "tail4",
				"parent": "tail3",
				"pivot": [0, 14, 86],
				"pose": [1, 0, 0],
				"cubes": [
					{"name": "tail", "origin": [-5, 9, 86], "size": [10, 10, 10], "uv": [192, 104]},
					{"name": "tail", "origin": [-1, 19, 88], "size": [2, 4, 6], "uv": [48, 0]}
				]
			},
			{
				"name": "tail5",
				"parent": "tail4",
				"pivot": [0, 14, 96],
				"pose": [2, 0, 0],
				"cubes": [
					{"name": "tail", "origin": [-5, 9, 96], "size": [10, 10, 10], "uv": [192, 104]},
					{"name": "tail", "origin": [-1, 19, 98], "size": [2, 4, 6], "uv": [48, 0]}
				]
			},
			{
				"name": "tail6",
				"parent": "tail5",
				"pivot": [0, 14, 106],
				"pose": [3, 0, 0],
				"cubes": [
					{"name": "tail", "origin": [-5, 9, 106], "size": [10, 10, 10], "uv": [192, 104]},
					{"name": "tail", "origin": [-1, 19, 108], "size": [2, 4, 6], "uv": [48, 0]}
				]
			},
			{
				"name": "tail7",
				"parent": "tail6",
				"pivot": [0, 14, 116],
				"pose": [3, 0, 0],
				"cubes": [
					{"name": "tail", "origin": [-5, 9, 116], "size": [10, 10, 10], "uv": [192, 104]},
					{"name": "tail", "origin": [-1, 19, 118], "size": [2, 4, 6], "uv": [48, 0]}
				]
			},
			{
				"name": "tail8",
				"parent": "tail7",
				"pivot": [0, 14, 126],
				"pose": [1, 0, 0],
				"cubes": [
					{"name": "tail", "origin": [-5, 9, 126], "size": [10, 10, 10], "uv": [192, 104]},
					{"name": "tail", "origin": [-1, 19, 128], "size": [2, 4, 6], "uv": [48, 0]}
				]
			},
			{
				"name": "tail9",
				"parent": "tail8",
				"pivot": [0, 14, 136],
				"pose": [-1, 0, 0],
				"cubes": [
					{"name": "tail", "origin": [-5, 9, 136], "size": [10, 10, 10], "uv": [192, 104]},
					{"name": "tail", "origin": [-1, 19, 138], "size": [2, 4, 6], "uv": [48, 0]}
				]
			},
			{
				"name": "tail10",
				"parent": "tail9",
				"pivot": [0, 14, 146],
				"pose": [-2, 0, 0],
				"cubes": [
					{"name": "tail", "origin": [-5, 9, 146], "size": [10, 10, 10], "uv": [192, 104]},
					{"name": "tail", "origin": [-1, 19, 148], "size": [2, 4, 6], "uv": [48, 0]}
				]
			},
			{
				"name": "tail11",
				"parent": "tail10",
				"pivot": [0, 14, 156],
				"pose": [-3, 0, 0],
				"cubes": [
					{"name": "tail", "origin": [-5, 9, 156], "size": [10, 10, 10], "uv": [192, 104]},
					{"name": "tail", "origin": [-1, 19, 158], "size": [2, 4, 6], "uv": [48, 0]}
				]
			},
			{
				"name": "tail12",
				"parent": "tail11",
				"pivot": [0, 14, 166],
				"pose": [-3, 0, 0],
				"cubes": [
					{"name": "tail", "origin": [-5, 9, 166], "size": [10, 10, 10], "uv": [192, 104]},
					{"name": "tail", "origin": [-1, 19, 168], "size": [2, 4, 6], "uv": [48, 0]}
				]
			}
		]
	}`
};
skin_presets.enderman = {
	display_name: 'Enderman',
	model: `{
		"name": "enderman",
		"texturewidth": 64,
		"textureheight": 32,
		"bones": [
			{
				"name": "Head",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "Head", "origin": [-4, 40, -4], "size": [8, 8, 8], "uv": [0, 0], "inflate": -0.5},
					{"name": "Head layer", "origin": [-4, 38, -4], "size": [8, 8, 8], "uv": [0, 16], "inflate": -0.5, "layer": true}
				]
			},
			{
				"name": "Body",
				"pivot": [0, 38, 0],
				"cubes": [
					{"name": "Body", "origin": [-4, 26, -2], "size": [8, 12, 4], "uv": [32, 16]}
				]
			},
			{
				"name": "RightArm",
				"pivot": [-3, 36, 0],
				"cubes": [
					{"name": "RightArm", "origin": [-6, 8, -1], "size": [2, 30, 2], "uv": [56, 0]}
				]
			},
			{
				"name": "LeftArm",
				"pivot": [5, 36, 0],
				"mirror": true,
				"cubes": [
					{"name": "LeftArm", "origin": [4, 8, -1], "size": [2, 30, 2], "uv": [56, 0]}
				]
			},
			{
				"name": "RightLeg",
				"pivot": [-2, 26, 0],
				"cubes": [
					{"name": "RightLeg", "origin": [-3, -4, -1], "size": [2, 30, 2], "uv": [56, 0]}
				]
			},
			{
				"name": "LeftLeg",
				"pivot": [2, 26, 0],
				"mirror": true,
				"cubes": [
					{"name": "LeftLeg", "origin": [1, -4, -1], "size": [2, 30, 2], "uv": [56, 0]}
				]
			}
		]
	}`
};
skin_presets.endermite = {
	display_name: 'Endermite',
	model: `{
		"name": "endermite",
		"external_textures": ["entity/endermite.png"],
		"texturewidth": 64,
		"textureheight": 32,
		"bones": [
			{
				"name": "section_2",
				"pivot": [0, 0, 2.5],
				"cubes": [
					{"name": "section_2", "origin": [-1.5, 0, 2.5], "size": [3, 3, 1], "uv": [0, 14]}
				]
			},
			{
				"name": "section_0",
				"parent": "section_2",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "section_0", "origin": [-2, 0, -4.4], "size": [4, 3, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "section_1",
				"parent": "section_2",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "section_1", "origin": [-3, 0, -2.4], "size": [6, 4, 5], "uv": [0, 5]}
				]
			},
			{
				"name": "section_3",
				"parent": "section_2",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "section_3", "origin": [-0.5, 0, 3.5], "size": [1, 2, 1], "uv": [0, 18]}
				]
			}
		]
	}`
};
skin_presets.evocation_fang = {
	display_name: 'Evocation Fang',
	model: `{
		"name": "evocation_fang",
		"external_textures": ["entity/illager/fangs.png"],
		"texturewidth": 64,
		"textureheight": 32,
		"bones": [
			{
				"name": "base",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "base", "origin": [-5, 0, -5], "size": [10, 12, 10], "uv": [0, 0]}
				]
			},
			{
				"name": "upper_jaw",
				"parent": "base",
				"pivot": [0, 11, 0],
				"rotation": [0, 180, -150],
				"cubes": [
					{"name": "upper_jaw", "origin": [-1.5, -4, -4], "size": [4, 14, 8], "uv": [40, 0], "inflate": 0.01}
				]
			},
			{
				"name": "lower_jaw",
				"parent": "base",
				"pivot": [0, 11, 0],
				"rotation": [0, 0, 150],
				"cubes": [
					{"name": "lower_jaw", "origin": [-1.5, -4, -4], "size": [4, 14, 8], "uv": [40, 0]}
				]
			}
		]
	}`
};
skin_presets.evoker = {
	display_name: 'Evoker',
	model: `{
		"name": "evoker",
		"external_textures": ["entity/illager/evoker.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "body",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "body", "origin": [-4, 12, -3], "size": [8, 12, 6], "uv": [16, 20]},
					{"name": "body", "origin": [-4, 6, -3], "size": [8, 18, 6], "uv": [0, 38], "inflate": 0.5}
				]
			},
			{
				"name": "Head",
				"parent": "body",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "Head", "origin": [-4, 24, -4], "size": [8, 10, 8], "uv": [0, 0]}
				]
			},
			{
				"name": "nose",
				"parent": "Head",
				"pivot": [0, 26, 0],
				"cubes": [
					{"name": "nose", "origin": [-1, 23, -6], "size": [2, 4, 2], "uv": [24, 0]}
				]
			},
			{
				"name": "arms",
				"parent": "body",
				"pivot": [0, 22, 0],
				"cubes": [
					{"name": "arms", "origin": [-8, 16, -2], "size": [4, 8, 4], "uv": [44, 22]},
					{"name": "arms", "origin": [4, 16, -2], "size": [4, 8, 4], "uv": [44, 22]},
					{"name": "arms", "origin": [-4, 16, -2], "size": [8, 4, 4], "uv": [40, 38]}
				]
			},
			{
				"name": "leg0",
				"parent": "body",
				"pivot": [-2, 12, 0],
				"cubes": [
					{"name": "leg0", "origin": [-4, 0, -2], "size": [4, 12, 4], "uv": [0, 22]}
				]
			},
			{
				"name": "leg1",
				"parent": "body",
				"pivot": [2, 12, 0],
				"mirror": true,
				"cubes": [
					{"name": "leg1", "origin": [0, 0, -2], "size": [4, 12, 4], "uv": [0, 22]}
				]
			},
			{
				"name": "RightArm",
				"parent": "body",
				"pivot": [-5, 22, 0],
				"cubes": [
					{"name": "RightArm", "origin": [-8, 12, -2], "size": [4, 12, 4], "uv": [40, 46]}
				]
			},
			{
				"name": "LeftArm",
				"parent": "body",
				"pivot": [5, 22, 0],
				"mirror": true,
				"cubes": [
					{"name": "LeftArm", "origin": [4, 12, -2], "size": [4, 12, 4], "uv": [40, 46]}
				]
			}
		]
	}`
};
skin_presets.fox = {
	display_name: 'Fox',
	model_bedrock: `{
		"name": "fox",
		"external_textures": ["entity/fox/fox.png"],
		"texturewidth": 64,
		"textureheight": 32,
		"bones": [
			{
				"name": "body",
				"pivot": [0, 8, 0],
				"rotation": [90, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-3, 0, -3], "size": [6, 11, 6], "uv": [30, 15]}
				]
			},
			{
				"name": "head",
				"pivot": [0, 8, -3],
				"cubes": [
					{"name": "head", "origin": [-4, 4, -9], "size": [8, 6, 6], "uv": [0, 0]},
					{"name": "head", "origin": [-4, 10, -8], "size": [2, 2, 1], "uv": [0, 0]},
					{"name": "head", "origin": [2, 10, -8], "size": [2, 2, 1], "uv": [22, 0]},
					{"name": "head", "origin": [-2, 4, -12], "size": [4, 2, 3], "uv": [0, 24]},
					{"name": "head_sleeping", "visibility": false, "origin": [-4, 4, -9], "size": [8, 6, 6], "uv": [0, 12]}
				]
			},
			{
				"name": "leg0",
				"pivot": [-3, 6, 6],
				"cubes": [
					{"name": "leg0", "origin": [-3.005, 0, 5], "size": [2, 6, 2], "uv": [14, 24]}
				]
			},
			{
				"name": "leg1",
				"pivot": [1, 6, 6],
				"cubes": [
					{"name": "leg1", "origin": [1.005, 0, 5], "size": [2, 6, 2], "uv": [22, 24]}
				]
			},
			{
				"name": "leg2",
				"pivot": [-3, 6, -1],
				"cubes": [
					{"name": "leg2", "origin": [-3.005, 0, -2], "size": [2, 6, 2], "uv": [14, 24]}
				]
			},
			{
				"name": "leg3",
				"pivot": [1, 6, -1],
				"cubes": [
					{"name": "leg3", "origin": [1.005, 0, -2], "size": [2, 6, 2], "uv": [22, 24]}
				]
			},
			{
				"name": "tail",
				"pivot": [0, 8, 7],
				"rotation": [90, 0, 0],
				"cubes": [
					{"name": "tail", "origin": [-2, -2, 4.75], "size": [4, 9, 5], "uv": [28, 0]}
				]
			}
		]
	}`,
	model_java: `{
		"name": "fox",
		"texturewidth": 48,
		"textureheight": 32,
		"bones": [
			{
				"name": "body",
				"pivot": [0, 8, 0],
				"rotation": [90, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-3, 0, -3], "size": [6, 11, 6], "uv": [24, 15]}
				]
			},
			{
				"name": "head",
				"pivot": [0, 8, -3],
				"cubes": [
					{"name": "head", "origin": [-4, 4, -9], "size": [8, 6, 6], "uv": [1, 5]},
					{"name": "head", "origin": [-4, 10, -8], "size": [2, 2, 1], "uv": [8, 1]},
					{"name": "head", "origin": [2, 10, -8], "size": [2, 2, 1], "uv": [15, 1]},
					{"name": "head", "origin": [-2, 4, -12], "size": [4, 2, 3], "uv": [6, 18]}
				]
			},
			{
				"name": "leg0",
				"pivot": [-3, 6, 6],
				"cubes": [
					{"name": "leg0", "origin": [-3.005, 0, 5], "size": [2, 6, 2], "uv": [13, 24]}
				]
			},
			{
				"name": "leg1",
				"pivot": [1, 6, 6],
				"cubes": [
					{"name": "leg1", "origin": [1.005, 0, 5], "size": [2, 6, 2], "uv": [4, 24]}
				]
			},
			{
				"name": "leg2",
				"pivot": [-3, 6, -1],
				"cubes": [
					{"name": "leg2", "origin": [-3.005, 0, -2], "size": [2, 6, 2], "uv": [13, 24]}
				]
			},
			{
				"name": "leg3",
				"pivot": [1, 6, -1],
				"cubes": [
					{"name": "leg3", "origin": [1.005, 0, -2], "size": [2, 6, 2], "uv": [4, 24]}
				]
			},
			{
				"name": "tail",
				"pivot": [0, 8, 7],
				"rotation": [90, 0, 0],
				"cubes": [
					{"name": "tail", "origin": [-2, -2, 4.75], "size": [4, 9, 5], "uv": [30, 0]}
				]
			}
		]
	}`
};
skin_presets.fox_baby = {
	display_name: 'Fox Baby',
	model: `{
		"name": "fox_baby",
		"texturewidth": 32,
		"textureheight": 32,
		"eyes": [
			[6, 7, 1, 1],
			[9, 7, 1, 1]
		],
		"bones": [
			{
				"name": "root",
				"pivot": [0, 0, 0]
			},
			{
				"name": "head",
				"parent": "root",
				"pivot": [0, 5.875, 0.125],
				"cubes": [
					{"origin": [-3, 3, -5], "size": [6, 5, 5], "uv": [0, 0]},
					{"origin": [-1, 3, -7], "size": [2, 2, 2], "uv": [18, 20]},
					{"origin": [-3, 8, -4], "size": [2, 2, 1], "uv": [22, 8]},
					{"origin": [1, 8, -4], "size": [2, 2, 1], "uv": [22, 11]}
				]
			},
			{
				"name": "held_item",
				"parent": "head",
				"pivot": [-2.25, 2.3, -9]
			},
			{
				"name": "leg0",
				"parent": "root",
				"pivot": [-1.5, 2, 4],
				"cubes": [
					{"origin": [-2.5, 0, 3], "size": [2, 2, 2], "uv": [22, 4]}
				]
			},
			{
				"name": "leg1",
				"parent": "root",
				"pivot": [1.5, 2, 4],
				"cubes": [
					{"origin": [0.5, 0, 3], "size": [2, 2, 2], "uv": [22, 0]}
				]
			},
			{
				"name": "leg2",
				"parent": "root",
				"pivot": [-1.5, 2, 0],
				"cubes": [
					{"origin": [-2.5, 0, -1], "size": [2, 2, 2], "uv": [22, 4]}
				]
			},
			{
				"name": "leg3",
				"parent": "root",
				"pivot": [1.5, 2, 0],
				"cubes": [
					{"origin": [0.5, 0, -1], "size": [2, 2, 2], "uv": [22, 0]}
				]
			},
			{
				"name": "body",
				"parent": "root",
				"pivot": [0, 4, 2],
				"cubes": [
					{"origin": [-2.5, 2, -1], "size": [5, 4, 6], "uv": [0, 10]}
				]
			},
			{
				"name": "lead",
				"parent": "body",
				"pivot": [0, 3, -2]
			},
			{
				"name": "tail",
				"parent": "body",
				"pivot": [0, 4.5, 5],
				"cubes": [
					{"origin": [-1.5, 2.98, 4], "size": [3, 3, 6], "uv": [0, 20]}
				]
			}
		]
	}`
};
skin_presets.frog = {
	display_name: 'Frog',
	model: `{
		"name": "frog",
		"external_textures": ["entity/frog/temperate_frog.png"],
		"texturewidth": 48,
		"textureheight": 48,
		"eyes": [
			[2, 4, 5, 1],
			[2, 9, 5, 1]
		],
		"bones": [
			{
				"name": "root",
				"pivot": [0, 0, 0]
			},
			{
				"name": "body",
				"parent": "root",
				"pivot": [0, 2, 4],
				"cubes": [
					{"origin": [-3.5, 1, -4], "size": [7, 3, 9], "uv": [3, 1]},
					{"origin": [-3.5, 3, -4], "size": [7, 0, 9], "uv": [23, 22]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 4, 3],
				"cubes": [
					{"origin": [-3.5, 5, -4], "size": [7, 0, 9], "uv": [23, 13]},
					{"origin": [-3.5, 3, -4], "size": [7, 3, 9], "uv": [0, 13]}
				]
			},
			{
				"name": "eyes",
				"parent": "head",
				"pivot": [-0.5, 4, 5]
			},
			{
				"name": "right_eye",
				"parent": "eyes",
				"pivot": [-2, 7, -1.5],
				"cubes": [
					{"origin": [-3.5, 6, -3], "size": [3, 2, 3], "uv": [0, 0]}
				]
			},
			{
				"name": "left_eye",
				"parent": "eyes",
				"pivot": [2, 7, -1.5],
				"cubes": [
					{"origin": [0.5, 6, -3], "size": [3, 2, 3], "uv": [0, 5]}
				]
			},
			{
				"name": "croaking_body",
				"parent": "body",
				"pivot": [0, 3, -1],
				"cubes": [
					{"origin": [-3.5, 1.1, -3.9], "size": [7, 2, 3], "inflate": -0.1, "uv": [26, 5]}
				]
			},
			{
				"name": "tongue",
				"parent": "body",
				"pivot": [0, 3.1, 5],
				"cubes": [
					{"origin": [-2, 3.1, -2.1], "size": [4, 0, 7], "uv": [17, 13]}
				]
			},
			{
				"name": "left_arm",
				"parent": "body",
				"pivot": [4, 3, -2.5],
				"cubes": [
					{"origin": [3, 0, -3.5], "size": [2, 3, 3], "uv": [0, 32]},
					{"origin": [0, -0.01, -7.5], "size": [8, 0, 8], "uv": [18, 40], "layer": true}
				]
			},
			{
				"name": "right_arm",
				"parent": "body",
				"pivot": [-4, 3, -2.5],
				"cubes": [
					{"origin": [-5, 0, -3.5], "size": [2, 3, 3], "uv": [0, 38]},
					{"origin": [-8, -0.01, -7.5], "size": [8, 0, 8], "uv": [2, 40], "layer": true}
				]
			},
			{
				"name": "left_leg",
				"parent": "root",
				"pivot": [3.5, 3, 4],
				"cubes": [
					{"origin": [2.5, 0, 2], "size": [3, 3, 4], "uv": [14, 25]},
					{"origin": [1.5, -0.01, 0], "size": [8, 0, 8], "uv": [2, 32], "layer": true}
				]
			},
			{
				"name": "right_leg",
				"parent": "root",
				"pivot": [-3.5, 3, 4],
				"cubes": [
					{"origin": [-5.5, 0, 2], "size": [3, 3, 4], "uv": [0, 25]},
					{"origin": [-9.5, -0.01, 0], "size": [8, 0, 8], "uv": [18, 32], "layer": true}
				]
			}
		]
	}`
};
skin_presets.ghast = {
	display_name: 'Ghast',
	model: `{
		"name": "ghast",
		"external_textures": ["entity/ghast/ghast.png"],
		"texturewidth": 64,
		"textureheight": 32,
		"default_resolution": 32,
		"eyes": [
			[19, 21, 3, 1],
			[26, 21, 3, 1]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [0, 8, 0],
				"cubes": [
					{"name": "body", "origin": [-8, 0, -8], "size": [16, 16, 16], "uv": [0, 0]}
				]
			},
			{
				"name": "tentacles_0",
				"parent": "body",
				"pivot": [-3.8, 1, -5],
				"cubes": [
					{"name": "tentacles_0", "origin": [-4.8, -8, -6], "size": [2, 9, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "tentacles_1",
				"parent": "body",
				"pivot": [1.3, 1, -5],
				"cubes": [
					{"name": "tentacles_1", "origin": [0.3, -10, -6], "size": [2, 11, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "tentacles_2",
				"parent": "body",
				"pivot": [6.3, 1, -5],
				"cubes": [
					{"name": "tentacles_2", "origin": [5.3, -7, -6], "size": [2, 8, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "tentacles_3",
				"parent": "body",
				"pivot": [-6.3, 1, 0],
				"cubes": [
					{"name": "tentacles_3", "origin": [-7.3, -8, -1], "size": [2, 9, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "tentacles_4",
				"parent": "body",
				"pivot": [-1.3, 1, 0],
				"cubes": [
					{"name": "tentacles_4", "origin": [-2.3, -12, -1], "size": [2, 13, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "tentacles_5",
				"parent": "body",
				"pivot": [3.8, 1, 0],
				"cubes": [
					{"name": "tentacles_5", "origin": [2.8, -10, -1], "size": [2, 11, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "tentacles_6",
				"parent": "body",
				"pivot": [-3.8, 1, 5],
				"cubes": [
					{"name": "tentacles_6", "origin": [-4.8, -11, 4], "size": [2, 12, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "tentacles_7",
				"parent": "body",
				"pivot": [1.3, 1, 5],
				"cubes": [
					{"name": "tentacles_7", "origin": [0.3, -11, 4], "size": [2, 12, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "tentacles_8",
				"parent": "body",
				"pivot": [6.3, 1, 5],
				"cubes": [
					{"name": "tentacles_8", "origin": [5.3, -12, 4], "size": [2, 13, 2], "uv": [0, 0]}
				]
			}
		]
	}`
};
skin_presets.goat = {
	display_name: 'Goat',
	model: `{
		"name": "goat",
		"external_textures": ["entity/goat/goat.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "left_back_leg",
				"pivot": [1, 10, 4],
				"cubes": [
					{"origin": [1, 0, 4], "size": [3, 6, 3], "uv": [36, 29]}
				]
			},
			{
				"name": "right_back_leg",
				"pivot": [-3, 10, 4],
				"cubes": [
					{"origin": [-3, 0, 4], "size": [3, 6, 3], "uv": [49, 29]}
				]
			},
			{
				"name": "right_front_leg",
				"pivot": [-3, 10, -6],
				"cubes": [
					{"origin": [-3, 0, -6], "size": [3, 10, 3], "uv": [49, 2]}
				]
			},
			{
				"name": "left_front_leg",
				"pivot": [1, 10, -6],
				"cubes": [
					{"origin": [1, 0, -6], "size": [3, 10, 3], "uv": [35, 2]}
				]
			},
			{
				"name": "body",
				"pivot": [0, 0, 0],
				"cubes": [
					{"origin": [-4, 6, -7], "size": [9, 11, 16], "uv": [1, 1]},
					{"origin": [-5, 4, -8], "size": [11, 14, 11], "uv": [0, 28]}
				]
			},
			{
				"name": "Head",
				"pivot": [1, 10, 0],
				"cubes": [
					{"origin": [-2, 15, -16], "size": [5, 7, 10], "pivot": [1, 18, -8], "rotation": [55, 0, 0], "uv": [34, 46]},
					{"origin": [-1.99, 19, -10], "size": [2, 7, 2], "uv": [12, 55]},
					{"origin": [0.99, 19, -10], "size": [2, 7, 2], "uv": [12, 55]},
					{"origin": [3, 19, -10], "size": [3, 2, 1], "uv": [2, 61], "mirror": true},
					{"origin": [-5, 19, -10], "size": [3, 2, 1], "uv": [2, 61]},
					{"origin": [0.5, 6, -14], "size": [0, 7, 5], "uv": [23, 52]}
				]
			},
			{
				"name": "Head Main",
				"parent": "Head",
				"pivot": [1, 18, -8],
				"rotation": [55, 0, 0],
				"cubes": [
					{"origin": [-2, 15, -16], "size": [5, 7, 10], "pivot": [1, 18, -8], "uv": [34, 46]}
				]
			}
		]
	}`
};
skin_presets.goat_baby = {
	display_name: 'Goat Baby',
	model: `{
		"name": "goat_baby",
		"texturewidth": 64,
		"textureheight": 64,
		"external_textures": ["entity/goat/goat_baby.png"],
		"eyes": [
			[2, 7, 1, 1],
			[13, 7, 1, 1]
		],
		"bones": [
			{
				"name": "left_back_leg",
				"pivot": [1.5, 4.5, 3],
				"cubes": [
					{"origin": [0.5, 0, 2], "size": [2, 5, 2], "uv": [29, 12]}
				]
			},
			{
				"name": "right_back_leg",
				"pivot": [-1.5, 4.5, 3],
				"cubes": [
					{"origin": [-2.5, 0, 2], "size": [2, 5, 2], "uv": [21, 12]}
				]
			},
			{
				"name": "right_front_leg",
				"pivot": [-1.5, 4.5, -2],
				"cubes": [
					{"origin": [-2.5, 0, -3], "size": [2, 5, 2], "uv": [21, 5]}
				]
			},
			{
				"name": "left_front_leg",
				"pivot": [1.5, 4.5, -2],
				"cubes": [
					{"origin": [0.5, 0, -3], "size": [2, 5, 2], "uv": [29, 5]}
				]
			},
			{
				"name": "body",
				"pivot": [0, 6.2, 0],
				"cubes": [
					{"origin": [-3, 3.5, -4.5], "size": [6, 5, 9], "uv": [0, 10]},
					{"origin": [-2.5, 4.4, -4], "size": [5, 4, 8], "uv": [0, 24]}
				]
			},
			{
				"name": "head",
				"pivot": [0, 10.5, -3],
				"rotation": [25, 0, 0],
				"cubes": [
					{"origin": [-2, 8.5, -9], "size": [4, 4, 6], "uv": [0, 0]},
					{"origin": [1.7, 10.5, -4.2], "size": [2, 1, 1], "pivot": [1.7, 11, -3.7], "rotation": [0, 30, 0], "uv": [0, 12]},
					{"origin": [-3.7, 10.5, -4.2], "size": [2, 1, 1], "pivot": [-1.7, 11, -3.7], "rotation": [0, -30, 0], "uv": [0, 12], "mirror": true},
					{"origin": [0.5, 12.5, -3.9], "size": [1, 2, 1], "pivot": [1.5, 12.5, -3.9], "rotation": [-25, 0, 0], "uv": [24, 0]},
					{"origin": [-1.5, 12.5, -3.9], "size": [1, 2, 1], "pivot": [-1.5, 12.5, -3.9], "rotation": [-25, 0, 0], "uv": [24, 0], "mirror": true}
				]
			}
		]
	}`
}
skin_presets.guardian = {
	display_name: 'Guardian',
	model: `{
		"name": "guardian",
		"external_textures": ["entity/guardian.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"eyes": [
			[19, 21, 6, 3]
		],
		"bones": [
			{
				"name": "head",
				"pivot": [0, 0, 0],
				"mirror": true,
				"cubes": [
					{"name": "head", "origin": [-6, 2, -8], "size": [12, 12, 16], "uv": [0, 0], "mirror": false},
					{"name": "head", "origin": [-8, 2, -6], "size": [2, 12, 12], "uv": [0, 28], "mirror": false},
					{"name": "head", "origin": [6, 2, -6], "size": [2, 12, 12], "uv": [0, 28]},
					{"name": "head", "origin": [-6, 14, -6], "size": [12, 2, 12], "uv": [16, 40]},
					{"name": "head", "origin": [-6, 0, -6], "size": [12, 2, 12], "uv": [16, 40]}
				]
			},
			{
				"name": "eye",
				"parent": "head",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "eye", "origin": [-1, 7, -8.25], "size": [2, 2, 1], "uv": [8, 0]}
				]
			},
			{
				"name": "tailpart0",
				"parent": "head",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "tailpart0", "origin": [-2, 6, 8], "size": [4, 4, 8], "uv": [40, 0]}
				]
			},
			{
				"name": "tailpart1",
				"parent": "tailpart0",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "tailpart1", "origin": [-1.5, 7, 16], "size": [3, 3, 7], "uv": [0, 54]}
				]
			},
			{
				"name": "tailpart2",
				"parent": "tailpart1",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "tailpart2", "origin": [-1, 8, 23], "size": [2, 2, 6], "uv": [41, 32]},
					{"name": "tailpart2", "origin": [0, 4.5, 26], "size": [1, 9, 9], "uv": [25, 19]}
				]
			},
			{
				"name": "spikepart0",
				"parent": "head",
				"pivot": [0, 24, 0],
				"rotation": [0, 0, 45],
				"cubes": [
					{"name": "spikepart0", "origin": [10.25, 19.5, -1], "size": [2, 9, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "spikepart1",
				"parent": "head",
				"pivot": [0, 24, 0],
				"rotation": [0, 0, -45],
				"cubes": [
					{"name": "spikepart1", "origin": [-12.25, 19.5, -1], "size": [2, 9, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "spikepart2",
				"parent": "head",
				"pivot": [0, 24, 0],
				"rotation": [45, 0, 0],
				"cubes": [
					{"name": "spikepart2", "origin": [-1, 19.5, -12.25], "size": [2, 9, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "spikepart3",
				"parent": "head",
				"pivot": [0, 24, 0],
				"rotation": [-45, 0, 0],
				"cubes": [
					{"name": "spikepart3", "origin": [-1, 19.5, 10.5], "size": [2, 9, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "spikepart4",
				"parent": "head",
				"pivot": [0, 24, 0],
				"rotation": [0, 0, 135],
				"cubes": [
					{"name": "spikepart4", "origin": [10.25, 42.5, -1], "size": [2, 9, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "spikepart5",
				"parent": "head",
				"pivot": [0, 24, 0],
				"rotation": [0, 0, -135],
				"cubes": [
					{"name": "spikepart5", "origin": [-12.25, 42.5, -1], "size": [2, 9, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "spikepart6",
				"parent": "head",
				"pivot": [0, 24, 0],
				"rotation": [135, 0, 0],
				"cubes": [
					{"name": "spikepart6", "origin": [-1, 43.5, -12.25], "size": [2, 9, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "spikepart7",
				"parent": "head",
				"pivot": [0, 24, 0],
				"rotation": [-135, 0, 0],
				"cubes": [
					{"name": "spikepart7", "origin": [-1, 42.5, 10.25], "size": [2, 9, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "spikepart8",
				"parent": "head",
				"pivot": [0, 24, 0],
				"rotation": [90, -45, 0],
				"cubes": [
					{"name": "spikepart8", "origin": [-1, 32.5, -17], "size": [2, 9, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "spikepart9",
				"parent": "head",
				"pivot": [0, 24, 0],
				"rotation": [90, 45, 0],
				"cubes": [
					{"name": "spikepart8", "origin": [-1, 32.5, -17], "size": [2, 9, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "spikepart10",
				"parent": "head",
				"pivot": [0, 24, 0],
				"rotation": [90, -135, 0],
				"cubes": [
					{"name": "spikepart8", "origin": [-1, 32.5, -17], "size": [2, 9, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "spikepart11",
				"parent": "head",
				"pivot": [0, 24, 0],
				"rotation": [90, 135, 0],
				"cubes": [
					{"name": "spikepart8", "origin": [-1, 32.5, -17], "size": [2, 9, 2], "uv": [0, 0]}
				]
			}
		]
	}`
};
skin_presets.happy_ghast = {
	display_name: 'Happy Ghast',
	model: `{
		"name": "happy_ghast",
		"external_textures": ["entity/happy_ghast/adult.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"default_resolution": 32,
		"eyes": [
			[18, 24, 3, 1],
			[27, 24, 3, 1]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [0, 0, 0],
				"cubes": [
					{"origin": [-8, 0, -8], "size": [16, 16, 16], "uv": [0, 0]},
					{"origin": [-8, 0, -8], "size": [16, 16, 16], "inflate": -0.5, "uv": [0, 32]}
				]
			},
			{
				"name": "tentacles_0",
				"parent": "body",
				"pivot": [-3.8, 1, -5],
				"cubes": [
					{"origin": [-4.8, -4, -6], "size": [2, 5, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "tentacles_1",
				"parent": "body",
				"pivot": [1.3, 1, -5],
				"cubes": [
					{"origin": [0.3, -6, -6], "size": [2, 7, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "tentacles_2",
				"parent": "body",
				"pivot": [6.3, 1, -5],
				"cubes": [
					{"origin": [5.3, -3, -6], "size": [2, 4, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "tentacles_3",
				"parent": "body",
				"pivot": [-6.3, 1, 0],
				"cubes": [
					{"origin": [-7.3, -4, -1], "size": [2, 5, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "tentacles_4",
				"parent": "body",
				"pivot": [-1.3, 1, 0],
				"cubes": [
					{"origin": [-2.3, -4, -1], "size": [2, 5, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "tentacles_5",
				"parent": "body",
				"pivot": [3.8, 1, 0],
				"cubes": [
					{"origin": [2.8, -6, -1], "size": [2, 7, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "tentacles_6",
				"parent": "body",
				"pivot": [-3.8, 1, 5],
				"cubes": [
					{"origin": [-4.8, -7, 4], "size": [2, 8, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "tentacles_7",
				"parent": "body",
				"pivot": [1.3, 1, 5],
				"cubes": [
					{"origin": [0.3, -7, 4], "size": [2, 8, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "tentacles_8",
				"parent": "body",
				"pivot": [6.3, 1, 5],
				"cubes": [
					{"origin": [5.3, -4, 4], "size": [2, 5, 2], "uv": [0, 0]}
				]
			}
		]
	}`
};
skin_presets.harness = {
	display_name: 'Happy Ghast Harness',
	model: `{
		"name": "harness",
		"external_textures": ["entity/harness/harness_white.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"default_resolution": 32,
		"bones": [
			{
				"name": "body",
				"pivot": [0, 0, 0],
				"cubes": [
					{"origin": [-8, 0.5, -8], "size": [16, 16, 16], "inflate": 0.5, "uv": [0, 0]}
				]
			},
			{
				"name": "goggles",
				"parent": "body",
				"pivot": [0, 11.5, -5.5],
				"cubes": [
					{"origin": [-8, 7.5, -8], "size": [16, 5, 5], "inflate": 0.65, "uv": [0, 32]}
				]
			}
		]
	}`
};
skin_presets.hoglin = {
	display_name: 'Hoglin',
	model: `{
		"name": "hoglin",
		"external_textures": ["entity/hoglin/hoglin.png"],
		"texturewidth": 128,
		"textureheight": 64,
		"bones": [
			{
				"name": "body",
				"pivot": [0, 19, -3],
				"cubes": [
					{"origin": [-8, 11, -7], "size": [16, 14, 26], "inflate": 0.02, "uv": [1, 1]},
					{"origin": [0, 22, -10], "size": [0, 10, 19], "inflate": 0.02, "uv": [90, 33]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 22, -5],
				"rotation": [50, 0, 0],
				"cubes": [
					{"origin": [-7, 21, -24], "size": [14, 6, 19], "uv": [61, 1]},
					{"origin": [-8, 22, -19], "size": [2, 11, 2], "uv": [1, 13]},
					{"origin": [6, 22, -19], "size": [2, 11, 2], "uv": [1, 13]}
				]
			},
			{
				"name": "right_ear",
				"parent": "head",
				"pivot": [-7, 27, -7],
				"rotation": [0, 0, -50],
				"cubes": [
					{"origin": [-13, 26, -10], "size": [6, 1, 4], "uv": [1, 1]}
				]
			},
			{
				"name": "left_ear",
				"parent": "head",
				"pivot": [7, 27, -7],
				"rotation": [0, 0, 50],
				"cubes": [
					{"origin": [7, 26, -10], "size": [6, 1, 4], "uv": [1, 6]}
				]
			},
			{
				"name": "leg_back_right",
				"pivot": [6, 8, 17],
				"cubes": [
					{"origin": [-8, 0, 13], "size": [5, 11, 5], "uv": [21, 45]}
				]
			},
			{
				"name": "leg_back_left",
				"pivot": [-6, 8, 17],
				"cubes": [
					{"origin": [3, 0, 13], "size": [5, 11, 5], "uv": [0, 45]}
				]
			},
			{
				"name": "leg_front_right",
				"pivot": [-6, 12, -3],
				"cubes": [
					{"origin": [-8, 0, -6], "size": [6, 14, 6], "uv": [66, 42]}
				]
			},
			{
				"name": "leg_front_left",
				"pivot": [6, 12, -3],
				"cubes": [
					{"origin": [2, 0, -6], "size": [6, 14, 6], "uv": [41, 42]}
				]
			}
		]
	}`
};
skin_presets.hoglin_baby = {
	display_name: 'Hoglin Baby',
	model: `{
		"name": "hoglin_baby",
		"texturewidth": 64,
		"textureheight": 64,
		"external_textures": ["entity/hoglin/hoglin_baby.png"],
		"eyes": [
			[13, 4, 2, 2],
			[19, 4, 2, 2]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [0, 0, 0],
				"cubes": [
					{"origin": [-4, 6, -7], "size": [8, 8, 14], "inflate": 0.02, "uv": [0, 16]},
					{"origin": [0, 12, -8], "size": [0, 6, 11], "inflate": 0.02, "uv": [24, 39]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 11, -7],
				"rotation": [50, 0, 0],
				"cubes": [
					{"origin": [-5, 9.26046, -17.54701], "size": [10, 4, 12], "uv": [0, 0]},
					{"origin": [-7, 10.09814, -15.48793], "size": [2, 5, 2], "uv": [44, 29]},
					{"origin": [5, 10.09814, -15.48793], "size": [2, 5, 2], "uv": [52, 29]}
				]
			},
			{
				"name": "right_ear",
				"parent": "head",
				"pivot": [-5, 12, -8.5],
				"rotation": [0, 0, -50],
				"cubes": [
					{"origin": [-10.1, 11.5, -10.5], "size": [6, 1, 4], "uv": [32, 5]}
				]
			},
			{
				"name": "left_ear",
				"parent": "head",
				"pivot": [5, 12, -8.5],
				"rotation": [0, 0, 50],
				"cubes": [
					{"origin": [4.1, 11.5, -10.5], "size": [6, 1, 4], "uv": [32, 0], "mirror": true}
				]
			},
			{
				"name": "leg_back_right",
				"parent": "body",
				"pivot": [-2.5, 6, 4.5],
				"cubes": [
					{"origin": [-4, 0, 3], "size": [3, 6, 3], "uv": [0, 47]}
				]
			},
			{
				"name": "leg_back_left",
				"parent": "body",
				"pivot": [2.5, 6, 4.5],
				"cubes": [
					{"origin": [1, 0, 3], "size": [3, 6, 3], "uv": [12, 47]}
				]
			},
			{
				"name": "leg_front_right",
				"parent": "body",
				"pivot": [-2.5, 6, -4.5],
				"cubes": [
					{"origin": [-4, 0, -6], "size": [3, 6, 3], "uv": [0, 38]}
				]
			},
			{
				"name": "leg_front_left",
				"parent": "body",
				"pivot": [2.5, 6, -4.5],
				"cubes": [
					{"origin": [1, 0, -6], "size": [3, 6, 3], "uv": [12, 38]}
				]
			}
		]
	}`
};
skin_presets.horse = {
	display_name: 'Horse',
	model: `{
		"name": "horse",
		"external_textures": ["entity/horse2/horse_gray.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "Body",
				"pivot": [0, 13, 9],
				"cubes": [
					{"name": "Body", "origin": [-5, 11, -11], "size": [10, 10, 22], "uv": [0, 32]}
				]
			},
			{
				"name": "TailA",
				"pivot": [0, 20, 11],
				"rotation": [30, 0, 0],
				"cubes": [
					{"name": "TailA", "origin": [-1.5, 6, 9], "size": [3, 14, 4], "uv": [42, 36]}
				]
			},
			{
				"name": "Leg1A",
				"pivot": [3, 11, 9],
				"cubes": [
					{"name": "Leg1A", "origin": [1, 0, 7], "size": [4, 11, 4], "uv": [48, 21], "mirror": true}
				]
			},
			{
				"name": "Leg2A",
				"pivot": [-3, 11, 9],
				"cubes": [
					{"name": "Leg2A", "origin": [-5, 0, 7], "size": [4, 11, 4], "uv": [48, 21]}
				]
			},
			{
				"name": "Leg3A",
				"pivot": [3, 11, -9],
				"cubes": [
					{"name": "Leg3A", "origin": [1, 0, -11], "size": [4, 11, 4], "uv": [48, 21], "mirror": true}
				]
			},
			{
				"name": "Leg4A",
				"pivot": [-3, 11, -9],
				"cubes": [
					{"name": "Leg4A", "origin": [-5, 0, -11], "size": [4, 11, 4], "uv": [48, 21]}
				]
			},
			{
				"name": "Head",
				"pivot": [0, 28, -11],
				"rotation": [30, 0, 0],
				"cubes": [
					{"name": "Head", "origin": [-3, 28, -17], "size": [6, 5, 7], "uv": [0, 13]},
					{"name": "UMouth", "origin": [-2, 28, -22], "size": [4, 5, 5], "uv": [0, 25]}
				]
			},
			{
				"name": "Ear1",
				"pivot": [0, 17, -8],
				"rotation": [30, 0, 5],
				"cubes": [
					{"name": "Ear1", "origin": [-0.5, 32, -5.01], "size": [2, 3, 1], "uv": [19, 16], "mirror": true}
				]
			},
			{
				"name": "Ear2",
				"pivot": [0, 17, -8],
				"rotation": [30, 0, -5],
				"cubes": [
					{"name": "Ear2", "origin": [-1.5, 32, -5.01], "size": [2, 3, 1], "uv": [19, 16]}
				]
			},
			{
				"name": "MuleEarL",
				"pivot": [0, 17, -8],
				"rotation": [30, 0, 15],
				"cubes": [
					{"name": "MuleEarL", "visibility": false, "origin": [-3, 32, -5.01], "size": [2, 7, 1], "uv": [0, 12], "mirror": true}
				]
			},
			{
				"name": "MuleEarR",
				"pivot": [0, 17, -8],
				"rotation": [30, 0, -15],
				"cubes": [
					{"name": "MuleEarR", "visibility": false, "origin": [1, 32, -5.01], "size": [2, 7, 1], "uv": [0, 12]}
				]
			},
			{
				"name": "Neck",
				"pivot": [0, 17, -8],
				"rotation": [30, 0, 0],
				"cubes": [
					{"name": "Neck", "origin": [-2, 16, -11], "size": [4, 12, 7], "uv": [0, 35]},
					{"name": "Mane", "origin": [-1, 17, -4], "size": [2, 16, 2], "uv": [56, 36]}
				]
			},
			{
				"name": "Bag1",
				"pivot": [-5, 21, 11],
				"rotation": [0, -90, 0],
				"cubes": [
					{"name": "Bag1", "visibility": false, "origin": [-14, 13, 11], "size": [8, 8, 3], "uv": [26, 21]}
				]
			},
			{
				"name": "Bag2",
				"pivot": [5, 21, 11],
				"rotation": [0, 90, 0],
				"cubes": [
					{"name": "Bag2", "visibility": false, "origin": [6, 13, 11], "size": [8, 8, 3], "uv": [26, 21], "mirror": true}
				]
			},
			{
				"name": "Saddle",
				"pivot": [0, 22, 2],
				"cubes": [
					{"name": "Saddle", "origin": [-5, 12, -3.5], "size": [10, 9, 9], "uv": [26, 0], "inflate": 0.5}
				]
			},
			{
				"name": "SaddleMouthL",
				"pivot": [0, 17, -8],
				"rotation": [30, 0, 0],
				"cubes": [
					{"name": "SaddleMouthL", "origin": [2, 29, -14], "size": [1, 2, 2], "uv": [29, 5]}
				]
			},
			{
				"name": "SaddleMouthR",
				"pivot": [0, 17, -8],
				"rotation": [30, 0, 0],
				"cubes": [
					{"name": "SaddleMouthR", "origin": [-3, 29, -14], "size": [1, 2, 2], "uv": [29, 5]}
				]
			},
			{
				"name": "SaddleMouthLine",
				"pivot": [0, 17, -8],
				"cubes": [
					{"name": "SaddleMouthLine", "origin": [3.1, 24, -19.5], "size": [0, 3, 16], "uv": [32, 2]}
				]
			},
			{
				"name": "SaddleMouthLineR",
				"pivot": [0, 17, -8],
				"cubes": [
					{"name": "SaddleMouthLineR", "origin": [-3.1, 24, -19.5], "size": [0, 3, 16], "uv": [32, 2]}
				]
			},
			{
				"name": "HeadSaddle",
				"pivot": [0, 17, -8],
				"rotation": [30, 0, 0],
				"cubes": [
					{"name": "HeadSaddle", "origin": [-2, 28, -13], "size": [4, 5, 2], "uv": [19, 0], "inflate": 0.25},
					{"name": "HeadSaddle", "visibility": false, "origin": [-3, 28, -11], "size": [6, 5, 7], "uv": [0, 0], "inflate": 0.25}
				]
			}
		]
	}`
};
skin_presets.horse_baby = {
	display_name: 'Horse Baby',
	model: `{
		"name": "horse_baby",
		"texturewidth": 64,
		"textureheight": 64,
		"external_textures": ["entity/horse2/horse_brown_baby.png"],
		"eyes": [
			[2, 10, 2, 1],
			[20, 10, 2, 1]
		],
		"bones": [
			{
				"name": "Body",
				"pivot": [0, 11.5, 0],
				"cubes": [
					{"origin": [-4, 8, -7], "size": [8, 7, 14], "uv": [0, 13]}
				]
			},
			{
				"name": "Tail",
				"parent": "Body",
				"pivot": [0, 12.5, 7],
				"rotation": [-42.5, 0, 0],
				"cubes": [
					{"origin": [-1.5, 11, 6], "size": [3, 3, 8], "uv": [24, 34]}
				]
			},
			{
				"name": "LegBL",
				"parent": "Body",
				"pivot": [2.4, 8, 5.4],
				"cubes": [
					{"origin": [0.9, 0, 3.9], "size": [3, 9, 3], "uv": [12, 46]}
				]
			},
			{
				"name": "LegBR",
				"parent": "Body",
				"pivot": [-2.4, 8, 5.4],
				"cubes": [
					{"origin": [-3.9, 0, 3.9], "size": [3, 9, 3], "uv": [0, 46]}
				]
			},
			{
				"name": "LegFL",
				"parent": "Body",
				"pivot": [2.4, 8, -5.4],
				"cubes": [
					{"origin": [0.9, 0, -6.9], "size": [3, 9, 3], "uv": [12, 34]}
				]
			},
			{
				"name": "LegFR",
				"parent": "Body",
				"pivot": [-2.4, 8, -5.4],
				"cubes": [
					{"origin": [-3.9, 0, -6.9], "size": [3, 9, 3], "uv": [0, 34]}
				]
			},
			{
				"name": "Neck",
				"parent": "Body",
				"pivot": [0, 14, -6],
				"rotation": [35, 0, 0],
				"cubes": [
					{"origin": [-2, 12, -8], "size": [4, 8, 4], "uv": [30, 0]}
				]
			},
			{
				"name": "Head",
				"parent": "Neck",
				"pivot": [0, 20.05164, -6.29505],
				"cubes": [
					{"origin": [-3, 20, -13], "size": [6, 4, 9], "uv": [0, 0]}
				]
			},
			{
				"name": "EarL",
				"parent": "Head",
				"pivot": [2, 24.3, -4.35],
				"rotation": [0, 0, 15],
				"cubes": [
					{"origin": [1, 23.8, -5.15], "size": [2, 3, 1], "uv": [0, 4]}
				]
			},
			{
				"name": "EarR",
				"parent": "Head",
				"pivot": [-2, 24.3, -4.65],
				"rotation": [0, 0, -15],
				"cubes": [
					{"origin": [-3, 23.8, -5.15], "size": [2, 3, 1], "uv": [0, 0]}
				]
			}
		]
	}`
};
skin_presets.irongolem = {
	display_name: 'Iron Golem',
	model: `{
		"name": "irongolem",
		"external_textures": ["entity/iron_golem.png"],
		"texturewidth": 128,
		"textureheight": 128,
		"bones": [
			{
				"name": "body",
				"pivot": [0, 31, 0],
				"cubes": [
					{"name": "body", "origin": [-9, 21, -6], "size": [18, 12, 11], "uv": [0, 40]},
					{"name": "body", "origin": [-4.5, 16, -3], "size": [9, 5, 6], "uv": [0, 70], "inflate": 0.5}
				]
			},
			{
				"name": "Head",
				"parent": "body",
				"pivot": [0, 31, -2],
				"cubes": [
					{"name": "head", "origin": [-4, 33, -7.5], "size": [8, 10, 8], "uv": [0, 0]},
					{"name": "head", "origin": [-1, 32, -9.5], "size": [2, 4, 2], "uv": [24, 0]}
				]
			},
			{
				"name": "arm0",
				"parent": "body",
				"pivot": [0, 31, 0],
				"cubes": [
					{"name": "arm0", "origin": [-13, 3.5, -3], "size": [4, 30, 6], "uv": [60, 21]}
				]
			},
			{
				"name": "arm1",
				"parent": "body",
				"pivot": [0, 31, 0],
				"cubes": [
					{"name": "arm1", "origin": [9, 3.5, -3], "size": [4, 30, 6], "uv": [60, 58]}
				]
			},
			{
				"name": "leg0",
				"parent": "body",
				"pivot": [-4, 13, 0],
				"cubes": [
					{"name": "leg0", "origin": [-7.5, 0, -3], "size": [6, 16, 5], "uv": [37, 0]}
				]
			},
			{
				"name": "leg1",
				"parent": "body",
				"pivot": [5, 13, 0],
				"mirror": true,
				"cubes": [
					{"name": "leg1", "origin": [1.5, 0, -3], "size": [6, 16, 5], "uv": [60, 0]}
				]
			}
		]
	}`
};
skin_presets.llama = {
	display_name: 'Llama',
	model: `{
		"name": "llama",
		"external_textures": ["entity/llama/llama.png"],
		"texturewidth": 128,
		"textureheight": 64,
		"eyes": [
			[7, 21],
			[11, 21]
		],
		"bones": [
			{
				"name": "Head",
				"pivot": [0, 17, -6],
				"cubes": [
					{"name": "head", "origin": [-2, 27, -16], "size": [4, 4, 9], "uv": [0, 0]},
					{"name": "head", "origin": [-4, 15, -12], "size": [8, 18, 6], "uv": [0, 14]},
					{"name": "head", "origin": [-4, 33, -10], "size": [3, 3, 2], "uv": [17, 0]},
					{"name": "head", "origin": [1, 33, -10], "size": [3, 3, 2], "uv": [17, 0]}
				]
			},
			{
				"name": "chest1",
				"pivot": [-8.5, 21, 3],
				"rotation": [0, 90, 0],
				"cubes": [
					{"name": "chest1", "origin": [-11.5, 13, 3], "size": [8, 8, 3], "uv": [45, 28]}
				]
			},
			{
				"name": "chest2",
				"pivot": [5.5, 21, 3],
				"rotation": [0, 90, 0],
				"cubes": [
					{"name": "chest2", "origin": [2.5, 13, 3], "size": [8, 8, 3], "uv": [45, 41]}
				]
			},
			{
				"name": "body",
				"pivot": [0, 19, 2],
				"rotation": [90, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-6, 11, -5], "size": [12, 18, 10], "uv": [29, 0]}
				]
			},
			{
				"name": "leg0",
				"pivot": [-3.5, 14, 6],
				"cubes": [
					{"name": "leg0", "origin": [-5.5, 0, 4], "size": [4, 14, 4], "uv": [29, 29]}
				]
			},
			{
				"name": "leg1",
				"pivot": [3.5, 14, 6],
				"cubes": [
					{"name": "leg1", "origin": [1.5, 0, 4], "size": [4, 14, 4], "uv": [29, 29]}
				]
			},
			{
				"name": "leg2",
				"pivot": [-3.5, 14, -5],
				"cubes": [
					{"name": "leg2", "origin": [-5.5, 0, -7], "size": [4, 14, 4], "uv": [29, 29]}
				]
			},
			{
				"name": "leg3",
				"pivot": [3.5, 14, -5],
				"cubes": [
					{"name": "leg3", "origin": [1.5, 0, -7], "size": [4, 14, 4], "uv": [29, 29]}
				]
			}
		]
	}`
};
skin_presets.llama_baby = {
	display_name: 'Llama Baby',
	model: `{
		"name": "llama_baby",
		"texturewidth": 64,
		"textureheight": 64,
		"external_textures": ["entity/llama/llama_creamy_baby.png"],
		"eyes": [
			[5, 5, 1, 1],
			[8, 5, 1, 1]
		],
		"bones": [
			{
				"name": "root",
				"pivot": [0, 0, 0]
			},
			{
				"name": "head",
				"parent": "root",
				"pivot": [0, 13, -4],
				"cubes": [
					{"origin": [-3, 11, -8], "size": [6, 11, 4], "uv": [0, 0]},
					{"origin": [-1.5, 17, -11], "size": [3, 3, 3], "uv": [0, 15]},
					{"origin": [0.5, 22, -7], "size": [2, 2, 2], "uv": [20, 4]},
					{"origin": [-2.5, 22, -7], "size": [2, 2, 2], "uv": [20, 0]}
				]
			},
			{
				"name": "leg0",
				"parent": "root",
				"pivot": [-2.5, 8.5, 4.5],
				"cubes": [
					{"origin": [-3.9, 0, 3], "size": [3, 8, 3], "uv": [0, 45]}
				]
			},
			{
				"name": "leg1",
				"parent": "root",
				"pivot": [2.5, 8.5, 4.5],
				"cubes": [
					{"origin": [0.9, 0, 3], "size": [3, 8, 3], "uv": [12, 45]}
				]
			},
			{
				"name": "leg2",
				"parent": "root",
				"pivot": [-2.5, 8.5, -3.5],
				"cubes": [
					{"origin": [-3.9, 0, -5], "size": [3, 8, 3], "uv": [0, 34]}
				]
			},
			{
				"name": "leg3",
				"parent": "root",
				"pivot": [2.5, 8.5, -3.5],
				"cubes": [
					{"origin": [0.9, 0, -5], "size": [3, 8, 3], "uv": [12, 34]}
				]
			},
			{
				"name": "body",
				"parent": "root",
				"pivot": [0, 11, 2.5],
				"cubes": [
					{"origin": [-4, 8, -6], "size": [8, 6, 13], "uv": [0, 15]}
				]
			}
		]
	}`
};
skin_presets.lavaslime = {
	display_name: 'Magma Cube',
	variants: {
		new: {
			name: 'New',
			model: `{
				"name": "magma_cube_v2",
				"texturewidth": 64,
				"textureheight": 64,
				"eyes": [
					[9, 26, 2, 1],
					[13, 26, 2, 1],
					[9, 35, 2, 1],
					[13, 35, 2, 1]
				],
				"bones": [
					{
						"name": "inside",
						"pivot": [0, 0, 0],
						"cubes": [
							{"origin": [-2, 2, -2], "size": [4, 4, 4], "uv": [24, 40]}
						]
					},
					{
						"name": "outside",
						"pivot": [0, 24, 0],
						"cubes": [
							{"origin": [-4, 7, -4], "size": [8, 1, 8], "uv": [0, 0]},
							{"origin": [-4, 6, -4], "size": [8, 1, 8], "uv": [0, 9]},
							{"origin": [-4, 5, -4], "size": [8, 1, 8], "uv": [0, 18]},
							{"origin": [-4, 4, -4], "size": [8, 1, 8], "uv": [0, 27]},
							{"origin": [-4, 3, -4], "size": [8, 1, 8], "uv": [32, 0]},
							{"origin": [-4, 2, -4], "size": [8, 1, 8], "uv": [32, 9]},
							{"origin": [-4, 1, -4], "size": [8, 1, 8], "uv": [32, 18]},
							{"origin": [-4, 0, -4], "size": [8, 1, 8], "uv": [32, 27]}
						]
					}
				]
			}`
		},
		old: {
			name: 'Classic',
			model: `{
				"name": "lavaslime",
				"texturewidth": 64,
				"textureheight": 32,
				"eyes": [
					[33, 18, 2, 1],
					[37, 18, 2, 1],
					[33, 27, 2, 1],
					[37, 27, 2, 1]
				],
				"bones": [
					{
						"name": "insideCube",
						"pivot": [0, 0, 0],
						"cubes": [
							{"name": "insideCube", "origin": [-2, 2, -2], "size": [4, 4, 4], "uv": [0, 16]}
						]
					},
					{
						"name": "bodyCube_0",
						"parent": "insideCube",
						"pivot": [0, 24, 0],
						"cubes": [
							{"name": "bodyCube_0", "origin": [-4, 7, -4], "size": [8, 1, 8], "uv": [0, 0]}
						]
					},
					{
						"name": "bodyCube_1",
						"parent": "insideCube",
						"pivot": [0, 24, 0],
						"cubes": [
							{"name": "bodyCube_1", "origin": [-4, 6, -4], "size": [8, 1, 8], "uv": [0, 1]}
						]
					},
					{
						"name": "bodyCube_2",
						"parent": "insideCube",
						"pivot": [0, 24, 0],
						"cubes": [
							{"name": "bodyCube_2", "origin": [-4, 5, -4], "size": [8, 1, 8], "uv": [24, 10]}
						]
					},
					{
						"name": "bodyCube_3",
						"parent": "insideCube",
						"pivot": [0, 24, 0],
						"cubes": [
							{"name": "bodyCube_3", "origin": [-4, 4, -4], "size": [8, 1, 8], "uv": [24, 19]}
						]
					},
					{
						"name": "bodyCube_4",
						"parent": "insideCube",
						"pivot": [0, 24, 0],
						"cubes": [
							{"name": "bodyCube_4", "origin": [-4, 3, -4], "size": [8, 1, 8], "uv": [0, 4]}
						]
					},
					{
						"name": "bodyCube_5",
						"parent": "insideCube",
						"pivot": [0, 24, 0],
						"cubes": [
							{"name": "bodyCube_5", "origin": [-4, 2, -4], "size": [8, 1, 8], "uv": [0, 5]}
						]
					},
					{
						"name": "bodyCube_6",
						"parent": "insideCube",
						"pivot": [0, 24, 0],
						"cubes": [
							{"name": "bodyCube_6", "origin": [-4, 1, -4], "size": [8, 1, 8], "uv": [0, 6]}
						]
					},
					{
						"name": "bodyCube_7",
						"parent": "insideCube",
						"pivot": [0, 24, 0],
						"cubes": [
							{"name": "bodyCube_7", "origin": [-4, 0, -4], "size": [8, 1, 8], "uv": [0, 7]}
						]
					}
				]
			}`
		}
	}
};
skin_presets.minecart = {
	display_name: 'Minecart',
	model: `{
		"name": "minecart",
		"external_textures": ["entity/minecart.png"],
		"texturewidth": 64,
		"textureheight": 32,
		"bones": [
			{
				"name": "bottom",
				"pivot": [0, 20, 0],
				"rotation": [90, 0, 0],
				"mirror": true,
				"cubes": [
					{"name": "bottom", "origin": [-10, 12, -20], "size": [20, 16, 2], "uv": [0, 10]}
				]
			},
			{
				"name": "front",
				"pivot": [-9, 25, 0],
				"rotation": [0, -90, 0],
				"mirror": true,
				"cubes": [
					{"name": "front", "origin": [-17, 2, -1], "size": [16, 8, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "back",
				"pivot": [9, 25, 0],
				"rotation": [0, 90, 0],
				"mirror": true,
				"cubes": [
					{"name": "back", "origin": [1, 2, -1], "size": [16, 8, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "right",
				"pivot": [0, 25, -7],
				"rotation": [0, -180, 0],
				"mirror": true,
				"cubes": [
					{"name": "right", "origin": [-8, 2, -8], "size": [16, 8, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "left",
				"pivot": [0, 25, 7],
				"mirror": true,
				"cubes": [
					{"name": "left", "origin": [-8, 2, 6], "size": [16, 8, 2], "uv": [0, 0]}
				]
			}
		]
	}`
};
skin_presets.nautilus = {
	display_name: 'Nautilus',
	model: `{
		"name": "nautilus",
		"external_textures": ["entity/nautilus/nautilus.png"],
		"texturewidth": 128,
		"textureheight": 128,
		"eyes": [
			[7, 70, 2, 1],
			[29, 70, 2, 1]
		],
		"bones": [
			{
				"name": "nautilus",
				"pivot": [0, -5, -6]
			},
			{
				"name": "head",
				"parent": "nautilus",
				"pivot": [0, 8, -1],
				"cubes": [
					{"origin": [-7, 8, -8], "size": [14, 10, 16], "uv": [0, 0]},
					{"name": "head_bottom", "origin": [-7, 0, -8], "size": [14, 8, 20], "uv": [0, 26]},
					{"name": "head_back", "origin": [-7, 0, 5], "size": [14, 8, 0], "uv": [48, 26]}
				]
			},
			{
				"name": "body",
				"parent": "nautilus",
				"pivot": [0, 3.5, 6.3],
				"cubes": [
					{"origin": [-5, 0.01, 3.3], "size": [10, 8, 14], "uv": [0, 54]},
					{"name": "body_back", "origin": [-5, 0.01, 13.3], "size": [10, 8, 0], "uv": [0, 76]},
					{"name": "mouth_top", "origin": [-5, 4.01, 13.3], "size": [10, 4, 4], "inflate": -0.002, "uv": [54, 54]},
					{"name": "inner_mouth", "origin": [-3, 2.01, 13.3], "size": [6, 4, 4], "uv": [54, 70]},
					{"name": "mouth_bottom", "origin": [-5, -0.01, 13.3], "size": [10, 4, 4], "inflate": -0.002, "uv": [54, 62]}
				]
			}
		]
	}`
};
skin_presets.nautilus_baby = {
	display_name: 'Nautilus Baby',
	model: `{
		"name": "nautilus_baby",
		"external_textures": ["entity/nautilus/nautilus_baby.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"eyes": [
			[3, 32, 1, 1],
			[15, 32, 1, 1]
		],
		"bones": [
			{
				"name": "nautilus_baby",
				"pivot": [0, -4, 0]
			},
			{
				"name": "head",
				"parent": "nautilus_baby",
				"pivot": [-2.5, 4, -2.5],
				"cubes": [
					{"origin": [-3.5, 4, -3.5], "size": [7, 4, 7], "uv": [0, 0]},
					{"name": "head_bottom", "origin": [-3.5, 0, -3.5], "size": [7, 4, 9], "uv": [0, 11]},
					{"name": "head_back", "origin": [-3.5, 0, 2.5], "size": [7, 4, 0], "uv": [23, 11]}
				]
			},
			{
				"name": "body",
				"parent": "nautilus_baby",
				"pivot": [0, 1, 2.5],
				"cubes": [
					{"origin": [-2.5, 0.01, 1.5], "size": [5, 4, 7], "uv": [0, 24]},
					{"name": "body_back", "origin": [-2.5, 0.01, 6.6], "size": [5, 4, 0], "uv": [0, 35]},
					{"name": "mouth_top", "origin": [-2.5, 2.01, 6.4], "size": [5, 2, 2], "inflate": -0.002, "uv": [24, 24]},
					{"name": "inner_mouth", "origin": [-1.5, 1.01, 6.4], "size": [3, 2, 2], "uv": [24, 32]},
					{"name": "mouth_bottom", "origin": [-2.5, 0.01, 6.4], "size": [5, 2, 2], "inflate": -0.002, "uv": [24, 28]}
				]
			}
		]
	}`
};
skin_presets.panda = {
	display_name: 'Panda',
	model: `{
		"name": "panda",
		"external_textures": ["entity/panda/panda.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"eyes": [
			[11, 19, 2, 1],
			[18, 19, 2, 1]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [0, 14, 0],
				"rotation": [90, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-9.5, 1, -6.5], "size": [19, 26, 13], "uv": [0, 25]}
				]
			},
			{
				"name": "head",
				"pivot": [0, 12.5, -17],
				"cubes": [
					{"name": "head", "origin": [-6.5, 7.5, -21], "size": [13, 10, 9], "uv": [0, 6]},
					{"name": "head", "origin": [-3.5, 7.5, -23], "size": [7, 5, 2], "uv": [45, 16]},
					{"name": "head", "origin": [-8.5, 16.5, -18], "size": [5, 4, 1], "uv": [52, 25]},
					{"name": "head", "origin": [3.5, 16.5, -18], "size": [5, 4, 1], "uv": [52, 25]}
				]
			},
			{
				"name": "leg0",
				"pivot": [-5.5, 9, 9],
				"cubes": [
					{"name": "leg0", "origin": [-8.5, 0, 6], "size": [6, 9, 6], "uv": [40, 0]}
				]
			},
			{
				"name": "leg1",
				"pivot": [5.5, 9, 9],
				"cubes": [
					{"name": "leg1", "origin": [2.5, 0, 6], "size": [6, 9, 6], "uv": [40, 0]}
				]
			},
			{
				"name": "leg2",
				"pivot": [-5.5, 9, -9],
				"cubes": [
					{"name": "leg2", "origin": [-8.5, 0, -12], "size": [6, 9, 6], "uv": [40, 0]}
				]
			},
			{
				"name": "leg3",
				"pivot": [5.5, 9, -9],
				"cubes": [
					{"name": "leg3", "origin": [2.5, 0, -12], "size": [6, 9, 6], "uv": [40, 0]}
				]
			}
		]
	}`
};
skin_presets.panda_baby = {
	display_name: 'Panda Baby',
	model: `{
		"name": "panda_baby",
		"texturewidth": 64,
		"textureheight": 64,
		"external_textures": ["entity/panda/panda_baby.png"],
		"eyes": [
			[6, 8, 1, 1],
			[10, 8, 1, 1]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [0, 5.5, 2.5],
				"cubes": [
					{"origin": [-4.5, 2, -3], "size": [9, 7, 11], "uv": [0, 11]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 5, -3],
				"cubes": [
					{"origin": [-3.5, 2, -8], "size": [7, 6, 5], "uv": [0, 0]},
					{"origin": [-2, 2, -9], "size": [4, 2, 1], "uv": [24, 6]},
					{"origin": [-4.5, 6, -6.5], "size": [3, 3, 1], "uv": [24, 0]},
					{"origin": [1.5, 6, -6.5], "size": [3, 3, 1], "uv": [33, 0]}
				]
			},
			{
				"name": "leg0",
				"parent": "body",
				"pivot": [-3, 2, 6.5],
				"cubes": [
					{"origin": [-4.4975, 0, 4.975], "size": [3, 2, 3], "uv": [0, 34]}
				]
			},
			{
				"name": "leg1",
				"parent": "body",
				"pivot": [3, 2, 6.5],
				"cubes": [
					{"origin": [1.4975, 0, 4.975], "size": [3, 2, 3], "uv": [12, 34]}
				]
			},
			{
				"name": "leg2",
				"parent": "body",
				"pivot": [-3, 2, -1.5],
				"cubes": [
					{"origin": [-4.475, 0, -2.975], "size": [3, 2, 3], "uv": [0, 29]}
				]
			},
			{
				"name": "leg3",
				"parent": "body",
				"pivot": [3, 2, -1.5],
				"cubes": [
					{"origin": [1.475, 0, -2.975], "size": [3, 2, 3], "uv": [12, 29]}
				]
			}
		]
	}`
};
skin_presets.parrot = {
	display_name: 'Parrot',
	model_bedrock: `{
		"name": "parrot",
		"external_textures": ["entity/parrot/parrot_red_blue.png"],
		"texturewidth": 32,
		"textureheight": 32,
		"bones": [
			{
				"name": "body",
				"pivot": [0, 7.5, -3],
				"rotation": [25, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-1.5, 1.5, -4.5], "size": [3, 6, 3], "uv": [2, 8]}
				]
			},
			{
				"name": "wing0",
				"parent": "body",
				"pivot": [1.5, 7.1, -2.8],
				"rotation": [10, 0, 0],
				"cubes": [
					{"name": "wing0", "origin": [1, 2.1, -4.3], "size": [1, 5, 3], "uv": [19, 8]}
				]
			},
			{
				"name": "wing1",
				"parent": "body",
				"pivot": [-1.5, 7.1, -2.8],
				"rotation": [10, 0, 0],
				"cubes": [
					{"name": "wing1", "origin": [-2, 2.1, -4.3], "size": [1, 5, 3], "uv": [19, 8]}
				]
			},
			{
				"name": "head",
				"pivot": [0, 8.3, -2.8],
				"cubes": [
					{"name": "head", "origin": [-1, 6.8, -3.8], "size": [2, 3, 2], "uv": [2, 2]},
					{"name": "head2", "origin": [-1, 9.8, -5.8], "size": [2, 1, 4], "uv": [10, 0]},
					{"name": "beak1", "origin": [-0.5, 7.8, -4.7], "size": [1, 2, 1], "uv": [11, 7]},
					{"name": "beak2", "origin": [-0.5, 8.1, -5.7], "size": [1, 1.7, 1], "uv": [16, 7]},
					{"name": "feather", "origin": [0, 9.1, -4.9], "size": [0, 5, 4], "uv": [2, 18]}
				]
			},
			{
				"name": "tail",
				"pivot": [0, 2.9, 1.2],
				"rotation": [50, 0, 0],
				"cubes": [
					{"name": "tail", "origin": [-1.5, -0.1, 0.2], "size": [3, 4, 1], "uv": [22, 1]}
				]
			},
			{
				"name": "leg0",
				"pivot": [1.5, 1, -0.5],
				"cubes": [
					{"name": "leg0", "origin": [0.5, -0.5, -1.5], "size": [1, 2, 1], "uv": [14, 18]}
				]
			},
			{
				"name": "leg1",
				"pivot": [-0.5, 1, -0.5],
				"cubes": [
					{"name": "leg1", "origin": [-1.5, -0.5, -1.5], "size": [1, 2, 1], "uv": [14, 18]}
				]
			}
		]
	}`,
	model_java: `{
		"name": "parrot",
		"external_textures": ["entity/parrot/parrot_red_blue.png"],
		"texturewidth": 32,
		"textureheight": 32,
		"bones": [
			{
				"name": "body",
				"pivot": [0, 7.5, -3],
				"rotation": [25, 0, 0],
				"cubes": [
					{"origin": [-1.5, 1.5, -4.5], "size": [3, 6, 3], "uv": [2, 8]}
				]
			},
			{
				"name": "wing0",
				"parent": "body",
				"pivot": [1.5, 7.1, -2.8],
				"rotation": [10, 0, 0],
				"cubes": [
					{"origin": [1, 2.1, -4.3], "size": [1, 5, 3], "uv": [19, 8]}
				]
			},
			{
				"name": "wing1",
				"parent": "body",
				"pivot": [-1.5, 7.1, -2.8],
				"rotation": [10, 0, 0],
				"cubes": [
					{"origin": [-2, 2.1, -4.3], "size": [1, 5, 3], "uv": [19, 8]}
				]
			},
			{
				"name": "head",
				"pivot": [0, 8.3, -2.8],
				"cubes": [
					{"origin": [-1, 6.8, -3.8], "size": [2, 3, 2], "uv": [2, 2]},
					{"origin": [-1, 9.8, -5.8], "size": [2, 1, 4], "uv": [10, 0]},
					{"origin": [-0.5, 7.8, -4.7], "size": [1, 2, 1], "uv": [11, 7]},
					{"origin": [-0.5, 8.035, -5.64], "size": [1, 2.025, 1], "uv": [16, 7]},
					{"origin": [0, 9.1, -4.9], "size": [0, 5, 4], "uv": [2, 18]}
				]
			},
			{
				"name": "tail",
				"pivot": [0, 2.9, 1.2],
				"rotation": [50, 0, 0],
				"cubes": [
					{"origin": [-1.5, -0.1, 0.2], "size": [3, 4, 1], "uv": [22, 1]}
				]
			},
			{
				"name": "leg0",
				"pivot": [1.5, 1, -0.5],
				"cubes": [
					{"origin": [0.5, -0.5, -1.5], "size": [1, 2, 1], "uv": [14, 18]}
				]
			},
			{
				"name": "leg1",
				"pivot": [-0.5, 1, -0.5],
				"cubes": [
					{"origin": [-1.5, -0.5, -1.5], "size": [1, 2, 1], "uv": [14, 18]}
				]
			}
		]
	}`
};
skin_presets.phantom = {
	display_name: 'Phantom',
	model: `{
		"name": "phantom",
		"external_textures": ["entity/phantom.tga"],
		"eyes": [
			[5, 6, 2, 1],
			[10, 6, 2, 1]
		],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "body",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "body", "origin": [-3, 23, -8], "size": [5, 3, 9], "uv": [0, 8]}
				]
			},
			{
				"name": "wing0",
				"parent": "body",
				"pivot": [2, 26, -8],
				"rotation": [0, 0, 5],
				"cubes": [
					{"name": "wing0", "origin": [2, 24, -8], "size": [6, 2, 9], "uv": [23, 12]}
				]
			},
			{
				"name": "wingtip0",
				"parent": "wing0",
				"pivot": [8, 26, -8],
				"rotation": [0, 0, 10],
				"cubes": [
					{"name": "wingtip0", "origin": [8, 25, -8], "size": [13, 1, 9], "uv": [16, 24]}
				]
			},
			{
				"name": "wing1",
				"parent": "body",
				"pivot": [-3, 26, -8],
				"rotation": [0, 0, -5],
				"mirror": true,
				"cubes": [
					{"name": "wing1", "origin": [-9, 24, -8], "size": [6, 2, 9], "uv": [23, 12]}
				]
			},
			{
				"name": "wingtip1",
				"parent": "wing1",
				"pivot": [-9, 26, -8],
				"rotation": [0, 0, -10],
				"mirror": true,
				"cubes": [
					{"name": "wingtip1", "origin": [-22, 25, -8], "size": [13, 1, 9], "uv": [16, 24]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 23, -7],
				"cubes": [
					{"name": "head", "origin": [-4, 22, -12], "size": [7, 3, 5], "uv": [0, 0]}
				]
			},
			{
				"name": "tail",
				"parent": "body",
				"pivot": [0, 26, 1],
				"rotation": [-5, 0, 0],
				"cubes": [
					{"name": "tail", "origin": [-2, 24, 1], "size": [3, 2, 6], "uv": [3, 20]}
				]
			},
			{
				"name": "tailtip",
				"parent": "tail",
				"pivot": [0, 25.5, 7],
				"rotation": [-5, 0, 0],
				"cubes": [
					{"name": "tailtip", "origin": [-1, 24.5, 7], "size": [1, 1, 6], "uv": [4, 29]}
				]
			}
		]
	}`
};
skin_presets.pig = {
	display_name: 'Pig',
	variants: {
		new: {
			name: 'New',
			model: `{
				"name": "pig",
				"external_textures": ["entity/pig/pig_v3.png"],
				"texturewidth": 64,
				"textureheight": 64,
				"eyes": [
					[8, 11, 2, 1],
					[14, 11, 2, 1]
				],
				"bones": [
					{
						"name": "root",
						"pivot": [0, 0, 0]
					},
					{
						"name": "head",
						"parent": "root",
						"pivot": [0, 12, -7],
						"cubes": [
							{"origin": [-4, 8, -15], "size": [8, 8, 8], "uv": [0, 0]},
							{"origin": [-2, 9, -16], "size": [4, 3, 1], "uv": [16, 16]}
						]
					},
					{
						"name": "body",
						"parent": "root",
						"pivot": [0, 11, 9],
						"cubes": [
							{"origin": [-5, 13, 4], "size": [10, 16, 8], "pivot": [0, 11, 9], "rotation": [90, 0, 0], "uv": [28, 8]},
							{"origin": [-5, 13, 4], "size": [10, 16, 8], "inflate": 0.5, "pivot": [0, 11, 9], "rotation": [90, 0, 0], "uv": [28, 32], "layer": true}
						]
					},
					{
						"name": "leg0",
						"parent": "root",
						"pivot": [-3, 6, 6],
						"cubes": [
							{"origin": [-5, 0, 4], "size": [4, 6, 4], "uv": [0, 16]}
						]
					},
					{
						"name": "leg1",
						"parent": "root",
						"pivot": [3, 6, 6],
						"mirror": true,
						"cubes": [
							{"origin": [1, 0, 4], "size": [4, 6, 4], "uv": [0, 16], "mirror": true}
						]
					},
					{
						"name": "leg3",
						"parent": "root",
						"pivot": [3, 6, -6],
						"mirror": true,
						"cubes": [
							{"origin": [1, 0, -8], "size": [4, 6, 4], "uv": [0, 16], "mirror": true}
						]
					},
					{
						"name": "leg2",
						"parent": "root",
						"pivot": [-3, 6, -6],
						"cubes": [
							{"origin": [-5, 0, -8], "size": [4, 6, 4], "uv": [0, 16]}
						]
					}
				]
			}`
		},
		old: {
			name: 'Classic',
			model: `{
				"name": "pig",
				"external_textures": ["entity/pig/pig.png"],
				"texturewidth": 64,
				"textureheight": 32,
				"eyes": [
					[8, 11, 2, 1],
					[14, 11, 2, 1]
				],
				"bones": [
					{
						"name": "body",
						"pivot": [0, 13, 2],
						"rotation": [90, 0, 0],
						"cubes": [
							{"name": "body", "origin": [-5, 7, -5], "size": [10, 16, 8], "uv": [28, 8]}
						]
					},
					{
						"name": "head",
						"pivot": [0, 12, -6],
						"cubes": [
							{"name": "head", "origin": [-4, 8, -14], "size": [8, 8, 8], "uv": [0, 0]},
							{"name": "head", "origin": [-2, 9, -15], "size": [4, 3, 1], "uv": [16, 16]}
						]
					},
					{
						"name": "leg0",
						"pivot": [-3, 6, 7],
						"cubes": [
							{"name": "leg0", "origin": [-5, 0, 5], "size": [4, 6, 4], "uv": [0, 16]}
						]
					},
					{
						"name": "leg1",
						"pivot": [3, 6, 7],
						"mirror": true,
						"cubes": [
							{"name": "leg1", "origin": [1, 0, 5], "size": [4, 6, 4], "uv": [0, 16]}
						]
					},
					{
						"name": "leg2",
						"pivot": [-3, 6, -5],
						"cubes": [
							{"name": "leg2", "origin": [-5, 0, -7], "size": [4, 6, 4], "uv": [0, 16]}
						]
					},
					{
						"name": "leg3",
						"pivot": [3, 6, -5],
						"mirror": true,
						"cubes": [
							{"name": "leg3", "origin": [1, 0, -7], "size": [4, 6, 4], "uv": [0, 16]}
						]
					}
				]
			}`
		}
	}
};
skin_presets.pig_baby = {
	display_name: 'Pig Baby',
	model: `{
		"name": "pig_baby",
		"external_textures": ["entity/pig/pig_temperate_baby.png"],
		"texturewidth": 32,
		"textureheight": 32,
		"eyes": [
			[7, 23, 1, 1],
			[11, 23, 1, 1]
		],
		"bones": [
			{
				"name": "root",
				"pivot": [0, 0, 0]
			},
			{
				"name": "body",
				"parent": "root",
				"pivot": [0, 5, 0.5],
				"cubes": [
					{"origin": [-3.5, 2, -4], "size": [7, 6, 9], "uv": [0, 0]}
				]
			},
			{
				"name": "head",
				"parent": "root",
				"pivot": [0, 5, -2],
				"cubes": [
					{"origin": [-3.51, 4, -7], "size": [7.02, 6, 6], "uv": [0, 15]},
					{"origin": [-1.5, 5, -8], "size": [3, 2, 1], "uv": [6, 27]}
				]
			},
			{
				"name": "leg0",
				"parent": "root",
				"pivot": [-2.5, 2, 4],
				"cubes": [
					{"origin": [-3.475, 0, 3], "size": [2, 2, 2], "uv": [23, 4]}
				]
			},
			{
				"name": "leg1",
				"parent": "root",
				"pivot": [2.5, 2, 4],
				"cubes": [
					{"origin": [1.475, 0, 3], "size": [2, 2, 2], "uv": [0, 4]}
				]
			},
			{
				"name": "leg3",
				"parent": "root",
				"pivot": [2.5, 2, -3],
				"cubes": [
					{"origin": [1.475, 0, -4], "size": [2, 2, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "leg2",
				"parent": "root",
				"pivot": [-2.5, 2, -3],
				"cubes": [
					{"origin": [-3.475, 0, -4], "size": [2, 2, 2], "uv": [23, 0]}
				]
			}
		]
	}`
};
skin_presets.piglin = {
	display_name: 'Piglin',
	model: `{
		"name": "piglin",
		"external_textures": ["entity/piglin/piglin.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"eyes": [
			[10, 11, 1, 1],
			[15, 11, 1, 1]
		],
		"bones": [
			{
				"name": "Body",
				"pivot": [0, 24, 0],
				"cubes": [
					{"origin": [-4, 12, -2], "size": [8, 12, 4], "uv": [16, 16]},
					{"origin": [-4, 12, -2], "size": [8, 12, 4], "inflate": 0.25, "uv": [16, 32]}
				]
			},
			{
				"name": "head",
				"pivot": [0, 24, 0],
				"cubes": [
					{"origin": [-5, 24, -4], "size": [10, 8, 8], "inflate": -0.02, "uv": [0, 0]},
					{"origin": [-2, 24, -5], "size": [4, 4, 1], "uv": [31, 1]},
					{"origin": [2, 24, -5], "size": [1, 2, 1], "uv": [2, 4]},
					{"origin": [-3, 24, -5], "size": [1, 2, 1], "uv": [2, 0]}
				]
			},
			{
				"name": "leftear",
				"parent": "head",
				"pivot": [5, 30, 0],
				"rotation": [0, 0, -30],
				"cubes": [
					{"origin": [4, 25, -2], "size": [1, 5, 4], "uv": [51, 6]}
				]
			},
			{
				"name": "rightear",
				"parent": "head",
				"pivot": [-5, 30, 0],
				"rotation": [0, 0, 30],
				"cubes": [
					{"origin": [-5, 25, -2], "size": [1, 5, 4], "uv": [39, 6]}
				]
			},
			{
				"name": "RightArm",
				"pivot": [-5, 22, 0],
				"cubes": [
					{"origin": [-8, 12, -2], "size": [4, 12, 4], "uv": [40, 16]},
					{"origin": [-8, 12, -2], "size": [4, 12, 4], "inflate": 0.25, "uv": [40, 32]}
				]
			},
			{
				"name": "LeftArm",
				"pivot": [5, 22, 0],
				"cubes": [
					{"origin": [4, 12, -2], "size": [4, 12, 4], "uv": [32, 48]},
					{"origin": [4, 12, -2], "size": [4, 12, 4], "inflate": 0.25, "uv": [48, 48]}
				]
			},
			{
				"name": "RightLeg",
				"pivot": [-1.9, 12, 0],
				"cubes": [
					{"origin": [-4, 0, -2], "size": [4, 12, 4], "uv": [0, 16]},
					{"origin": [-4, 0, -2], "size": [4, 12, 4], "inflate": 0.25, "uv": [0, 32]}
				]
			},
			{
				"name": "LeftLeg",
				"pivot": [1.9, 12, 0],
				"cubes": [
					{"origin": [0, 0, -2], "size": [4, 12, 4], "uv": [16, 48]},
					{"origin": [0, 0, -2], "size": [4, 12, 4], "inflate": 0.25, "uv": [0, 48]}
				]
			},
			{
				"name": "leftItem",
				"pivot": [6, 15, 1]
			}
		]
	}`
};
skin_presets.piglin_baby = {
	display_name: 'Piglin Baby',
	model: `{
		"name": "piglin_baby",
		"texturewidth": 64,
		"textureheight": 64,
		"external_textures": ["entity/piglin/piglin_baby.png"],
		"eyes": [
			[9, 9, 1, 1],
			[13, 9, 1, 1]
		],
		"bones": [
			{
				"name": "Body",
				"pivot": [0, 6, 0],
				"cubes": [
					{"origin": [-3, 4, -1], "size": [6, 5, 3], "uv": [0, 13]}
				]
			},
			{
				"name": "head",
				"parent": "Body",
				"pivot": [0, 9, 0.5],
				"cubes": [
					{"origin": [-1.5, 9, -4], "size": [3, 3, 1], "uv": [21, 30]},
					{"origin": [-4.5, 9, -3], "size": [9, 6, 7], "uv": [0, 0]}
				]
			},
			{
				"name": "leftear",
				"parent": "head",
				"pivot": [4.2, 13, 1],
				"cubes": [
					{"origin": [4.7, 8.25, -1], "size": [1, 6, 4], "pivot": [5.2, 11.25, 1], "rotation": [0, 0, -35], "uv": [0, 21]}
				]
			},
			{
				"name": "rightear",
				"parent": "head",
				"pivot": [-4.2, 13, 1],
				"cubes": [
					{"origin": [-5.7, 8.25, -1], "size": [1, 6, 4], "pivot": [-5.2, 11.25, 1], "rotation": [0, 0, 35], "uv": [18, 13]}
				]
			},
			{
				"name": "LeftArm",
				"parent": "Body",
				"pivot": [4, 9, 0.5],
				"cubes": [
					{"origin": [3, 4, -1], "size": [2, 5, 3], "uv": [28, 13]}
				]
			},
			{
				"name": "leftItem",
				"parent": "LeftArm",
				"pivot": [4, 6, 0.5]
			},
			{
				"name": "RightArm",
				"parent": "Body",
				"pivot": [-4, 9, 0.5],
				"cubes": [
					{"origin": [-5, 4, -1], "size": [2, 5, 3], "uv": [10, 30]}
				]
			},
			{
				"name": "rightItem",
				"parent": "RightArm",
				"pivot": [-4, 6, 0.5]
			},
			{
				"name": "RightLeg",
				"parent": "Body",
				"pivot": [-1.5, 4, 0.5],
				"cubes": [
					{"origin": [-3, 0, -1], "size": [3, 4, 3], "uv": [22, 23]}
				]
			},
			{
				"name": "LeftLeg",
				"parent": "Body",
				"pivot": [1.5, 4, 0.5],
				"cubes": [
					{"origin": [0, 0, -1], "size": [3, 4, 3], "uv": [10, 23]}
				]
			}
		]
	}`
};
skin_presets.pillager = {
	display_name: 'Pillager',
	model: `{
		"name": "pillager",
		"external_textures": ["entity/pillager.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "waist",
				"pivot": [0, 12, 0]
			},
			{
				"name": "Body",
				"parent": "waist",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "Body", "origin": [-4, 12, -3], "size": [8, 12, 6], "uv": [16, 20]},
					{"name": "Body", "origin": [-4, 6, -3], "size": [8, 18, 6], "uv": [0, 38], "inflate": 0.5}
				]
			},
			{
				"name": "head",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "head", "origin": [-4, 24, -4], "size": [8, 10, 8], "uv": [0, 0]}
				]
			},
			{
				"name": "nose",
				"parent": "head",
				"pivot": [0, 26, 0],
				"cubes": [
					{"name": "nose", "origin": [-1, 23, -6], "size": [2, 4, 2], "uv": [24, 0]}
				]
			},
			{
				"name": "LeftLeg",
				"pivot": [2, 12, 0],
				"cubes": [
					{"name": "LeftLeg", "origin": [0, 0, -2], "size": [4, 12, 4], "uv": [0, 22]}
				]
			},
			{
				"name": "RightLeg",
				"pivot": [-2, 12, 0],
				"mirror": true,
				"cubes": [
					{"name": "RightLeg", "origin": [-4, 0, -2], "size": [4, 12, 4], "uv": [0, 22]}
				]
			},
			{
				"name": "RightArm",
				"pivot": [-5, 22, 0],
				"cubes": [
					{"name": "RightArm", "origin": [-8, 12, -2], "size": [4, 12, 4], "uv": [40, 46]}
				]
			},
			{
				"name": "LeftArm",
				"pivot": [5, 22, 0],
				"mirror": true,
				"cubes": [
					{"name": "LeftArm", "origin": [4, 12, -2], "size": [4, 12, 4], "uv": [40, 46]}
				]
			}
		]
	}`
};
skin_presets.polar_bear = {
	display_name: 'Polar Bear',
	model: `{
		"name": "polar_bear",
		"external_textures": ["entity/polar_bear.png"],
		"texturewidth": 128,
		"textureheight": 64,
		"bones": [
			{
				"name": "body",
				"pivot": [-2, 15, 12],
				"rotation": [90, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-7, 14, 5], "size": [14, 14, 11], "uv": [0, 19]},
					{"name": "body", "origin": [-6, 28, 5], "size": [12, 12, 10], "uv": [39, 0]}
				]
			},
			{
				"name": "head",
				"pivot": [0, 14, -16],
				"mirror": true,
				"cubes": [
					{"name": "head", "origin": [-3.5, 10, -19], "size": [7, 7, 7], "uv": [0, 0], "mirror": false},
					{"name": "head", "origin": [-2.5, 10, -22], "size": [5, 3, 3], "uv": [0, 44], "mirror": false},
					{"name": "head", "origin": [-4.5, 16, -17], "size": [2, 2, 1], "uv": [26, 0], "mirror": false},
					{"name": "head", "origin": [2.5, 16, -17], "size": [2, 2, 1], "uv": [26, 0]}
				]
			},
			{
				"name": "leg0",
				"pivot": [-4.5, 10, 6],
				"cubes": [
					{"name": "leg0", "origin": [-6.5, 0, 4], "size": [4, 10, 8], "uv": [50, 22]}
				]
			},
			{
				"name": "leg1",
				"pivot": [4.5, 10, 6],
				"cubes": [
					{"name": "leg1", "origin": [2.5, 0, 4], "size": [4, 10, 8], "uv": [50, 22]}
				]
			},
			{
				"name": "leg2",
				"pivot": [-3.5, 10, -8],
				"cubes": [
					{"name": "leg2", "origin": [-5.5, 0, -10], "size": [4, 10, 6], "uv": [50, 40]}
				]
			},
			{
				"name": "leg3",
				"pivot": [3.5, 10, -8],
				"cubes": [
					{"name": "leg3", "origin": [1.5, 0, -10], "size": [4, 10, 6], "uv": [50, 40]}
				]
			}
		]
	}`
};
skin_presets.polar_bear_baby = {
	display_name: 'Polar Bear Baby',
	model: `{
		"name": "polar_bear_baby",
		"texturewidth": 64,
		"textureheight": 64,
		"external_textures": ["entity/polar_bear/polar_bear_baby.png"],
		"eyes": [
			[5, 6, 1, 1],
			[8, 6, 1, 1]
		],
		"bones": [
			{
				"name": "root",
				"pivot": [0, 0, 0]
			},
			{
				"name": "head",
				"parent": "root",
				"pivot": [0, 5.375, -6.75],
				"cubes": [
					{"origin": [-3, 3, -10], "size": [6, 5, 4], "uv": [0, 0]},
					{"origin": [-2, 3, -12], "size": [4, 2, 2], "uv": [20, 3]},
					{"origin": [-4, 7, -8.5], "size": [2, 2, 1], "uv": [20, 0]},
					{"origin": [2, 7, -8.5], "size": [2, 2, 1], "uv": [26, 0]}
				]
			},
			{
				"name": "leg0",
				"parent": "root",
				"pivot": [-2.5, 2.5, 4.5],
				"cubes": [
					{"origin": [-3.975, 0, 3], "size": [3, 3, 3], "uv": [0, 34]}
				]
			},
			{
				"name": "leg1",
				"parent": "root",
				"pivot": [2.5, 2.5, 4.5],
				"cubes": [
					{"origin": [0.975, 0, 3], "size": [3, 3, 3], "uv": [12, 34]}
				]
			},
			{
				"name": "leg2",
				"parent": "root",
				"pivot": [-2.5, 2.5, -4.5],
				"cubes": [
					{"origin": [-3.975, 0, -6], "size": [3, 3, 3], "uv": [0, 28]}
				]
			},
			{
				"name": "leg3",
				"parent": "root",
				"pivot": [2.5, 2.5, -4.5],
				"cubes": [
					{"origin": [0.975, 0, -6], "size": [3, 3, 3], "uv": [12, 28]}
				]
			},
			{
				"name": "body",
				"parent": "root",
				"pivot": [0, 6.5, 4],
				"cubes": [
					{"origin": [-4, 3, -6], "size": [8, 7, 12], "uv": [0, 9]}
				]
			}
		]
	}`
};
skin_presets.pufferfish = {
	display_name: 'Pufferfish',
	model: `{
		"name": "pufferfish",
		"external_textures": ["entity/fish/pufferfish.png"],
		"texturewidth": 32,
		"textureheight": 32,
		"bones": [
			{
				"name": "body_large",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-4, 0, -4], "size": [8, 8, 8], "uv": [0, 0]}
				]
			},
			{
				"name": "leftFin",
				"parent": "body_large",
				"pivot": [4, 7, 3],
				"cubes": [
					{"name": "leftFin", "origin": [4, 6, -2.9904], "size": [2, 1, 2], "uv": [24, 3]}
				]
			},
			{
				"name": "rightFin",
				"parent": "body_large",
				"pivot": [-4, 7, 1],
				"cubes": [
					{"name": "rightFin", "origin": [-5.9968, 6, -2.992], "size": [2, 1, 2], "uv": [24, 0]}
				]
			},
			{
				"name": "spines_top_front",
				"parent": "body_large",
				"pivot": [-4, 8, -4],
				"rotation": [45, 0, 0],
				"cubes": [
					{"name": "spines_top_front", "origin": [-4, 8, -4], "size": [8, 1, 1], "uv": [14, 16]}
				]
			},
			{
				"name": "spines_top_mid",
				"parent": "body_large",
				"pivot": [0, 8, 0],
				"cubes": [
					{"name": "spines_top_mid", "origin": [-4, 8, 0], "size": [8, 1, 1], "uv": [14, 16]}
				]
			},
			{
				"name": "spines_top_back",
				"parent": "body_large",
				"pivot": [0, 8, 4],
				"rotation": [-45, 0, 0],
				"cubes": [
					{"name": "spines_top_back", "origin": [-4, 8, 4], "size": [8, 1, 1], "uv": [14, 16]}
				]
			},
			{
				"name": "spines_bottom_front",
				"parent": "body_large",
				"pivot": [0, 0, -4],
				"rotation": [-45, 0, 0],
				"cubes": [
					{"name": "spines_bottom_front", "origin": [-4, -1, -4], "size": [8, 1, 1], "uv": [14, 19]}
				]
			},
			{
				"name": "spines_bottom_mid",
				"parent": "body_large",
				"pivot": [0, -1, 0],
				"cubes": [
					{"name": "spines_bottom_mid", "origin": [-4, -1, 0], "size": [8, 1, 1], "uv": [14, 19]}
				]
			},
			{
				"name": "spines_bottom_back",
				"parent": "body_large",
				"pivot": [0, 0, 4],
				"rotation": [45, 0, 0],
				"cubes": [
					{"name": "spines_bottom_back", "origin": [-4, -1, 4], "size": [8, 1, 1], "uv": [14, 19]}
				]
			},
			{
				"name": "spines_left_front",
				"parent": "body_large",
				"pivot": [4, 0, -4],
				"rotation": [0, 45, 0],
				"cubes": [
					{"name": "spines_left_front", "origin": [4, 0, -4], "size": [1, 8, 1], "uv": [0, 16]}
				]
			},
			{
				"name": "spines_left_mid",
				"parent": "body_large",
				"pivot": [4, 0, 0],
				"cubes": [
					{"name": "spines_left_mid", "origin": [4, 0, 0], "size": [1, 8, 1], "uv": [4, 16], "mirror": true}
				]
			},
			{
				"name": "spines_left_back",
				"parent": "body_large",
				"pivot": [4, 0, 4],
				"rotation": [0, -45, 0],
				"cubes": [
					{"name": "spines_left_back", "origin": [4, 0, 4], "size": [1, 8, 1], "uv": [8, 16], "mirror": true}
				]
			},
			{
				"name": "spines_right_front",
				"parent": "body_large",
				"pivot": [-4, 0, -4],
				"rotation": [0, -45, 0],
				"cubes": [
					{"name": "spines_right_front", "origin": [-5, 0, -4], "size": [1, 8, 1], "uv": [4, 16]}
				]
			},
			{
				"name": "spines_right_mid",
				"parent": "body_large",
				"pivot": [-4, 0, 0],
				"cubes": [
					{"name": "spines_right_mid", "origin": [-5, 0, 0], "size": [1, 8, 1], "uv": [8, 16]}
				]
			},
			{
				"name": "spines_right_back",
				"parent": "body_large",
				"pivot": [-4, 0, 4],
				"rotation": [0, 45, 0],
				"cubes": [
					{"name": "spines_right_back", "origin": [-5, 0, 4], "size": [1, 8, 1], "uv": [8, 16]}
				]
			},
			{
				"name": "body_mid",
				"pivot": [16, 0, 0],
				"cubes": [
					{"name": "body", "origin": [13.5, 1, -2.5], "size": [5, 5, 5], "uv": [12, 22]}
				]
			},
			{
				"name": "leftFin",
				"parent": "body_mid",
				"pivot": [18.5, 5, 0.5],
				"cubes": [
					{"name": "leftFin", "origin": [18.5, 4, -1.5], "size": [2, 1, 2], "uv": [24, 3]}
				]
			},
			{
				"name": "rightFin",
				"parent": "body_mid",
				"pivot": [13.5, 5, 0.5],
				"cubes": [
					{"name": "rightFin", "origin": [11.5, 4, -1.5], "size": [2, 1, 2], "uv": [24, 0]}
				]
			},
			{
				"name": "spines_top_front",
				"parent": "body_mid",
				"pivot": [16, 6, -2.5],
				"cubes": [
					{"name": "spines_top_front", "origin": [13.5, 6, -2.5], "size": [5, 1, 0], "uv": [19, 17]}
				]
			},
			{
				"name": "spines_top_back",
				"parent": "body_mid",
				"pivot": [16, 6, 2.5],
				"cubes": [
					{"name": "spines_top_back", "origin": [13.5, 6, 2.5], "size": [5, 1, 0], "uv": [11, 17]}
				]
			},
			{
				"name": "spines_bottom_front",
				"parent": "body_mid",
				"pivot": [16, 1, -2.5],
				"cubes": [
					{"name": "spines_bottom_front", "origin": [13.5, 0, -2.5], "size": [5, 1, 0], "uv": [18, 20]}
				]
			},
			{
				"name": "spines_bottom_back",
				"parent": "body_mid",
				"pivot": [16, 1, 2.5],
				"rotation": [45, 0, 0],
				"cubes": [
					{"name": "spines_bottom_back", "origin": [13.5, 0, 2.5], "size": [5, 1, 0], "uv": [18, 20]}
				]
			},
			{
				"name": "spines_left_front",
				"parent": "body_mid",
				"pivot": [18.5, 0, -2.5],
				"rotation": [0, 45, 0],
				"cubes": [
					{"name": "spines_left_front", "origin": [18.5, 1, -2.5], "size": [1, 5, 0], "uv": [1, 17]}
				]
			},
			{
				"name": "spines_left_back",
				"parent": "body_mid",
				"pivot": [18.5, 0, 2.5],
				"rotation": [0, -45, 0],
				"cubes": [
					{"name": "spines_left_back", "origin": [18.5, 1, 2.5], "size": [1, 5, 0], "uv": [1, 17]}
				]
			},
			{
				"name": "spines_right_front",
				"parent": "body_mid",
				"pivot": [13.5, 0, -2.5],
				"rotation": [0, -45, 0],
				"cubes": [
					{"name": "spines_right_front", "origin": [12.5, 1, -2.5], "size": [1, 5, 0], "uv": [5, 17]}
				]
			},
			{
				"name": "spines_right_back",
				"parent": "body_mid",
				"pivot": [13.5, 0, 2.5],
				"rotation": [0, 45, 0],
				"cubes": [
					{"name": "spines_right_back", "origin": [12.5, 1, 2.5], "size": [1, 5, 0], "uv": [9, 17]}
				]
			},
			{
				"name": "body_small",
				"pivot": [-16, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-17.5, 0, -1.5], "size": [3, 2, 3], "uv": [0, 27]},
					{"name": "body", "origin": [-15.5, 2, -1.5], "size": [1, 1, 1], "uv": [24, 6]},
					{"name": "body", "origin": [-17.5, 2, -1.5], "size": [1, 1, 1], "uv": [28, 6]}
				]
			},
			{
				"name": "tailfin",
				"parent": "body_small",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "tailfin", "origin": [-17.5, 1, 1.5], "size": [3, 0, 3], "uv": [-3, 0]}
				]
			},
			{
				"name": "leftFin",
				"parent": "body_small",
				"pivot": [6.5, 5, 0.5],
				"cubes": [
					{"name": "leftFin", "origin": [-14.5, 0, -1.5], "size": [1, 1, 2], "uv": [25, 0], "mirror": true}
				]
			},
			{
				"name": "rightFin",
				"parent": "body_small",
				"pivot": [-6.5, 5, 0.5],
				"cubes": [
					{"name": "rightFin", "origin": [-18.5, 0, -1.5], "size": [1, 1, 2], "uv": [25, 0]}
				]
			}
		]
	}`
};
skin_presets.rabbit = {
	display_name: 'Rabbit',
		variants: {
		new: {
			name: 'New',
			model: `{
				"name": "rabbit_v2",
				"texturewidth": 64,
				"textureheight": 64,
				"external_textures": ["entity/rabbit/rabbit_salt.png"],
				"eyes": [
					[6, 22, 1, 2],
					[8, 22, 1, 2]
				],
				"bones": [
					{
						"name": "body",
						"pivot": [0, 1, 4],
						"rotation": [-22.5, 0, 0],
						"cubes": [
							{"origin": [-4, 1, -5], "size": [8, 6, 10], "uv": [0, 0]}
						]
					},
					{
						"name": "tail",
						"parent": "body",
						"pivot": [0, 5.99162, 4.01254],
						"cubes": [
							{"origin": [-2, 5, 3], "size": [4, 4, 4], "uv": [20, 16]}
						]
					},
					{
						"name": "head",
						"parent": "body",
						"pivot": [0, 6.29289, -4.12132],
						"rotation": [22.5, 0, 0],
						"cubes": [
							{"origin": [-2.5, 4.29289, -8.12132], "size": [5, 5, 5], "uv": [0, 16]}
						]
					},
					{
						"name": "left_ear",
						"parent": "head",
						"pivot": [1.5, 10, -5],
						"cubes": [
							{"origin": [0.5, 9.29289, -5.12132], "size": [2, 5, 1], "uv": [32, 0]}
						]
					},
					{
						"name": "right_ear",
						"parent": "head",
						"pivot": [-1.5, 10, -5],
						"cubes": [
							{"origin": [-2.5, 9.29289, -5.12132], "size": [2, 5, 1], "uv": [26, 0]}
						]
					},
					{
						"name": "frontlegs",
						"parent": "body",
						"pivot": [0, 2.53492, -2.31075]
					},
					{
						"name": "rightFrontLeg",
						"parent": "frontlegs",
						"pivot": [-2, 0.61104, -1.92807],
						"rotation": [22.5, 0, 0],
						"cubes": [
							{"origin": [-2.9, -2.38896, -2.82807], "size": [2, 4, 2], "uv": [36, 18]}
						]
					},
					{
						"name": "leftFrontLeg",
						"parent": "frontlegs",
						"pivot": [2, 0.61104, -1.82807],
						"rotation": [22.5, 0, 0],
						"cubes": [
							{"origin": [1, -2.38896, -2.82807], "size": [2, 4, 2], "uv": [44, 18]}
						]
					},
					{
						"name": "backlegs",
						"pivot": [0, 1, 4]
					},
					{
						"name": "rightBackLeg",
						"parent": "backlegs",
						"pivot": [-3, 0.5, 4],
						"cubes": [
							{"origin": [-4, 0, -1], "size": [2, 1, 6], "pivot": [-3, 1, 4], "rotation": [0, 22.5, 0], "uv": [20, 24]}
						]
					},
					{
						"name": "leftBackLeg",
						"parent": "backlegs",
						"pivot": [3, 0.5, 4],
						"cubes": [
							{"origin": [2, 0, -1], "size": [2, 1, 6], "pivot": [3, 1, 4], "rotation": [0, -22.5, 0], "uv": [36, 24]}
						]
					}
				]
			}`
		},
		old: {
			name: 'Classic',
			model: `{
				"name": "rabbit",
				"texturewidth": 64,
				"textureheight": 32,
				"bones": [
					{
						"name": "rearFootLeft",
						"pivot": [3, 6.5, 3.7],
						"mirror": true,
						"cubes": [
							{"name": "rearFootLeft", "origin": [2, 0, 0], "size": [2, 1, 7], "uv": [8, 24]}
						]
					},
					{
						"name": "rearFootRight",
						"pivot": [-3, 6.5, 3.7],
						"mirror": true,
						"cubes": [
							{"name": "rearFootRight", "origin": [-4, 0, 0], "size": [2, 1, 7], "uv": [26, 24]}
						]
					},
					{
						"name": "haunchLeft",
						"pivot": [3, 6.5, 3.7],
						"rotation": [-20, 0, 0],
						"mirror": true,
						"cubes": [
							{"name": "haunchLeft", "origin": [2, 2.5, 3.7], "size": [2, 4, 5], "uv": [16, 15]}
						]
					},
					{
						"name": "haunchRight",
						"pivot": [-3, 6.5, 3.7],
						"rotation": [-20, 0, 0],
						"mirror": true,
						"cubes": [
							{"name": "haunchRight", "origin": [-4, 2.5, 3.7], "size": [2, 4, 5], "uv": [30, 15]}
						]
					},
					{
						"name": "body",
						"pivot": [0, 5, 8],
						"rotation": [-20, 0, 0],
						"mirror": true,
						"cubes": [
							{"name": "body", "origin": [-3, 2, -2], "size": [6, 5, 10], "uv": [0, 0]}
						]
					},
					{
						"name": "frontLegLeft",
						"pivot": [3, 7, -1],
						"rotation": [-10, 0, 0],
						"mirror": true,
						"cubes": [
							{"name": "frontLegLeft", "origin": [2, 0, -2], "size": [2, 7, 2], "uv": [8, 15]}
						]
					},
					{
						"name": "frontLegRight",
						"pivot": [-3, 7, -1],
						"rotation": [-10, 0, 0],
						"mirror": true,
						"cubes": [
							{"name": "frontLegRight", "origin": [-4, 0, -2], "size": [2, 7, 2], "uv": [0, 15]}
						]
					},
					{
						"name": "head",
						"pivot": [0, 8, -1],
						"mirror": true,
						"cubes": [
							{"name": "head", "origin": [-2.5, 8, -6], "size": [5, 4, 5], "uv": [32, 0]}
						]
					},
					{
						"name": "earRight",
						"pivot": [0, 8, -1],
						"rotation": [0, -15, 0],
						"mirror": true,
						"cubes": [
							{"name": "earRight", "origin": [-2.5, 12, -2], "size": [2, 5, 1], "uv": [58, 0]}
						]
					},
					{
						"name": "earLeft",
						"pivot": [0, 8, -1],
						"rotation": [0, 15, 0],
						"mirror": true,
						"cubes": [
							{"name": "earLeft", "origin": [0.5, 12, -2], "size": [2, 5, 1], "uv": [52, 0]}
						]
					},
					{
						"name": "tail",
						"pivot": [0, 4, 7],
						"rotation": [-20, 0, 0],
						"mirror": true,
						"cubes": [
							{"name": "tail", "origin": [-1.5, 2.5, 7], "size": [3, 3, 2], "uv": [52, 6]}
						]
					},
					{
						"name": "nose",
						"pivot": [0, 8, -1],
						"mirror": true,
						"cubes": [
							{"name": "nose", "origin": [-0.5, 9.5, -6.5], "size": [1, 1, 1], "uv": [32, 9]}
						]
					}
				]
			}`
		}
	}
};
skin_presets.rabbit_baby = {
	display_name: 'Rabbit Baby',
	model: `{
		"name": "rabbit_baby",
		"texturewidth": 32,
		"textureheight": 32,
		"external_textures": ["entity/rabbit/rabbit_salt_baby.png"],
		"eyes": [
			[5, 5, 1, 2],
			[7, 5, 1, 2]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [0, 1, 1.6],
				"cubes": [
					{"origin": [-2, 2, -3], "size": [4, 3, 6], "pivot": [0, 3, 0], "rotation": [-30, 0, 0], "uv": [0, 8]}
				]
			},
			{
				"name": "tail",
				"parent": "body",
				"pivot": [0, 3.2, 3.6],
				"cubes": [
					{"origin": [-1.5, 2.22679, 2.58231], "size": [3, 3, 3], "pivot": [-0.1, 3.2, 3.6], "rotation": [-30, 0, 0], "uv": [0, 21]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 6, -1],
				"cubes": [
					{"origin": [-2.5, 5, -4], "size": [5, 4, 4], "uv": [0, 0]}
				]
			},
			{
				"name": "right_ear",
				"parent": "head",
				"pivot": [-1.5, 9.5, -1.5],
				"cubes": [
					{"origin": [-2.5, 9, -2], "size": [2, 4, 1], "uv": [18, 0]}
				]
			},
			{
				"name": "left_ear",
				"parent": "head",
				"pivot": [1.5, 9.5, -1.5],
				"cubes": [
					{"origin": [0.5, 9, -2], "size": [2, 4, 1], "uv": [24, 0]}
				]
			},
			{
				"name": "frontlegs",
				"parent": "body",
				"pivot": [0, 3.5, -1]
			},
			{
				"name": "leftFrontLeg",
				"parent": "frontlegs",
				"pivot": [1, 2.5, -1.5],
				"rotation": [22.5, 0, 0],
				"cubes": [
					{"origin": [0.5, 0, -2], "size": [1, 3, 1], "pivot": [1, 1.5, -1.5], "rotation": [-22.5, 0, 0], "uv": [18, 8]}
				]
			},
			{
				"name": "rightFrontLeg",
				"parent": "frontlegs",
				"pivot": [-1, 2.5, -1.5],
				"rotation": [22.5, 0, 0],
				"cubes": [
					{"origin": [-1.5, 0, -2], "size": [1, 3, 1], "pivot": [-1, 1.5, -1.5], "rotation": [-22.5, 0, 0], "uv": [14, 8]}
				]
			},
			{
				"name": "backlegs",
				"pivot": [0, 1, 2]
			},
			{
				"name": "leftBackLeg",
				"parent": "backlegs",
				"pivot": [1.5, 0.5, 2.5],
				"rotation": [0, 180, 0],
				"cubes": [
					{"origin": [0.5, 0, 3], "size": [2, 1, 3], "pivot": [2.5, 0.5, 3], "rotation": [0, -45, 0], "uv": [10, 17]}
				]
			},
			{
				"name": "rightBackLeg",
				"parent": "backlegs",
				"pivot": [-1.5, 0.5, 2.5],
				"rotation": [0, 180, 0],
				"cubes": [
					{"origin": [-3, 0, 1.6], "size": [2, 1, 3], "pivot": [-1, 0.5, 1.6], "rotation": [0, 45, 0], "uv": [0, 17]}
				]
			}
		]
	}`
};
skin_presets.ravager = {
	display_name: 'Ravager',
	model: `{
		"name": "ravager",
		"external_textures": ["entity/illager/ravager.png"],
		"texturewidth": 128,
		"textureheight": 128,
		"bones": [
			{
				"name": "body",
				"pivot": [0, 19, 2],
				"rotation": [90, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-7, 10, -2], "size": [14, 16, 20], "uv": [0, 55]},
					{"name": "body", "origin": [-6, -3, -2], "size": [12, 13, 18], "uv": [0, 91]}
				]
			},
			{
				"name": "neck",
				"pivot": [0, 20, -20],
				"cubes": [
					{"name": "neck", "origin": [-5, 21, -10], "size": [10, 10, 18], "uv": [68, 73]}
				]
			},
			{
				"name": "head",
				"parent": "neck",
				"pivot": [0, 28, -10],
				"cubes": [
					{"name": "head", "origin": [-8, 14, -24], "size": [16, 20, 16], "uv": [0, 0]},
					{"name": "head", "origin": [-2, 12, -28], "size": [4, 8, 4], "uv": [0, 0]}
				]
			},
			{
				"name": "mouth",
				"parent": "head",
				"pivot": [0, 15, -10],
				"cubes": [
					{"name": "mouth", "origin": [-8, 13, -24], "size": [16, 3, 16], "uv": [0, 36]}
				]
			},
			{
				"name": "horns",
				"parent": "head",
				"pivot": [-5, 27, -19],
				"rotation": [60, 0, 0],
				"cubes": [
					{"name": "horns", "origin": [-10, 27, -20], "size": [2, 14, 4], "uv": [74, 55]},
					{"name": "horns", "origin": [8, 27, -20], "size": [2, 14, 4], "uv": [74, 55]}
				]
			},
			{
				"name": "leg0",
				"pivot": [-12, 30, 22],
				"cubes": [
					{"name": "leg0", "origin": [-12, 0, 17], "size": [8, 37, 8], "uv": [96, 0]}
				]
			},
			{
				"name": "leg1",
				"pivot": [4, 30, 22],
				"cubes": [
					{"name": "leg1", "origin": [4, 0, 17], "size": [8, 37, 8], "uv": [96, 0]}
				]
			},
			{
				"name": "leg2",
				"pivot": [-4, 26, -4],
				"cubes": [
					{"name": "leg2", "origin": [-12, 0, -8], "size": [8, 37, 8], "uv": [64, 0]}
				]
			},
			{
				"name": "leg3",
				"pivot": [-4, 26, -4],
				"cubes": [
					{"name": "leg3", "origin": [4, 0, -8], "size": [8, 37, 8], "uv": [64, 0]}
				]
			}
		]
	}`
};
skin_presets.salmon = {
	display_name: 'Salmon',
	model: `{
		"name": "salmon",
		"external_textures": ["entity/fish/salmon.png"],
		"texturewidth": 32,
		"textureheight": 32,
		"bones": [
			{
				"name": "body_front",
				"pivot": [0, 0, -4],
				"cubes": [
					{"name": "body_front", "origin": [-1.5, 3.5, -4], "size": [3, 5, 8], "uv": [0, 0]}
				]
			},
			{
				"name": "body_back",
				"parent": "body_front",
				"pivot": [0, 0, 4],
				"cubes": [
					{"name": "body_back", "origin": [-1.5, 3.5, 4], "size": [3, 5, 8], "uv": [0, 13]}
				]
			},
			{
				"name": "dorsal_back",
				"parent": "body_back",
				"pivot": [0, 5, 4],
				"cubes": [
					{"name": "dorsal_back", "origin": [0, 8.5, 4], "size": [0, 2, 3], "uv": [2, 3]}
				]
			},
			{
				"name": "tailfin",
				"parent": "body_back",
				"pivot": [0, 0, 12],
				"cubes": [
					{"name": "tailfin", "origin": [0, 3.5, 12], "size": [0, 5, 6], "uv": [20, 10]}
				]
			},
			{
				"name": "dorsal_front",
				"parent": "body_front",
				"pivot": [0, 5, 2],
				"cubes": [
					{"name": "dorsal_front", "origin": [0, 8.5, 2], "size": [0, 2, 2], "uv": [4, 2]}
				]
			},
			{
				"name": "head",
				"parent": "body_front",
				"pivot": [0, 3, -4],
				"cubes": [
					{"name": "head", "origin": [-1, 4.5, -7], "size": [2, 4, 3], "uv": [22, 0]}
				]
			},
			{
				"name": "leftFin",
				"parent": "body_front",
				"pivot": [1.5, 1, -4],
				"rotation": [0, 0, 35],
				"cubes": [
					{"name": "leftFin", "origin": [-0.50752, 3.86703, -4], "size": [2, 0, 2], "uv": [2, 0]}
				]
			},
			{
				"name": "rightFin",
				"parent": "body_front",
				"pivot": [-1.5, 1, -4],
				"rotation": [0, 0, -35],
				"cubes": [
					{"name": "rightFin", "origin": [-1.49258, 3.86703, -4], "size": [2, 0, 2], "uv": [-2, 0]}
				]
			}
		]
	}`
};
skin_presets.sheep = {
	display_name: 'Sheep',
	model: `{
		"name": "sheep",
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "body",
				"pivot": [0, 19, 2],
				"rotation": [90, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-4, 13, -5], "size": [8, 16, 6], "uv": [28, 8]},
					{"name": "body", "origin": [-4, 13, -5], "size": [8, 16, 6], "uv": [28, 40], "inflate": 1.75}
				]
			},
			{
				"name": "head",
				"pivot": [0, 18, -8],
				"cubes": [
					{"name": "head", "origin": [-3, 16, -14], "size": [6, 6, 8], "uv": [0, 0]},
					{"name": "head", "origin": [-3, 16, -12], "size": [6, 6, 6], "uv": [0, 32], "inflate": 0.6}
				]
			},
			{
				"name": "leg0",
				"pivot": [-3, 12, 7],
				"cubes": [
					{"name": "leg0", "origin": [-5, 0, 5], "size": [4, 12, 4], "uv": [0, 16]},
					{"name": "leg0", "origin": [-5, 6, 5], "size": [4, 6, 4], "uv": [0, 48], "inflate": 0.5}
				]
			},
			{
				"name": "leg1",
				"pivot": [3, 12, 7],
				"cubes": [
					{"name": "leg1", "origin": [1, 0, 5], "size": [4, 12, 4], "uv": [0, 16]},
					{"name": "leg1", "origin": [1, 6, 5], "size": [4, 6, 4], "uv": [0, 48], "inflate": 0.5}
				]
			},
			{
				"name": "leg2",
				"pivot": [-3, 12, -5],
				"cubes": [
					{"name": "leg2", "origin": [-5, 0, -7], "size": [4, 12, 4], "uv": [0, 16]},
					{"name": "leg2", "origin": [-5, 6, -7], "size": [4, 6, 4], "uv": [0, 48], "inflate": 0.5}
				]
			},
			{
				"name": "leg3",
				"pivot": [3, 12, -5],
				"cubes": [
					{"name": "leg3", "origin": [1, 0, -7], "size": [4, 12, 4], "uv": [0, 16]},
					{"name": "leg3", "origin": [1, 6, -7], "size": [4, 6, 4], "uv": [0, 48], "inflate": 0.5}
				]
			}
		]
	}`
};
skin_presets.sheep_baby = {
	display_name: 'Sheep Baby',
	model: `{
		"name": "sheep_baby",
		"texturewidth": 32,
		"textureheight": 32,
		"eyes": [
			[5, 7, 1, 1],
			[9, 7, 1, 1]
		],
		"bones": [
			{
				"name": "root",
				"pivot": [0, 0, 0]
			},
			{
				"name": "head",
				"parent": "root",
				"pivot": [0, 8.5, -2.5],
				"cubes": [
					{"origin": [-2.5, 8, -6], "size": [5, 5, 5], "uv": [0, 0]}
				]
			},
			{
				"name": "leg0",
				"parent": "root",
				"pivot": [-2, 5, 3],
				"cubes": [
					{"origin": [-2.975, 0, 2], "size": [2, 5, 2], "uv": [0, 23]}
				]
			},
			{
				"name": "leg1",
				"parent": "root",
				"pivot": [2, 5, 3],
				"cubes": [
					{"origin": [0.975, 0, 2], "size": [2, 5, 2], "uv": [24, 12]}
				]
			},
			{
				"name": "leg2",
				"parent": "root",
				"pivot": [-2, 5, -2],
				"cubes": [
					{"origin": [-2.975, 0, -3], "size": [2, 5, 2], "uv": [8, 23]}
				]
			},
			{
				"name": "leg3",
				"parent": "root",
				"pivot": [2, 5, -2],
				"cubes": [
					{"origin": [0.975, 0, -3], "size": [2, 5, 2], "uv": [24, 5]}
				]
			},
			{
				"name": "body",
				"parent": "root",
				"pivot": [0, 8, 2.5],
				"cubes": [
					{"origin": [-3, 5, -4], "size": [6, 4, 9], "uv": [0, 10]}
				]
			}
		]
	}`
};
skin_presets.shield = {
	display_name: 'Shield',
	model: `{
		"name": "shield",
		"external_textures": ["entity/shield.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "shield",
				"pivot": [1, 15.5, 3],
				"cubes": [
					{"name": "shield", "origin": [0, 25, 0], "size": [2, 6, 6], "uv": [26, 0]},
					{"name": "shield", "origin": [-5, 17, -1], "size": [12, 22, 1], "uv": [0, 0]}
				]
			}
		]
	}`
};
skin_presets.shulker = {
	display_name: 'Shulker',
	model: `{
		"name": "shulker",
		"external_textures": ["entity/shulker/shulker_white.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "base",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "base", "origin": [-8, 0, -8], "size": [16, 8, 16], "uv": [0, 28]}
				]
			},
			{
				"name": "lid",
				"parent": "base",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "lid", "origin": [-8, 13, -8], "size": [16, 12, 16], "uv": [0, 0]}
				]
			},
			{
				"name": "head",
				"parent": "base",
				"pivot": [0, 12, 0],
				"cubes": [
					{"name": "head", "origin": [-3, 6, -3], "size": [6, 6, 6], "uv": [0, 52]}
				]
			}
		]
	}`
};
skin_presets.shulker_bullet = {
	display_name: 'Shulker Bullet',
	model: `{
		"name": "shulker_bullet",
		"external_textures": ["entity/shulker/shulker_white.png"],
		"texturewidth": 64,
		"textureheight": 32,
		"bones": [
			{
				"name": "body",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-4, -4, -1], "size": [8, 8, 2], "uv": [0, 0]},
					{"name": "body", "origin": [-1, -4, -4], "size": [2, 8, 8], "uv": [0, 10]},
					{"name": "body", "origin": [-4, -1, -4], "size": [8, 2, 8], "uv": [20, 0]}
				]
			}
		]
	}`
};
skin_presets.silverfish = {
	display_name: 'Silverfish',
	model: `{
		"name": "silverfish",
		"external_textures": ["entity/silverfish.png"],
		"texturewidth": 64,
		"textureheight": 32,
		"bones": [
			{
				"name": "bodyPart_2",
				"pivot": [0, 4, 1],
				"cubes": [
					{"name": "bodyPart_2", "origin": [-3, 0, -0.5], "size": [6, 4, 3], "uv": [0, 9]}
				]
			},
			{
				"name": "bodyPart_0",
				"parent": "bodyPart_2",
				"pivot": [0, 2, -3.5],
				"cubes": [
					{"name": "bodyPart_0", "origin": [-1.5, 0, -4.5], "size": [3, 2, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "bodyPart_1",
				"parent": "bodyPart_2",
				"pivot": [0, 3, -1.5],
				"cubes": [
					{"name": "bodyPart_1", "origin": [-2, 0, -2.5], "size": [4, 3, 2], "uv": [0, 4]}
				]
			},
			{
				"name": "bodyLayer_2",
				"parent": "bodyPart_1",
				"pivot": [0, 5, -1.5],
				"cubes": [
					{"name": "bodyLayer_2", "origin": [-3, 0, -3], "size": [6, 5, 2], "uv": [20, 18], "layer": true}
				]
			},
			{
				"name": "bodyPart_3",
				"parent": "bodyPart_2",
				"pivot": [0, 3, 4],
				"cubes": [
					{"name": "bodyPart_3", "origin": [-1.5, 0, 2.5], "size": [3, 3, 3], "uv": [0, 16]}
				]
			},
			{
				"name": "bodyPart_4",
				"parent": "bodyPart_2",
				"pivot": [0, 2, 7],
				"cubes": [
					{"name": "bodyPart_4", "origin": [-1, 0, 5.5], "size": [2, 2, 3], "uv": [0, 22]}
				]
			},
			{
				"name": "bodyLayer_1",
				"parent": "bodyPart_4",
				"pivot": [0, 4, 7],
				"cubes": [
					{"name": "bodyLayer_1", "origin": [-3, 0, 5.5], "size": [6, 4, 3], "uv": [20, 11], "layer": true}
				]
			},
			{
				"name": "bodyPart_5",
				"parent": "bodyPart_2",
				"pivot": [0, 1, 9.5],
				"cubes": [
					{"name": "bodyPart_5", "origin": [-1, 0, 8.5], "size": [2, 1, 2], "uv": [11, 0]}
				]
			},
			{
				"name": "bodyPart_6",
				"parent": "bodyPart_2",
				"pivot": [0, 1, 11.5],
				"cubes": [
					{"name": "bodyPart_6", "origin": [-0.5, 0, 10.5], "size": [1, 1, 2], "uv": [13, 4]}
				]
			},
			{
				"name": "bodyLayer_0",
				"parent": "bodyPart_2",
				"pivot": [0, 8, 1],
				"cubes": [
					{"name": "bodyLayer_0", "origin": [-5, 0, -0.5], "size": [10, 8, 3], "uv": [20, 0], "layer": true}
				]
			}
		]
	}`
};
skin_presets.skeleton = {
	display_name: 'Skeleton/Stray',
	model: `{
		"name": "skeleton",
		"external_textures": ["entity/skeleton/skeleton.png"],
		"texturewidth": 64,
		"textureheight": 32,
		"eyes": [
			[9, 12, 2, 1],
			[13, 12, 2, 1]
		],
		"bones": [
			{
				"name": "waist",
				"pivot": [0, 12, 0]
			},
			{
				"name": "Body",
				"parent": "waist",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "Body", "origin": [-4, 12, -2], "size": [8, 12, 4], "uv": [16, 16]}
				]
			},
			{
				"name": "Head",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "Head", "origin": [-4, 24, -4], "size": [8, 8, 8], "uv": [0, 0]},
					{"name": "Head Layer", "visibility": false, "origin": [-4, 24, -4], "size": [8, 8, 8], "uv": [32, 0], "inflate": 0.5}
				]
			},
			{
				"name": "RightArm",
				"pivot": [-5, 22, 0],
				"cubes": [
					{"name": "RightArm", "origin": [-6, 12, -1], "size": [2, 12, 2], "uv": [40, 16]}
				]
			},
			{
				"name": "LeftArm",
				"pivot": [5, 22, 0],
				"mirror": true,
				"cubes": [
					{"name": "LeftArm", "origin": [4, 12, -1], "size": [2, 12, 2], "uv": [40, 16]}
				]
			},
			{
				"name": "leftItem",
				"parent": "LeftArm",
				"pivot": [6, 15, 1]
			},
			{
				"name": "RightLeg",
				"pivot": [-2, 12, 0],
				"cubes": [
					{"name": "RightLeg", "origin": [-3, 0, -1], "size": [2, 12, 2], "uv": [0, 16]}
				]
			},
			{
				"name": "LeftLeg",
				"pivot": [2, 12, 0],
				"mirror": true,
				"cubes": [
					{"name": "LeftLeg", "origin": [1, 0, -1], "size": [2, 12, 2], "uv": [0, 16]}
				]
			}
		]
	}`
};
skin_presets.slime = {
	display_name: 'Slime',
	model: `{
		"name": "slime",
		"external_textures": ["entity/slime/slime.png"],
		"texturewidth": 64,
		"textureheight": 32,
		"bones": [
			{
				"name": "inner",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "cube", "origin": [-3, 1, -3], "size": [6, 6, 6], "uv": [0, 16]},
					{"name": "eye0", "origin": [-3.3, 4, -3.5], "size": [2, 2, 2], "uv": [32, 0]},
					{"name": "eye1", "origin": [1.3, 4, -3.5], "size": [2, 2, 2], "uv": [32, 4]},
					{"name": "mouth", "origin": [0, 2, -3.5], "size": [1, 1, 1], "uv": [32, 8]}
				]
			},
			{
				"name": "outer",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "cube layer", "visibility": false, "origin": [-4, 0, -4], "size": [8, 8, 8], "uv": [0, 0], "layer": true},
					{"name": "eye0 layer", "visibility": false, "origin": [-3.3, 4, -3.5], "size": [2, 2, 2], "uv": [32, 0], "layer": true},
					{"name": "eye1 layer", "visibility": false, "origin": [1.3, 4, -3.5], "size": [2, 2, 2], "uv": [32, 4], "layer": true},
					{"name": "mouth layer", "visibility": false, "origin": [0, 2, -3.5], "size": [1, 1, 1], "uv": [32, 8], "layer": true}
				]
			}
		]
	}`
};
skin_presets.sniffer = {
	display_name: 'Sniffer',
	model: `{
		"name": "sniffer",
		"external_textures": ["entity/sniffer/sniffer.png"],
		"texturewidth": 192,
		"textureheight": 192,
		"eyes": [
			[13, 31, 4, 1],
			[34, 31, 4, 1]
		],
		"bones": [
			{
				"name": "bone",
				"pivot": [0, 19, 0]
			},
			{
				"name": "body",
				"parent": "bone",
				"pivot": [0, 0, 0],
				"cubes": [
					{"origin": [-12.5, 9, -20], "size": [25, 24, 40], "inflate": 0.5, "uv": [62, 0]},
					{"origin": [-12.5, 4, -20], "size": [25, 29, 40], "uv": [62, 68]},
					{"origin": [-12.5, 8, -20], "size": [25, 0, 40], "uv": [87, 68]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 13.5, -19.4],
				"cubes": [
					{"origin": [-6.5, 3, -30.9], "size": [13, 18, 11], "uv": [8, 15]},
					{"origin": [-6.5, 6, -30.9], "size": [13, 0, 11], "uv": [8, 4]}
				]
			},
			{
				"name": "left_ear",
				"parent": "head",
				"pivot": [6.4, 21, -23.9],
				"cubes": [
					{"origin": [6.4, 2, -26.9], "size": [1, 19, 7], "uv": [2, 0]}
				]
			},
			{
				"name": "right_ear",
				"parent": "head",
				"pivot": [-6.4, 21, -23.9],
				"cubes": [
					{"origin": [-7.4, 2, -26.9], "size": [1, 19, 7], "uv": [48, 0]}
				]
			},
			{
				"name": "nose",
				"parent": "head",
				"pivot": [0, 18, -30.9],
				"cubes": [
					{"origin": [-6.5, 18, -39.9], "size": [13, 2, 9], "uv": [10, 45]}
				]
			},
			{
				"name": "lower_beak",
				"parent": "head",
				"pivot": [0, 11, -31.9],
				"cubes": [
					{"origin": [-6.5, 6, -39.9], "size": [13, 12, 9], "uv": [10, 57]}
				]
			},
			{
				"name": "right_front_leg",
				"parent": "bone",
				"pivot": [-7.5, 9, -15],
				"cubes": [
					{"origin": [-11, 0, -19], "size": [7, 10, 8], "uv": [32, 87]}
				]
			},
			{
				"name": "right_mid_leg",
				"parent": "bone",
				"pivot": [-7.5, 9, 0],
				"cubes": [
					{"origin": [-11, 0, -4], "size": [7, 10, 8], "uv": [32, 105]}
				]
			},
			{
				"name": "right_hind_leg",
				"parent": "bone",
				"pivot": [-7.5, 9, 15],
				"cubes": [
					{"origin": [-11, 0, 11], "size": [7, 10, 8], "uv": [32, 123]}
				]
			},
			{
				"name": "left_front_leg",
				"parent": "bone",
				"pivot": [7.5, 9, -15],
				"cubes": [
					{"origin": [4, 0, -19], "size": [7, 10, 8], "uv": [0, 87]}
				]
			},
			{
				"name": "left_mid_leg",
				"parent": "bone",
				"pivot": [7.5, 9, 0],
				"cubes": [
					{"origin": [4, 0, -4], "size": [7, 10, 8], "uv": [0, 105]}
				]
			},
			{
				"name": "left_hind_leg",
				"parent": "bone",
				"pivot": [7.5, 9, 15],
				"cubes": [
					{"origin": [4, 0, 11], "size": [7, 10, 8], "uv": [0, 123]}
				]
			}
		]
	}`
}
skin_presets.snowgolem = {
	display_name: 'Snowgolem',
	model: `{
		"name": "snowgolem",
		"external_textures": ["entity/snow_golem.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"eyes": [
			[9, 11],
			[13, 11]
		],
		"bones": [
			{
				"name": "piece2",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "piece2", "origin": [-6, 0, -6], "size": [12, 12, 12], "uv": [0, 36], "inflate": -0.5}
				]
			},
			{
				"name": "piece1",
				"parent": "piece2",
				"pivot": [0, 11, 0],
				"cubes": [
					{"name": "piece1", "origin": [-5, 11, -5], "size": [10, 10, 10], "uv": [0, 16], "inflate": -0.5}
				]
			},
			{
				"name": "head",
				"parent": "piece1",
				"pivot": [0, 20, 0],
				"cubes": [
					{"name": "head", "origin": [-4, 20, -4], "size": [8, 8, 8], "uv": [0, 0], "inflate": -0.5}
				]
			},
			{
				"name": "arm1",
				"parent": "piece1",
				"pivot": [0, 18, 0],
				"rotation": [0, 0, 45],
				"cubes": [
					{"name": "arm1", "origin": [1, 20, -1], "size": [12, 2, 2], "uv": [32, 0], "inflate": -0.5}
				]
			},
			{
				"name": "arm2",
				"parent": "piece1",
				"pivot": [0, 18, 0],
				"rotation": [0, 0, 135],
				"cubes": [
					{"name": "arm2", "origin": [1, 14, -1], "size": [12, 2, 2], "uv": [32, 0], "inflate": -0.5}
				]
			}
		]
	}`
};
skin_presets.spider = {
	display_name: 'Spider',
	model: `{
		"name": "spider",
		"texturewidth": 64,
		"textureheight": 32,
		"bones": [
			{
				"name": "head",
				"pivot": [0, 9, -3],
				"cubes": [
					{"name": "head", "origin": [-4, 5, -11], "size": [8, 8, 8], "uv": [32, 4]}
				]
			},
			{
				"name": "body0",
				"pivot": [0, 9, 0],
				"cubes": [
					{"name": "body0", "origin": [-3, 6, -3], "size": [6, 6, 6], "uv": [0, 0]}
				]
			},
			{
				"name": "body1",
				"pivot": [0, 9, 9],
				"cubes": [
					{"name": "body1", "origin": [-5, 5, 3], "size": [10, 8, 12], "uv": [0, 12]}
				]
			},
			{
				"name": "leg0",
				"pivot": [-4, 9, 2],
				"rotation": [0, 45, -45],
				"cubes": [
					{"name": "leg0", "origin": [-19, 8, 1], "size": [16, 2, 2], "uv": [18, 0]}
				]
			},
			{
				"name": "leg1",
				"pivot": [4, 9, 2],
				"rotation": [0, -45, 45],
				"cubes": [
					{"name": "leg1", "origin": [3, 8, 1], "size": [16, 2, 2], "uv": [18, 0]}
				]
			},
			{
				"name": "leg2",
				"pivot": [-4, 9, 1],
				"rotation": [0, 15, -35],
				"cubes": [
					{"name": "leg2", "origin": [-19, 8, 0], "size": [16, 2, 2], "uv": [18, 0]}
				]
			},
			{
				"name": "leg3",
				"pivot": [4, 9, 1],
				"rotation": [0, -15, 35],
				"cubes": [
					{"name": "leg3", "origin": [3, 8, 0], "size": [16, 2, 2], "uv": [18, 0]}
				]
			},
			{
				"name": "leg4",
				"pivot": [-4, 9, 0],
				"rotation": [0, -15, -35],
				"cubes": [
					{"name": "leg4", "origin": [-19, 8, -1], "size": [16, 2, 2], "uv": [18, 0]}
				]
			},
			{
				"name": "leg5",
				"pivot": [4, 9, 0],
				"rotation": [0, 15, 35],
				"cubes": [
					{"name": "leg5", "origin": [3, 8, -1], "size": [16, 2, 2], "uv": [18, 0]}
				]
			},
			{
				"name": "leg6",
				"pivot": [-4, 9, -1],
				"rotation": [0, -45, -45],
				"cubes": [
					{"name": "leg6", "origin": [-19, 8, -2], "size": [16, 2, 2], "uv": [18, 0]}
				]
			},
			{
				"name": "leg7",
				"pivot": [4, 9, -1],
				"rotation": [0, 45, 45],
				"cubes": [
					{"name": "leg7", "origin": [3, 8, -2], "size": [16, 2, 2], "uv": [18, 0]}
				]
			}
		]
	}`
};
skin_presets.spyglass = {
	display_name: 'Spyglass',
	model: `{
		"name": "spyglass",
		"external_textures": ["entity/spyglass.png"],
		"texturewidth": 16,
		"textureheight": 16,
		"bones": [
			{
				"name": "spyglass",
				"pivot": [0, 0, 0],
				"cubes": [
					{"origin": [-11.1, -0.1, -0.1], "size": [6.2, 2.2, 2.2], "uv": [0, 0]},
					{"origin": [-5, 0, 0], "size": [5, 2, 2], "uv": [0, 4]}
				]
			}
		]
	}`
}
skin_presets.squid = {
	display_name: 'Squid',
	model: `{
		"name": "squid",
		"external_textures": ["entity/squid.png"],
		"texturewidth": 64,
		"textureheight": 32,
		"eyes": [
			[14, 18],
			[20, 18]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-6, -8, -6], "size": [12, 16, 12], "uv": [0, 0]}
				]
			},
			{
				"name": "tentacle1",
				"pivot": [5, -7, 0],
				"rotation": [0, 90, 0],
				"cubes": [
					{"name": "tentacle1", "origin": [4, -25, -1], "size": [2, 18, 2], "uv": [48, 0]}
				]
			},
			{
				"name": "tentacle2",
				"pivot": [3.5, -7, 3.5],
				"rotation": [0, 45, 0],
				"cubes": [
					{"name": "tentacle2", "origin": [2.5, -25, 2.5], "size": [2, 18, 2], "uv": [48, 0]}
				]
			},
			{
				"name": "tentacle3",
				"pivot": [0, -7, 5],
				"cubes": [
					{"name": "tentacle3", "origin": [-1, -25, 4], "size": [2, 18, 2], "uv": [48, 0]}
				]
			},
			{
				"name": "tentacle4",
				"pivot": [-3.5, -7, 3.5],
				"rotation": [0, -45, 0],
				"cubes": [
					{"name": "tentacle4", "origin": [-4.5, -25, 2.5], "size": [2, 18, 2], "uv": [48, 0]}
				]
			},
			{
				"name": "tentacle5",
				"pivot": [-5, -7, 0],
				"rotation": [0, -90, 0],
				"cubes": [
					{"name": "tentacle5", "origin": [-6, -25, -1], "size": [2, 18, 2], "uv": [48, 0]}
				]
			},
			{
				"name": "tentacle6",
				"pivot": [-3.5, -7, -3.5],
				"rotation": [0, -135, 0],
				"cubes": [
					{"name": "tentacle6", "origin": [-4.5, -25, -4.5], "size": [2, 18, 2], "uv": [48, 0]}
				]
			},
			{
				"name": "tentacle7",
				"pivot": [0, -7, -5],
				"rotation": [0, -180, 0],
				"cubes": [
					{"name": "tentacle7", "origin": [-1, -25, -6], "size": [2, 18, 2], "uv": [48, 0]}
				]
			},
			{
				"name": "tentacle8",
				"pivot": [3.5, -7, -3.5],
				"rotation": [0, -225, 0],
				"cubes": [
					{"name": "tentacle8", "origin": [2.5, -25, -4.5], "size": [2, 18, 2], "uv": [48, 0]}
				]
			}
		]
	}`
};
skin_presets.squid_baby = {
	display_name: 'Squid Baby',
	model: `{
		"name": "squid_baby",
		"texturewidth": 32,
		"textureheight": 32,
		"external_textures": ["entity/squid/squid_baby.png"],
		"eyes": [
			[9, 12, 2, 2],
			[13, 12, 2, 2]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [0, 0, 0],
				"cubes": [
					{"origin": [-4, -4, -4], "size": [8, 10, 8], "uv": [0, 0]}
				]
			},
			{
				"name": "tentacle1",
				"parent": "body",
				"pivot": [3, -4.5, 0],
				"cubes": [
					{"origin": [2, -10, -1], "size": [2, 6, 2], "uv": [0, 18]}
				]
			},
			{
				"name": "tentacle2",
				"parent": "body",
				"pivot": [2.35355, -4.5, 2.35355],
				"cubes": [
					{"origin": [1.35355, -10, 1.35355], "size": [2, 6, 2], "pivot": [2.35355, -7, 2.35355], "rotation": [0, 45, 0], "uv": [0, 18]}
				]
			},
			{
				"name": "tentacle3",
				"parent": "body",
				"pivot": [0, -4.5, 3],
				"cubes": [
					{"origin": [-1, -10, 2], "size": [2, 6, 2], "uv": [0, 18]}
				]
			},
			{
				"name": "tentacle4",
				"parent": "body",
				"pivot": [-2.35355, -4.5, 2.35355],
				"cubes": [
					{"origin": [-3.35355, -10, 1.35355], "size": [2, 6, 2], "pivot": [-2.35355, -7, 2.35355], "rotation": [0, -45, 0], "uv": [0, 18], "mirror": true}
				]
			},
			{
				"name": "tentacle5",
				"parent": "body",
				"pivot": [-3, -4.5, 0],
				"cubes": [
					{"origin": [-4, -10, -1], "size": [2, 6, 2], "uv": [0, 18]}
				]
			},
			{
				"name": "tentacle6",
				"parent": "body",
				"pivot": [-2.35355, -4.5, -2.35355],
				"cubes": [
					{"origin": [-3.35355, -10, -3.35355], "size": [2, 6, 2], "pivot": [-2.35355, -7, -2.35355], "rotation": [0, 45, 0], "uv": [0, 18], "mirror": true}
				]
			},
			{
				"name": "tentacle7",
				"parent": "body",
				"pivot": [0, -4.5, -3],
				"cubes": [
					{"origin": [-1, -10, -4], "size": [2, 6, 2], "uv": [0, 18]}
				]
			},
			{
				"name": "tentacle8",
				"parent": "body",
				"pivot": [2.35355, -4.5, -2.35355],
				"cubes": [
					{"origin": [1.35355, -10, -3.35355], "size": [2, 6, 2], "pivot": [2.35355, -7, -2.35355], "rotation": [0, -45, 0], "uv": [0, 18]}
				]
			}
		]
	}`
};
skin_presets.strider = {
	display_name: 'Strider',
	model: `{
		"name": "strider",
		"external_textures": ["entity/strider/strider.png"],
		"texturewidth": 64,
		"textureheight": 128,
		"eyes": [
			[17, 25, 2, 1],
			[29, 25, 2, 1]
		],
		"bones": [
			{
				"name": "Body",
				"pivot": [0, 17, 0],
				"cubes": [
					{"name": "cube", "origin": [-8, 17, -8], "size": [16, 14, 16], "uv": [0, 0]}
				]
			},
			{
				"name": "right_bristles_1",
				"parent": "Body",
				"pivot": [-8, 30, 0],
				"rotation": [0, 0, -60],
				"mirror": true,
				"cubes": [
					{"name": "cube", "origin": [-20, 30, -8], "size": [12, 0, 16], "uv": [4, 33]}
				]
			},
			{
				"name": "left_bristles_1",
				"parent": "Body",
				"pivot": [8, 30, 0],
				"rotation": [0, 0, 60],
				"cubes": [
					{"name": "cube", "origin": [8, 30, -8], "size": [12, 0, 16], "uv": [4, 33]}
				]
			},
			{
				"name": "right_bristles_2",
				"parent": "Body",
				"pivot": [-8, 26, 0],
				"rotation": [0, 0, -60],
				"mirror": true,
				"cubes": [
					{"name": "cube", "origin": [-20, 26, -8], "size": [12, 0, 16], "uv": [4, 49]}
				]
			},
			{
				"name": "left_bristles_2",
				"parent": "Body",
				"pivot": [8, 26, 0],
				"rotation": [0, 0, 60],
				"cubes": [
					{"name": "cube", "origin": [8, 26, -8], "size": [12, 0, 16], "uv": [4, 49]}
				]
			},
			{
				"name": "right_bristles_3",
				"parent": "Body",
				"pivot": [-8, 21, 0],
				"rotation": [0, 0, -60],
				"mirror": true,
				"cubes": [
					{"name": "cube", "origin": [-20, 21, -8], "size": [12, 0, 16], "uv": [4, 65]}
				]
			},
			{
				"name": "left_bristles_3",
				"parent": "Body",
				"pivot": [8, 21, 0],
				"rotation": [0, 0, 60],
				"cubes": [
					{"name": "cube", "origin": [8, 21, -8], "size": [12, 0, 16], "uv": [4, 65]}
				]
			},
			{
				"name": "RightLeg",
				"pivot": [-4, 17, 0],
				"cubes": [
					{"name": "cube", "origin": [-6, 0, -2], "size": [4, 17, 4], "uv": [0, 32]}
				]
			},
			{
				"name": "LeftLeg",
				"pivot": [4, 17, 0],
				"mirror": true,
				"cubes": [
					{"name": "cube", "origin": [2, 0, -2], "size": [4, 17, 4], "uv": [0, 32]}
				]
			}
		]
	}`
};
skin_presets.strider_baby = {
	display_name: 'Strider Baby',
	model: `{
		"name": "strider_baby",
		"texturewidth": 32,
		"textureheight": 32,
		"external_textures": ["entity/strider/strider_baby.png"],
		"eyes": [
			[9, 11, 1, 1],
			[13, 11, 1, 1]
		],
		"bones": [
			{
				"name": "right_leg",
				"pivot": [-1.5, 4, 0],
				"cubes": [
					{"origin": [-2.5, 0, -1], "size": [2, 4, 2], "uv": [0, 24]}
				]
			},
			{
				"name": "left_leg",
				"pivot": [1.5, 4, 0],
				"cubes": [
					{"origin": [0.5, 0, -1], "size": [2, 4, 2], "uv": [8, 24]}
				]
			},
			{
				"name": "body",
				"pivot": [0, 7.25, 0],
				"cubes": [
					{"origin": [-3.5, 4, -4], "size": [7, 7, 8], "uv": [0, 0]}
				]
			},
			{
				"name": "bristles",
				"parent": "body",
				"pivot": [0, 11.5, 0],
				"cubes": [
					{"origin": [-3.5, 11, 2], "size": [7, 3, 0], "layer": true, "uv": [0, 21]},
					{"origin": [-3.5, 11, 0], "size": [7, 3, 0], "layer": true, "uv": [0, 18]},
					{"origin": [-3.5, 11, -2], "size": [7, 3, 0], "layer": true, "uv": [0, 15]}
				]
			}
		]
	}`
};
skin_presets.tadpole = {
	display_name: 'Tadpole',
	model: `{
		"name": "tadpole",
		"external_textures": ["entity/tadpole/tadpole.png"],
		"texturewidth": 16,
		"textureheight": 16,
		"eyes": [
			[2, 3, 2, 1],
			[5, 3, 2, 1]
		],
		"bones": [
			{
				"name": "root",
				"pivot": [0, 0, 0]
			},
			{
				"name": "body",
				"parent": "root",
				"pivot": [0, 0, 1],
				"cubes": [
					{"origin": [-1.5, 1, -2.5], "size": [3, 2, 3], "uv": [0, 0]}
				]
			},
			{
				"name": "tail",
				"parent": "root",
				"pivot": [0, 0, 1],
				"cubes": [
					{"origin": [0, 1, -0.5], "size": [0, 2, 7], "uv": [0, 0]}
				]
			}
		]
	}`
};
skin_presets.tropicalfish_a = {
	display_name: 'Tropicalfish A',
	model: `{
		"name": "tropicalfish_a",
		"external_textures": ["entity/fish/tropical_a.png"],
		"texturewidth": 32,
		"textureheight": 32,
		"bones": [
			{
				"name": "body",
				"pivot": [-0.5, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-1, 0, -3], "size": [2, 3, 6], "uv": [0, 0]},
					{"name": "body", "origin": [0, 3, -2.9992], "size": [0, 4, 6], "uv": [10, -6]}
				]
			},
			{
				"name": "tailfin",
				"parent": "body",
				"pivot": [0, 0, 3],
				"cubes": [
					{"name": "tailfin", "origin": [0, 0, 3], "size": [0, 3, 4], "uv": [24, -4]}
				]
			},
			{
				"name": "leftFin",
				"parent": "body",
				"pivot": [0.5, 0, 1],
				"rotation": [0, -35, 0],
				"cubes": [
					{"name": "leftFin", "origin": [0.336, 0, -0.10594], "size": [2, 2, 0], "uv": [2, 12]}
				]
			},
			{
				"name": "rightFin",
				"parent": "body",
				"pivot": [-0.5, 0, 1],
				"rotation": [0, 35, 0],
				"cubes": [
					{"name": "rightFin", "origin": [-2.336, 0, -0.10594], "size": [2, 2, 0], "uv": [2, 16]}
				]
			}
		]
	}`
};
skin_presets.tropicalfish_b = {
	display_name: 'Tropicalfish B',
	model: `{
		"name": "tropicalfish_b",
		"external_textures": ["entity/fish/tropical_b.png"],
		"texturewidth": 32,
		"textureheight": 32,
		"bones": [
			{
				"name": "body",
				"pivot": [-0.5, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-1, 0, -0.0008], "size": [2, 6, 6], "uv": [0, 20]},
					{"name": "body", "origin": [0, -5, -0.0008], "size": [0, 5, 6], "uv": [20, 21]},
					{"name": "body", "origin": [0, 6, -0.0008], "size": [0, 5, 6], "uv": [20, 10]}
				]
			},
			{
				"name": "tailfin",
				"parent": "body",
				"pivot": [0, 0, 6],
				"cubes": [
					{"name": "tailfin", "origin": [0, 0.0008, 6], "size": [0, 6, 5], "uv": [21, 16]}
				]
			},
			{
				"name": "leftFin",
				"parent": "body",
				"pivot": [0.5, 0, 1],
				"rotation": [0, -35, 0],
				"cubes": [
					{"name": "leftFin", "origin": [2.05673, 0, 2.35152], "size": [2, 2, 0], "uv": [2, 12]}
				]
			},
			{
				"name": "rightFin",
				"parent": "body",
				"pivot": [-0.5, 0, 1],
				"rotation": [0, 35, 0],
				"cubes": [
					{"name": "rightFin", "origin": [-4.05673, 0, 2.35152], "size": [2, 2, 0], "uv": [2, 16]}
				]
			}
		]
	}`
};
skin_presets.turtle = {
	display_name: 'Turtle',
	model_bedrock: `{
		"name": "sea_turtle",
		"external_textures": ["entity/sea_turtle.png"],
		"texturewidth": 128,
		"textureheight": 64,
		"bones": [
			{
				"name": "body",
				"pivot": [0, 13, -10],
				"rotation": [90, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-9.5, -10, -20], "size": [19, 20, 6], "uv": [6, 37]},
					{"name": "body", "origin": [-5.5, -8, -23], "size": [11, 18, 3], "uv": [30, 1]}
				]
			},
			{
				"name": "eggbelly",
				"parent": "body",
				"pivot": [0, 13, -10],
				"cubes": [
					{"name": "eggbelly", "origin": [-4.5, -8, -24], "size": [9, 18, 1], "uv": [69, 33]}
				]
			},
			{
				"name": "head",
				"pivot": [0, 5, -10],
				"cubes": [
					{"name": "head", "origin": [-3, 1, -13], "size": [6, 5, 6], "uv": [2, 0]}
				]
			},
			{
				"name": "leg0",
				"pivot": [-3.5, 2, 11],
				"cubes": [
					{"name": "leg0", "origin": [-5.5, 1, 11], "size": [4, 1, 10], "uv": [0, 23]}
				]
			},
			{
				"name": "leg1",
				"pivot": [3.5, 2, 11],
				"cubes": [
					{"name": "leg1", "origin": [1.5, 1, 11], "size": [4, 1, 10], "uv": [0, 12]}
				]
			},
			{
				"name": "leg2",
				"pivot": [-5, 3, -4],
				"rotation": [0, 10, 0],
				"cubes": [
					{"name": "leg2", "origin": [-18, 2, -6], "size": [13, 1, 5], "uv": [26, 30]}
				]
			},
			{
				"name": "leg3",
				"pivot": [5, 3, -4],
				"rotation": [0, -10, 0],
				"cubes": [
					{"name": "leg3", "origin": [5, 2, -6], "size": [13, 1, 5], "uv": [26, 24]}
				]
			}
		]
	}`,
	model_java: `{
		"name": "big_sea_turtle",
		"external_textures": ["entity/sea_turtle.png"],
		"texturewidth": 128,
		"textureheight": 64,
		"bones": [
			{
				"name": "body",
				"pivot": [0, 13, -10],
				"rotation": [90, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-9.5, -10, -20], "size": [19, 20, 6], "uv": [7, 37]},
					{"name": "body", "origin": [-5.5, -8, -23], "size": [11, 18, 3], "uv": [31, 1]}
				]
			},
			{
				"name": "eggbelly",
				"parent": "body",
				"pivot": [0, 13, -10],
				"cubes": [
					{"name": "eggbelly", "origin": [-4.5, -8, -24], "size": [9, 18, 1], "uv": [70, 33]}
				]
			},
			{
				"name": "head",
				"pivot": [0, 5, -10],
				"cubes": [
					{"name": "head", "origin": [-3, 1, -13], "size": [6, 5, 6], "uv": [3, 0]}
				]
			},
			{
				"name": "leg0",
				"pivot": [-3.5, 2, 11],
				"cubes": [
					{"name": "leg0", "origin": [-5.5, 1, 11], "size": [4, 1, 10], "uv": [1, 23]}
				]
			},
			{
				"name": "leg1",
				"pivot": [3.5, 2, 11],
				"cubes": [
					{"name": "leg1", "origin": [1.5, 1, 11], "size": [4, 1, 10], "uv": [1, 12]}
				]
			},
			{
				"name": "leg2",
				"pivot": [-5, 3, -4],
				"rotation": [0, 10, 0],
				"cubes": [
					{"name": "leg2", "origin": [-18, 2, -6], "size": [13, 1, 5], "uv": [27, 30]}
				]
			},
			{
				"name": "leg3",
				"pivot": [5, 3, -4],
				"rotation": [0, -10, 0],
				"cubes": [
					{"name": "leg3", "origin": [5, 2, -6], "size": [13, 1, 5], "uv": [27, 24]}
				]
			}
		]
	}`
};
skin_presets.turtle_baby = {
	display_name: 'Turtle Baby',
	model: `{
		"name": "turtle_baby",
		"texturewidth": 16,
		"textureheight": 16,
		"external_textures": ["entity/turtle/sea_turtle_baby.png"],
		"eyes": [
			[1, 10, 1, 1],
			[7, 10, 1, 1]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [0, 1, 1],
				"cubes": [
					{"origin": [-2, 0, -1], "size": [4, 2, 4], "uv": [0, 0]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 1, -1],
				"cubes": [
					{"origin": [-1.5, 0, -4], "size": [3, 3, 3], "uv": [0, 6]}
				]
			},
			{
				"name": "leg0",
				"parent": "body",
				"pivot": [-2, 0, 2.5],
				"cubes": [
					{"origin": [-4, 0, 2], "size": [2, 0, 1], "uv": [-1, 0]}
				]
			},
			{
				"name": "leg1",
				"parent": "body",
				"pivot": [2, 0, 2.5],
				"cubes": [
					{"origin": [2, 0, 2], "size": [2, 0, 1], "uv": [-1, 1]}
				]
			},
			{
				"name": "leg2",
				"parent": "body",
				"pivot": [-2, 0, -0.5],
				"cubes": [
					{"origin": [-4, 0, -1], "size": [2, 0, 1], "uv": [8, 6]}
				]
			},
			{
				"name": "leg3",
				"parent": "body",
				"pivot": [2, 0, -0.5],
				"cubes": [
					{"origin": [2, 0, -1], "size": [2, 0, 1], "uv": [8, 7]}
				]
			}
		]
	}`
};
skin_presets.vex = {
	display_name: 'Vex',
	model: `{
		"name": "vex",
		"external_textures": ["entity/vex/vex.png"],
		"texturewidth": 32,
		"textureheight": 32,
		"eyes": [
			[5, 8, 2, 1],
			[8, 8, 2, 1]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [0, 0, 0],
				"cubes": [
					{"origin": [-1.5, 0, -1], "size": [3, 4, 2], "uv": [0, 10]},
					{"origin": [-1.5, -2, -1], "size": [3, 5, 2], "inflate": -0.2, "uv": [0, 16]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 4, 0],
				"cubes": [
					{"origin": [-2.5, 4, -2.5], "size": [5, 5, 5], "uv": [0, 0]}
				]
			},
			{
				"name": "rightArm",
				"parent": "body",
				"pivot": [-1.75, 3.75, 0],
				"cubes": [
					{"origin": [-3, 0.25, -1], "size": [2, 4, 2], "inflate": -0.1, "uv": [23, 0]}
				]
			},
			{
				"name": "rightItem",
				"parent": "rightArm",
				"pivot": [-2, 1, 0]
			},
			{
				"name": "leftArm",
				"parent": "body",
				"pivot": [1.75, 3.75, 0],
				"cubes": [
					{"origin": [1, 0.25, -1], "size": [2, 4, 2], "inflate": -0.1, "uv": [23, 6]}
				]
			},
			{
				"name": "leftWing",
				"parent": "body",
				"pivot": [0.5, 3, 1],
				"cubes": [
					{"origin": [0.5, -2, 1], "size": [8, 5, 0], "uv": [16, 22], "mirror": true}
				]
			},
			{
				"name": "rightWing",
				"parent": "body",
				"pivot": [-0.5, 3, 1],
				"cubes": [
					{"origin": [-8.5, -2, 1], "size": [8, 5, 0], "uv": [16, 22]}
				]
			}
		]
	}`
};
skin_presets.villager = {
	display_name: 'Villager (Old)',
	model: `{
		"name": "villager",
		"external_textures": ["entity/villager/villager.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "head",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "head", "origin": [-4, 24, -4], "size": [8, 10, 8], "uv": [0, 0]}
				]
			},
			{
				"name": "nose",
				"parent": "head",
				"pivot": [0, 26, 0],
				"cubes": [
					{"name": "nose", "origin": [-1, 23, -6], "size": [2, 4, 2], "uv": [24, 0]}
				]
			},
			{
				"name": "body",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-4, 12, -3], "size": [8, 12, 6], "uv": [16, 20]},
					{"name": "body", "origin": [-4, 6, -3], "size": [8, 18, 6], "uv": [0, 38], "inflate": 0.5}
				]
			},
			{
				"name": "arms",
				"pivot": [0, 22, 0],
				"rotation": [-45, 0, 0],
				"cubes": [
					{"name": "arms", "origin": [-4, 16, -2], "size": [8, 4, 4], "uv": [40, 38]},
					{"name": "arms", "origin": [-8, 16, -2], "size": [4, 8, 4], "uv": [44, 22]},
					{"name": "arms", "origin": [4, 16, -2], "size": [4, 8, 4], "uv": [44, 22]}
				]
			},
			{
				"name": "RightLeg",
				"pivot": [-2, 12, 0],
				"cubes": [
					{"name": "leg0", "origin": [-4, 0, -2], "size": [4, 12, 4], "uv": [0, 22]}
				]
			},
			{
				"name": "LeftLeg",
				"pivot": [2, 12, 0],
				"cubes": [
					{"name": "leg1", "origin": [0, 0, -2], "size": [4, 12, 4], "uv": [0, 22]}
				]
			}
		]
	}`
};
skin_presets.villager_v2 = {
	display_name: 'Villager (New)',
	model_java: `{
		"name": "villager_v2",
		"external_textures": ["entity/villager2/villager.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "body",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-4, 12, -3], "size": [8, 12, 6], "uv": [16, 20]},
					{"name": "body", "origin": [-4, 4, -3], "size": [8, 20, 6], "uv": [0, 38], "inflate": 0.5}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "head", "origin": [-4, 24, -4], "size": [8, 10, 8], "uv": [0, 0]}
				]
			},
			{
				"name": "helmet",
				"parent": "head",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "helmet", "origin": [-4, 24, -4], "size": [8, 10, 8], "uv": [32, 0], "inflate": 0.5}
				]
			},
			{
				"name": "brim",
				"parent": "head",
				"pivot": [0, 24, 0],
				"rotation": [-90, 0, 0],
				"cubes": [
					{"name": "brim", "origin": [-8, 16, -6], "size": [16, 16, 1], "uv": [30, 47], "inflate": 0.1}
				]
			},
			{
				"name": "nose",
				"parent": "head",
				"pivot": [0, 26, 0],
				"cubes": [
					{"name": "nose", "origin": [-1, 23, -6], "size": [2, 4, 2], "uv": [24, 0]}
				]
			},
			{
				"name": "arms",
				"parent": "body",
				"pivot": [0, 22, 0],
				"rotation": [-45, 0, 0],
				"cubes": [
					{"name": "arms", "origin": [-4, 16, -2], "size": [8, 4, 4], "uv": [40, 38]},
					{"name": "arms", "origin": [-8, 16, -2], "size": [4, 8, 4], "uv": [44, 22]},
					{"name": "arms", "origin": [4, 16, -2], "size": [4, 8, 4], "uv": [44, 22], "mirror": true}
				]
			},
			{
				"name": "RightLeg",
				"parent": "body",
				"pivot": [-2, 12, 0],
				"cubes": [
					{"name": "leg0", "origin": [-4, 0, -2], "size": [4, 12, 4], "uv": [0, 22]}
				]
			},
			{
				"name": "LeftLeg",
				"parent": "body",
				"pivot": [2, 12, 0],
				"cubes": [
					{"name": "leg1", "origin": [0, 0, -2], "size": [4, 12, 4], "uv": [0, 22], "mirror": true}
				]
			}
		]
	}`,
	model_bedrock: `{
		"name": "villager_v2",
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "body",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-4, 12, -3], "size": [8, 12, 6], "uv": [16, 20]},
					{"name": "body", "origin": [-4, 6, -3], "size": [8, 18, 6], "uv": [0, 38], "inflate": 0.5}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "head", "origin": [-4, 24, -4], "size": [8, 10, 8], "uv": [0, 0]}
				]
			},
			{
				"name": "helmet",
				"parent": "head",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "helmet", "origin": [-4, 24, -4], "size": [8, 10, 8], "uv": [32, 0], "inflate": 0.5}
				]
			},
			{
				"name": "brim",
				"parent": "head",
				"pivot": [0, 24, 0],
				"rotation": [-90, 0, 0],
				"cubes": [
					{"name": "brim", "origin": [-8, 16, -6], "size": [16, 16, 1], "uv": [30, 47], "inflate": 0.1}
				]
			},
			{
				"name": "nose",
				"parent": "head",
				"pivot": [0, 26, 0],
				"cubes": [
					{"name": "nose", "origin": [-1, 23, -6], "size": [2, 4, 2], "uv": [24, 0]}
				]
			},
			{
				"name": "arms",
				"parent": "body",
				"pivot": [0, 22, 0],
				"rotation": [-45, 0, 0],
				"cubes": [
					{"name": "arms", "origin": [-4, 16, -2], "size": [8, 4, 4], "uv": [40, 38]},
					{"name": "arms", "origin": [-8, 16, -2], "size": [4, 8, 4], "uv": [44, 22]},
					{"name": "arms", "origin": [4, 16, -2], "size": [4, 8, 4], "uv": [44, 22], "mirror": true}
				]
			},
			{
				"name": "RightLeg",
				"parent": "body",
				"pivot": [-2, 12, 0],
				"cubes": [
					{"name": "leg0", "origin": [-4, 0, -2], "size": [4, 12, 4], "uv": [0, 22]}
				]
			},
			{
				"name": "LeftLeg",
				"parent": "body",
				"pivot": [2, 12, 0],
				"cubes": [
					{"name": "leg1", "origin": [0, 0, -2], "size": [4, 12, 4], "uv": [0, 22], "mirror": true}
				]
			}
		]
	}`
};
skin_presets.villager_baby = {
	display_name: 'Villager Baby',
	model: `{
		"name": "villager_baby",
		"texturewidth": 64,
		"textureheight": 64,
		"external_textures": ["entity/villager2/villager_baby.png"],
		"eyes": [
			[8, 12, 2, 1],
			[12, 12, 2, 1]
		],
		"bones": [
			{
				"name": "body",
				"pivot": [1, 5.25, 0],
				"cubes": [
					{"origin": [-2, 3, -1.5], "size": [4, 5, 3], "uv": [0, 15]},
					{"origin": [-2, 2, -1.5], "size": [4, 6, 3], "inflate": 0.2, "uv": [16, 21]}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [1, 8, 0],
				"cubes": [
					{"origin": [-4, 8, -3.5], "size": [8, 8, 7], "uv": [0, 0]}
				]
			},
			{
				"name": "helmet",
				"parent": "head",
				"pivot": [1, 12, 0],
				"cubes": [
					{"origin": [-4, 8, -3.5], "size": [8, 8, 7], "inflate": 0.3, "uv": [0, 30], "layer": true, "visibility": false}
				]
			},
			{
				"name": "brim",
				"parent": "head",
				"pivot": [1, 12.5, 0],
				"cubes": [
					{"origin": [-7, 12, -6], "size": [14, 1, 12], "uv": [0, 45], "layer": true, "visibility": false}
				]
			},
			{
				"name": "nose",
				"parent": "head",
				"pivot": [1, 10, -4],
				"cubes": [
					{"origin": [-1, 8, -4.5], "size": [2, 2, 1], "uv": [23, 0]}
				]
			},
			{
				"name": "arms",
				"parent": "body",
				"pivot": [1, 5.9, -1.2],
				"cubes": [
					{"origin": [2, 3.59, -2.8], "size": [2, 4, 2], "pivot": [4, 5.09754, -0.95992], "rotation": [-60, 0, 0], "uv": [16, 15]},
					{"origin": [-4, 3.59, -2.8], "size": [2, 4, 2], "pivot": [-2, 5.09754, -0.95992], "rotation": [-60, 0, 0], "uv": [36, 15]}
				]
			},
			{
				"name": "held_item",
				"parent": "arms",
				"pivot": [1.5, 0, 0]
			},
			{
				"name": "leg0",
				"parent": "body",
				"pivot": [0, 2.5, 0],
				"cubes": [
					{"origin": [-2, 0, -1], "size": [2, 3, 2], "uv": [8, 23]}
				]
			},
			{
				"name": "leg1",
				"parent": "body",
				"pivot": [2, 2.5, 0],
				"cubes": [
					{"origin": [0, 0, -1], "size": [2, 3, 2], "uv": [0, 23]}
				]
			}
		]
	}`
};
skin_presets.vindicator = {
	display_name: 'Vindicator',
	model: `{
		"name": "vindicator",
		"external_textures": ["entity/vindicator.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "head",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "head", "origin": [-4, 24, -4], "size": [8, 10, 8], "uv": [0, 0]}
				]
			},
			{
				"name": "nose",
				"parent": "head",
				"pivot": [0, 26, 0],
				"cubes": [
					{"name": "nose", "origin": [-1, 23, -6], "size": [2, 4, 2], "uv": [24, 0]}
				]
			},
			{
				"name": "body",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "body", "origin": [-4, 12, -3], "size": [8, 12, 6], "uv": [16, 20]},
					{"name": "body", "origin": [-4, 6, -3], "size": [8, 18, 6], "uv": [0, 38], "inflate": 0.5}
				]
			},
			{
				"name": "arms",
				"pivot": [0, 22, 0],
				"rotation": [-45, 0, 0],
				"cubes": [
					{"name": "arms", "origin": [-8, 16, -2], "size": [4, 8, 4], "uv": [44, 22]},
					{"name": "arms", "origin": [4, 16, -2], "size": [4, 8, 4], "uv": [44, 22]},
					{"name": "arms", "origin": [-4, 16, -2], "size": [8, 4, 4], "uv": [40, 38]}
				]
			},
			{
				"name": "RightLeg",
				"pivot": [-2, 12, 0],
				"cubes": [
					{"name": "RightLeg", "origin": [-4, 0, -2], "size": [4, 12, 4], "uv": [0, 22]}
				]
			},
			{
				"name": "LeftLeg",
				"pivot": [2, 12, 0],
				"mirror": true,
				"cubes": [
					{"name": "LeftLeg", "origin": [0, 0, -2], "size": [4, 12, 4], "uv": [0, 22]}
				]
			},
			{
				"name": "RightArm",
				"pivot": [-5, 22, 0],
				"cubes": [
					{"name": "RightArm", "origin": [-8, 12, -2], "size": [4, 12, 4], "uv": [40, 46]}
				]
			},
			{
				"name": "LeftArm",
				"pivot": [5, 22, 0],
				"mirror": true,
				"cubes": [
					{"name": "LeftArm", "origin": [4, 12, -2], "size": [4, 12, 4], "uv": [40, 46]}
				]
			}
		]
	}`
};
skin_presets.warden = {
	display_name: 'Warden',
	model: `{
		"name": "warden",
		"external_textures": ["entity/warden/warden.png"],
		"texturewidth": 128,
		"textureheight": 128,
		"eyes": [
			[12, 50, 12, 7]
		],
		"bones": [
			{
				"name": "root",
				"pivot": [0, 0, 0]
			},
			{
				"name": "body",
				"parent": "root",
				"pivot": [0, 21, 0],
				"cubes": [
					{"origin": [-9, 13, -4], "size": [18, 21, 11], "uv": [0, 0]}
				]
			},
			{
				"name": "right_ribcage",
				"parent": "body",
				"pivot": [-7, 23, -4],
				"cubes": [
					{"origin": [-9, 13, -4.1], "size": [9, 21, 0], "uv": [90, 11]}
				]
			},
			{
				"name": "left_ribcage",
				"parent": "body",
				"pivot": [7, 23, -4],
				"cubes": [
					{"origin": [0, 13, -4.1], "size": [9, 21, 0], "uv": [90, 11], "mirror": true}
				]
			},
			{
				"name": "head",
				"parent": "body",
				"pivot": [0, 34, 0],
				"cubes": [
					{"origin": [-8, 34, -5], "size": [16, 16, 10], "uv": [0, 32]}
				]
			},
			{
				"name": "right_tendril",
				"parent": "head",
				"pivot": [-8, 46, 0],
				"cubes": [
					{"origin": [-24, 43, 0], "size": [16, 16, 0], "uv": [52, 32]}
				]
			},
			{
				"name": "left_tendril",
				"parent": "head",
				"pivot": [8, 46, 0],
				"cubes": [
					{"origin": [8, 43, 0], "size": [16, 16, 0], "uv": [58, 0]}
				]
			},
			{
				"name": "right_arm",
				"parent": "body",
				"pivot": [-13, 34, 1],
				"cubes": [
					{"origin": [-17, 6, -3], "size": [8, 28, 8], "uv": [44, 50]}
				]
			},
			{
				"name": "left_arm",
				"parent": "body",
				"pivot": [13, 34, 1],
				"cubes": [
					{"origin": [9, 6, -3], "size": [8, 28, 8], "uv": [0, 58]}
				]
			},
			{
				"name": "right_leg",
				"parent": "root",
				"pivot": [-5.9, 13, 0],
				"cubes": [
					{"origin": [-9, 0, -3], "size": [6, 13, 6], "uv": [76, 48]}
				]
			},
			{
				"name": "left_leg",
				"parent": "root",
				"pivot": [5.9, 13, 0],
				"cubes": [
					{"origin": [3, 0, -3], "size": [6, 13, 6], "uv": [76, 76]}
				]
			}
		]
	}`
}
skin_presets.witch = {
	display_name: 'Witch',
	model: `{
		"name": "witch",
		"external_textures": ["entity/witch.png"],
		"texturewidth": 64,
		"textureheight": 128,
		"bones": [
			{
				"name": "head",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "head", "origin": [-4, 24, -4], "size": [8, 10, 8], "uv": [0, 0]}
				]
			},
			{
				"name": "nose",
				"parent": "head",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "nose", "origin": [-1, 23, -6], "size": [2, 4, 2], "uv": [24, 0]},
					{"name": "nose", "origin": [0, 25, -6.75], "size": [1, 1, 1], "uv": [0, 0], "inflate": -0.25}
				]
			},
			{
				"name": "hat",
				"parent": "head",
				"pivot": [-5, 32.03125, -5],
				"cubes": [
					{"name": "hat", "origin": [-5, 32.05, -5], "size": [10, 2, 10], "uv": [0, 64]}
				]
			},
			{
				"name": "hat2",
				"parent": "hat",
				"pivot": [1.75, 32, 2],
				"rotation": [-3, 0, 1.5],
				"cubes": [
					{"name": "hat2", "origin": [-3.25, 33.5, -3], "size": [7, 4, 7], "uv": [0, 76]}
				]
			},
			{
				"name": "hat3",
				"parent": "hat2",
				"pivot": [1.75, 35, 2],
				"rotation": [-6, 0, 3],
				"cubes": [
					{"name": "hat3", "origin": [-1.5, 36.5, -1], "size": [4, 4, 4], "uv": [0, 87]}
				]
			},
			{
				"name": "hat4",
				"parent": "hat3",
				"pivot": [1.75, 38, 2],
				"rotation": [-12, 0, 6],
				"cubes": [
					{"name": "hat4", "origin": [0.25, 40, 1], "size": [1, 2, 1], "uv": [0, 95], "inflate": 0.25}
				]
			},
			{
				"name": "body",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-4, 12, -3], "size": [8, 12, 6], "uv": [16, 20]},
					{"name": "body", "origin": [-4, 6, -3], "size": [8, 18, 6], "uv": [0, 38], "inflate": 0.5}
				]
			},
			{
				"name": "arms",
				"pivot": [0, 22, 0],
				"rotation": [-45, 0, 0],
				"cubes": [
					{"name": "arms", "origin": [-4, 16, -2], "size": [8, 4, 4], "uv": [40, 38]},
					{"name": "arms", "origin": [-8, 16, -2], "size": [4, 8, 4], "uv": [44, 22]},
					{"name": "arms", "origin": [4, 16, -2], "size": [4, 8, 4], "uv": [44, 22]}
				]
			},
			{
				"name": "leg0",
				"pivot": [-2, 12, 0],
				"cubes": [
					{"name": "leg0", "origin": [-4, 0, -2], "size": [4, 12, 4], "uv": [0, 22]}
				]
			},
			{
				"name": "leg1",
				"pivot": [2, 12, 0],
				"cubes": [
					{"name": "leg1", "origin": [0, 0, -2], "size": [4, 12, 4], "uv": [0, 22]}
				]
			}
		]
	}`
};
skin_presets.witherBoss = {
	display_name: 'Wither',
	model: `{
		"name": "witherBoss",
		"external_textures": ["entity/wither_boss/wither.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "upperBodyPart1",
				"pivot": [0, 0, 0],
				"cubes": [
					{"name": "upperBodyPart1", "origin": [-10, 17.1, -0.5], "size": [20, 3, 3], "uv": [0, 16]}
				]
			},
			{
				"name": "upperBodyPart2",
				"parent": "upperBodyPart1",
				"pivot": [-2, 17.1, -0.5],
				"cubes": [
					{"name": "upperBodyPart2", "origin": [-2, 7.1, -0.5], "size": [3, 10, 3], "uv": [0, 22]},
					{"name": "upperBodyPart2", "origin": [-6, 13.6, 0], "size": [11, 2, 2], "uv": [24, 22]},
					{"name": "upperBodyPart2", "origin": [-6, 11.1, 0], "size": [11, 2, 2], "uv": [24, 22]},
					{"name": "upperBodyPart2", "origin": [-6, 8.6, 0], "size": [11, 2, 2], "uv": [24, 22]}
				]
			},
			{
				"name": "upperBodyPart3",
				"parent": "upperBodyPart2",
				"pivot": [0, 7, 0],
				"rotation": [45, 0, 0],
				"cubes": [
					{"name": "upperBodyPart3", "origin": [-2, 1, 0], "size": [3, 6, 3], "uv": [12, 22]}
				]
			},
			{
				"name": "head1",
				"parent": "upperBodyPart1",
				"pivot": [0, 20, 0],
				"cubes": [
					{"name": "head1", "origin": [-4, 20, -4], "size": [8, 8, 8], "uv": [0, 0]}
				]
			},
			{
				"name": "head2",
				"parent": "upperBodyPart1",
				"pivot": [-9, 18, -1],
				"cubes": [
					{"name": "head2", "origin": [-12, 18, -4], "size": [6, 6, 6], "uv": [32, 0]}
				]
			},
			{
				"name": "head3",
				"parent": "upperBodyPart1",
				"pivot": [9, 18, -1],
				"cubes": [
					{"name": "head3", "origin": [6, 18, -4], "size": [6, 6, 6], "uv": [32, 0]}
				]
			}
		]
	}`
};
skin_presets.wolf = {
	display_name: 'Wolf',
	model: `{
		"name": "wolf",
		"external_textures": ["entity/wolf/wolf.png"],
		"texturewidth": 64,
		"textureheight": 32,
		"bones": [
			{
				"name": "head",
				"pivot": [-1, 10.5, -7],
				"cubes": [
					{"name": "head", "origin": [-4, 7.5, -9], "size": [6, 6, 4], "uv": [0, 0]},
					{"name": "head", "origin": [-4, 13.5, -7], "size": [2, 2, 1], "uv": [16, 14]},
					{"name": "head", "origin": [0, 13.5, -7], "size": [2, 2, 1], "uv": [16, 14]},
					{"name": "head", "origin": [-2.5, 7.51563, -12], "size": [3, 3, 4], "uv": [0, 10]}
				]
			},
			{
				"name": "body",
				"pivot": [0, 10, 2],
				"rotation": [90, 0, 0],
				"cubes": [
					{"name": "body", "origin": [-4, 3, -1], "size": [6, 9, 6], "uv": [18, 14]}
				]
			},
			{
				"name": "upperBody",
				"pivot": [-1, 10, 2],
				"rotation": [90, 0, 0],
				"cubes": [
					{"name": "upperBody", "origin": [-5, 12, -1], "size": [8, 6, 7], "uv": [21, 0]}
				]
			},
			{
				"name": "leg0",
				"pivot": [-2.5, 8, 7],
				"cubes": [
					{"name": "leg0", "origin": [-3.5, 0, 6], "size": [2, 8, 2], "uv": [0, 18]}
				]
			},
			{
				"name": "leg1",
				"pivot": [0.5, 8, 7],
				"cubes": [
					{"name": "leg1", "origin": [-0.5, 0, 6], "size": [2, 8, 2], "uv": [0, 18]}
				]
			},
			{
				"name": "leg2",
				"pivot": [-2.5, 8, -4],
				"cubes": [
					{"name": "leg2", "origin": [-3.5, 0, -5], "size": [2, 8, 2], "uv": [0, 18]}
				]
			},
			{
				"name": "leg3",
				"pivot": [0.5, 8, -4],
				"cubes": [
					{"name": "leg3", "origin": [-0.5, 0, -5], "size": [2, 8, 2], "uv": [0, 18]}
				]
			},
			{
				"name": "tail",
				"pivot": [-1, 12, 8],
				"rotation": [55, 0, 0],
				"cubes": [
					{"name": "tail", "origin": [-2, 4, 7], "size": [2, 8, 2], "uv": [9, 18]}
				]
			}
		]
	}`
};
skin_presets.wolf_baby = {
	display_name: 'Wolf Baby',
	model: `{
		"name": "wolf_baby",
		"texturewidth": 32,
		"textureheight": 32,
		"external_textures": ["entity/wolf/wolf_baby.png"],
		"eyes": [
			[6, 19, 1, 1],
			[9, 19, 1, 1]
		],
		"bones": [
			{
				"name": "head",
				"pivot": [0, 5.75, -4],
				"cubes": [
					{"origin": [-2.99, 4, -7], "size": [6, 5, 5], "inflate": 0.025, "uv": [0, 12]},
					{"origin": [-1.5, 3.99, -9], "size": [3, 2, 2], "uv": [17, 12]}
				]
			},
			{
				"name": "right_ear",
				"parent": "head",
				"pivot": [-2, 10, -4.5],
				"cubes": [
					{"origin": [-3, 9, -5], "size": [2, 2, 1], "uv": [0, 5]}
				]
			},
			{
				"name": "left_ear",
				"parent": "head",
				"pivot": [2, 10, -4.5],
				"cubes": [
					{"origin": [1, 9, -5], "size": [2, 2, 1], "uv": [20, 5]}
				]
			},
			{
				"name": "body",
				"pivot": [0, 5, 0],
				"cubes": [
					{"origin": [-3, 3, -4], "size": [6, 4, 8], "uv": [0, 0]}
				]
			},
			{
				"name": "leg0",
				"pivot": [-1.5, 3, 3],
				"cubes": [
					{"origin": [-2.5, 0, 2], "size": [2, 3, 2], "uv": [0, 22]}
				]
			},
			{
				"name": "leg1",
				"pivot": [1.5, 3, 3],
				"cubes": [
					{"origin": [0.5, 0, 2], "size": [2, 3, 2], "uv": [8, 22]}
				]
			},
			{
				"name": "leg2",
				"pivot": [-1.5, 3, -3],
				"cubes": [
					{"origin": [-2.5, 0, -4], "size": [2, 3, 2], "uv": [0, 0]}
				]
			},
			{
				"name": "leg3",
				"pivot": [1.5, 3, -3],
				"cubes": [
					{"origin": [0.5, 0, -4], "size": [2, 3, 2], "uv": [20, 0]}
				]
			},
			{
				"name": "tail",
				"pivot": [0, 5, 3],
				"rotation": [75, 0, 0],
				"cubes": [
					{"origin": [-1, 5.3, 2.2], "size": [2, 6, 2], "pivot": [0, 5.6, 3.2], "rotation": [180, 0, 0], "uv": [22, 16]}
				]
			}
		]
	}`
};
skin_presets.zombie = {
	display_name: 'Zombie',
	pose: true,
	model_java: `{
		"name": "zombie",
		"texturewidth": 64,
		"textureheight": 64,
		"eyes": [
			[9, 12, 2, 1],
			[13, 12, 2, 1]
		],
		"bones": [
			{
				"name": "Body",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "Body", "origin": [-4, 12, -2], "size": [8, 12, 4], "uv": [16, 16]}
				]
			},
			{
				"name": "Head",
				"pivot": [0, 24, 0],
				"pose": [3, -10, 0],
				"cubes": [
					{"name": "Head", "origin": [-4, 24, -4], "size": [8, 8, 8], "uv": [0, 0]},
					{"name": "Hat Layer", "visibility": false, "origin": [-4, 24, -4], "size": [8, 8, 8], "uv": [32, 0], "inflate": 0.5}
				]
			},
			{
				"name": "RightArm",
				"pivot": [-5, 22, 0],
				"pose": [-80, -5, 0],
				"cubes": [
					{"name": "RightArm", "origin": [-8, 12, -2], "size": [4, 12, 4], "uv": [40, 16]}
				]
			},
			{
				"name": "LeftArm",
				"pivot": [5, 22, 0],
				"pose": [-75, 5, 0],
				"mirror": true,
				"cubes": [
					{"name": "LeftArm", "origin": [4, 12, -2], "size": [4, 12, 4], "uv": [40, 16]}
				]
			},
			{
				"name": "RightLeg",
				"pivot": [-1.9, 12, 0],
				"pose": [-25, 0, 5],
				"cubes": [
					{"name": "RightLeg", "origin": [-3.9, 0, -2], "size": [4, 12, 4], "uv": [0, 16]}
				]
			},
			{
				"name": "LeftLeg",
				"pivot": [1.9, 12, 0],
				"pose": [20, 0, 0],
				"mirror": true,
				"cubes": [
					{"name": "LeftLeg", "origin": [-0.1, 0, -2], "size": [4, 12, 4], "uv": [0, 16]}
				]
			}
		]
	}`,
	model_bedrock: `{
		"name": "zombie",
		"external_textures": ["entity/zombie/zombie.png"],
		"texturewidth": 64,
		"textureheight": 32,
		"eyes": [
			[9, 12, 2, 1],
			[13, 12, 2, 1]
		],
		"bones": [
			{
				"name": "Body",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "Body", "origin": [-4, 12, -2], "size": [8, 12, 4], "uv": [16, 16]}
				]
			},
			{
				"name": "Head",
				"pivot": [0, 24, 0],
				"pose": [3, -10, 0],
				"cubes": [
					{"name": "Head", "origin": [-4, 24, -4], "size": [8, 8, 8], "uv": [0, 0]},
					{"name": "Hat Layer", "visibility": false, "origin": [-4, 24, -4], "size": [8, 8, 8], "uv": [32, 0], "inflate": 0.5}
				]
			},
			{
				"name": "RightArm",
				"pivot": [-5, 22, 0],
				"pose": [-80, -5, 0],
				"cubes": [
					{"name": "RightArm", "origin": [-8, 12, -2], "size": [4, 12, 4], "uv": [40, 16]}
				]
			},
			{
				"name": "LeftArm",
				"pivot": [5, 22, 0],
				"pose": [-75, 5, 0],
				"mirror": true,
				"cubes": [
					{"name": "LeftArm", "origin": [4, 12, -2], "size": [4, 12, 4], "uv": [40, 16]}
				]
			},
			{
				"name": "RightLeg",
				"pivot": [-1.9, 12, 0],
				"pose": [-25, 0, 5],
				"cubes": [
					{"name": "RightLeg", "origin": [-3.9, 0, -2], "size": [4, 12, 4], "uv": [0, 16]}
				]
			},
			{
				"name": "LeftLeg",
				"pivot": [1.9, 12, 0],
				"pose": [20, 0, 0],
				"mirror": true,
				"cubes": [
					{"name": "LeftLeg", "origin": [-0.1, 0, -2], "size": [4, 12, 4], "uv": [0, 16]}
				]
			}
		]
	}`
};
skin_presets.zombie_baby = {
	display_name: 'Zombie Baby',
	pose: true,
	model: `{
		"name": "zombie_baby",
		"texturewidth": 64,
		"textureheight": 64,
		"external_textures": ["entity/zombie/zombie_baby.png"],
		"eyes": [
			[9, 12, 2, 1],
			[13, 12, 2, 1]
		],
		"bones": [
			{
				"name": "Body",
				"pivot": [0, 6.5, 0],
				"cubes": [
					{"origin": [-2, 4, -1], "size": [4, 5, 2], "uv": [16, 16]}
				]
			},
			{
				"name": "Head",
				"parent": "Body",
				"pivot": [0, 8.75, 0],
				"cubes": [
					{"origin": [-3, 9, -3], "size": [6, 6, 6], "uv": [3, 3]},
					{"origin": [-3, 8.9, -3], "size": [6, 6, 6], "inflate": 0.25, "uv": [35, 3], "layer": true, "visibility": false}
				]
			},
			{
				"name": "RightArm",
				"parent": "Body",
				"pivot": [-3, 8.5, 0],
				"pose": [-80, -5, 0],
				"cubes": [
					{"origin": [-4, 4, -1], "size": [2, 5, 2], "uv": [36, 16]}
				]
			},
			{
				"name": "LeftArm",
				"parent": "Body",
				"pivot": [3, 8.5, 0],
				"pose": [-75, 5, 0],
				"cubes": [
					{"origin": [2, 4, -1], "size": [2, 5, 2], "uv": [28, 16]}
				]
			},
			{
				"name": "RightLeg",
				"parent": "Body",
				"pivot": [-1, 4, 0],
				"cubes": [
					{"origin": [-2, 0, -1], "size": [2, 4, 2], "uv": [8, 16]}
				]
			},
			{
				"name": "LeftLeg",
				"parent": "Body",
				"pivot": [1, 4, 0],
				"cubes": [
					{"origin": [0, 0, -1], "size": [2, 4, 2], "uv": [0, 16]}
				]
			}
		]
	}`
};
skin_presets.zombie_villager_1 = {
	display_name: 'Zombie Villager (Old)',
	model: `{
		"name": "zombie_villager_1",
		"external_textures": ["entity/zombie_villager/zombie_villager.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "Head",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "head", "origin": [-4, 24, -4], "size": [8, 10, 8], "uv": [0, 0], "inflate": 0.25},
					{"name": "head", "origin": [-1, 23, -6], "size": [2, 4, 2], "uv": [24, 0], "inflate": 0.25}
				]
			},
			{
				"name": "Body",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "Body", "origin": [-4, 12, -3], "size": [8, 12, 6], "uv": [16, 20]},
					{"name": "Body", "origin": [-4, 6, -3], "size": [8, 18, 6], "uv": [0, 38], "inflate": 0.5}
				]
			},
			{
				"name": "waist",
				"pivot": [0, 12, 0]
			},
			{
				"name": "RightArm",
				"pivot": [-5, 22, 0],
				"cubes": [
					{"name": "RightArm", "origin": [-8, 12, -2], "size": [4, 12, 4], "uv": [44, 38]}
				]
			},
			{
				"name": "LeftArm",
				"pivot": [5, 22, 0],
				"mirror": true,
				"cubes": [
					{"name": "LeftArm", "origin": [4, 12, -2], "size": [4, 12, 4], "uv": [44, 38]}
				]
			},
			{
				"name": "RightLeg",
				"pivot": [-2, 12, 0],
				"cubes": [
					{"name": "RightLeg", "origin": [-4, 0, -2], "size": [4, 12, 4], "uv": [0, 22]}
				]
			},
			{
				"name": "LeftLeg",
				"pivot": [2, 12, 0],
				"mirror": true,
				"cubes": [
					{"name": "LeftLeg", "origin": [0, 0, -2], "size": [4, 12, 4], "uv": [0, 22]}
				]
			}
		]
	}`
};
skin_presets.zombie_villager_2 = {
	display_name: 'Zombie Villager (New)',
	model_java: `{
		"name": "zombie_villager_2",
		"external_textures": ["entity/zombie_villager2/zombie-villager.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "waist",
				"pivot": [0, 12, 0]
			},
			{
				"name": "Body",
				"parent": "waist",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "Body", "origin": [-4, 12, -3], "size": [8, 12, 6], "uv": [16, 20]},
					{"name": "Body", "origin": [-4, 4, -3], "size": [8, 20, 6], "uv": [0, 38], "inflate": 0.5}
				]
			},
			{
				"name": "Head",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "Head", "origin": [-4, 24, -4], "size": [8, 10, 8], "uv": [0, 0], "inflate": 0.25},
					{"name": "Head", "origin": [-1, 23, -6], "size": [2, 4, 2], "uv": [24, 0], "inflate": 0.25}
				]
			},
			{
				"name": "helmet",
				"parent": "Head",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "Head Layer", "origin": [-4, 24, -4], "size": [8, 10, 8], "uv": [32, 0], "inflate": 0.5}
				]
			},
			{
				"name": "brim",
				"parent": "Head",
				"pivot": [0, 24, 0],
				"rotation": [-90, 0, 0],
				"cubes": [
					{"name": "brim", "origin": [-8, 16, -6], "size": [16, 16, 1], "uv": [30, 47], "inflate": 0.1}
				]
			},
			{
				"name": "RightArm",
				"pivot": [-5, 22, 0],
				"cubes": [
					{"name": "RightArm", "origin": [-8, 12, -2], "size": [4, 12, 4], "uv": [44, 22]}
				]
			},
			{
				"name": "LeftArm",
				"pivot": [5, 22, 0],
				"mirror": true,
				"cubes": [
					{"name": "LeftArm", "origin": [4, 12, -2], "size": [4, 12, 4], "uv": [44, 22]}
				]
			},
			{
				"name": "RightLeg",
				"pivot": [-2, 12, 0],
				"cubes": [
					{"name": "RightLeg", "origin": [-4, 0, -2], "size": [4, 12, 4], "uv": [0, 22]}
				]
			},
			{
				"name": "LeftLeg",
				"pivot": [2, 12, 0],
				"mirror": true,
				"cubes": [
					{"name": "LeftLeg", "origin": [0, 0, -2], "size": [4, 12, 4], "uv": [0, 22]}
				]
			}
		]
	}`,
	model_bedrock: `{
		"name": "zombie_villager_2",
		"external_textures": ["entity/zombie_villager2/zombie-villager.png"],
		"texturewidth": 64,
		"textureheight": 64,
		"bones": [
			{
				"name": "waist",
				"pivot": [0, 12, 0]
			},
			{
				"name": "Body",
				"parent": "waist",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "Body", "origin": [-4, 12, -3], "size": [8, 12, 6], "uv": [16, 20]},
					{"name": "Body", "origin": [-4, 6, -3], "size": [8, 18, 6], "uv": [0, 38], "inflate": 0.5}
				]
			},
			{
				"name": "Head",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "Head", "origin": [-4, 24, -4], "size": [8, 10, 8], "uv": [0, 0], "inflate": 0.25},
					{"name": "Head", "origin": [-1, 23, -6], "size": [2, 4, 2], "uv": [24, 0], "inflate": 0.25}
				]
			},
			{
				"name": "helmet",
				"parent": "Head",
				"pivot": [0, 24, 0],
				"cubes": [
					{"name": "Head Layer", "origin": [-4, 24, -4], "size": [8, 10, 8], "uv": [32, 0], "inflate": 0.5}
				]
			},
			{
				"name": "brim",
				"parent": "Head",
				"pivot": [0, 24, 0],
				"rotation": [-90, 0, 0],
				"cubes": [
					{"name": "brim", "origin": [-8, 16, -6], "size": [16, 16, 1], "uv": [30, 47], "inflate": 0.1}
				]
			},
			{
				"name": "RightArm",
				"pivot": [-5, 22, 0],
				"cubes": [
					{"name": "RightArm", "origin": [-8, 12, -2], "size": [4, 12, 4], "uv": [44, 22]}
				]
			},
			{
				"name": "LeftArm",
				"pivot": [5, 22, 0],
				"mirror": true,
				"cubes": [
					{"name": "LeftArm", "origin": [4, 12, -2], "size": [4, 12, 4], "uv": [44, 22]}
				]
			},
			{
				"name": "RightLeg",
				"pivot": [-2, 12, 0],
				"cubes": [
					{"name": "RightLeg", "origin": [-4, 0, -2], "size": [4, 12, 4], "uv": [0, 22]}
				]
			},
			{
				"name": "LeftLeg",
				"pivot": [2, 12, 0],
				"mirror": true,
				"cubes": [
					{"name": "LeftLeg", "origin": [0, 0, -2], "size": [4, 12, 4], "uv": [0, 22]}
				]
			}
		]
	}`
};
skin_presets.zombie_villager_baby = {
	display_name: 'Zombie Villager Baby',
	model: `{
		"name": "zombie_villager_baby",
		"texturewidth": 64,
		"textureheight": 64,
		"external_textures": ["entity/zombie_villager2/zombie-villager_baby.png"],
		"eyes": [
			[8, 12, 2, 1],
			[12, 12, 2, 1]
		],
		"bones": [
			{
				"name": "Body",
				"pivot": [-0.5, 5.25, 0],
				"cubes": [
					{"origin": [-2.5, 3, -1.5], "size": [4, 5, 3], "uv": [0, 15]},
					{"origin": [-2.5, 2, -1.5], "size": [4, 6, 3], "inflate": 0.2, "uv": [16, 22]}
				]
			},
			{
				"name": "Head",
				"parent": "Body",
				"pivot": [-0.5, 8, 0],
				"cubes": [
					{"origin": [-4.5, 8, -3.5], "size": [8, 8, 7], "uv": [0, 0]}
				]
			},
			{
				"name": "helmet",
				"parent": "Head",
				"pivot": [-0.5, 12, 0],
				"cubes": [
					{"origin": [-4.5, 8, -3.5], "size": [8, 8, 7], "inflate": 0.3, "uv": [0, 31], "layer": true, "visibility": false}
				]
			},
			{
				"name": "brim",
				"parent": "Head",
				"pivot": [-0.5, 12.5, 0],
				"cubes": [
					{"origin": [-7.5, 12, -6], "size": [14, 1, 12], "uv": [0, 46], "layer": true, "visibility": false}
				]
			},
			{
				"name": "Nose",
				"parent": "Head",
				"pivot": [-0.5, 9, -4],
				"cubes": [
					{"origin": [-1.5, 8, -4.5], "size": [2, 2, 1], "uv": [23, 0]}
				]
			},
			{
				"name": "RightArm",
				"parent": "Body",
				"pivot": [-3, 6.75, 0],
				"cubes": [
					{"origin": [-4.5, 2.75, -1], "size": [2, 5, 2], "uv": [24, 15]}
				]
			},
			{
				"name": "LeftArm",
				"parent": "Body",
				"pivot": [2, 6.75, 0],
				"cubes": [
					{"origin": [1.5, 2.75, -1], "size": [2, 5, 2], "uv": [16, 15]}
				]
			},
			{
				"name": "RightLeg",
				"parent": "Body",
				"pivot": [-1.5, 2.5, 0],
				"cubes": [
					{"origin": [-2.5, 0, -1], "size": [2, 3, 2], "uv": [8, 23]}
				]
			},
			{
				"name": "LeftLeg",
				"parent": "Body",
				"pivot": [0.5, 2.5, 0],
				"cubes": [
					{"origin": [-0.5, 0, -1], "size": [2, 3, 2], "uv": [0, 23]}
				]
			}
		]
	}`
};

for (let id in skin_presets) {
	model_options[id] = skin_presets[id].display_name;
}
