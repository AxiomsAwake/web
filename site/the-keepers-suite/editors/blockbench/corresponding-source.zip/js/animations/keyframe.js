import { markerColors } from "../marker_colors";
import { clipboard } from "../native_apis";
import { invertMolang, processMolangReturn } from "../util/molang";
import { openMolangEditor } from "./molang_editor";

export class KeyframeDataPoint {
	constructor(keyframe) {
		this.keyframe = keyframe;
		for (var key in KeyframeDataPoint.properties) {
			KeyframeDataPoint.properties[key].reset(this);
		}
	}
	extend(data) {
		if (data.values) {
			Object.assign(data, data.values)
		}
		let file_value_before = this.file;
		for (var key in KeyframeDataPoint.properties) {
			KeyframeDataPoint.properties[key].merge(this, data)
		}
		if (isApp && data.file && !PathModule.isAbsolute(data.file)) {
			this.file = PathModule.resolve(PathModule.dirname(Project.save_path), data.file);
		}
		if (isApp && data.file && !file_value_before) {
			if (this.keyframe.channel == 'sound' && !Timeline.waveforms[this.file]) {
				Timeline.visualizeAudioFile(this.file);
			} else if (this.keyframe.channel == 'particle') {
				try {
					Blockbench.read([this.file], {}, (files) => {
						Animator.loadParticleEmitter(this.file, files[0].content);
					})
				} catch (err) {
					console.log('Could not load particle effect for', this.file)
				}
			}
		}
	}
	getUndoCopy() {
		let copy = {}
		for (let key in KeyframeDataPoint.properties) {
			KeyframeDataPoint.properties[key].copy(this, copy)
		}
		return copy;
	}
}
new Property(KeyframeDataPoint, 'molang', 'x', { label: 'X', condition: point => point.keyframe.transform, default: point => (point && point.keyframe.channel == 'scale' ? '1' : '0') });
new Property(KeyframeDataPoint, 'molang', 'y', { label: 'Y', condition: point => point.keyframe.transform, default: point => (point && point.keyframe.channel == 'scale' ? '1' : '0') });
new Property(KeyframeDataPoint, 'molang', 'z', { label: 'Z', condition: point => point.keyframe.transform, default: point => (point && point.keyframe.channel == 'scale' ? '1' : '0') });
new Property(KeyframeDataPoint, 'string', 'effect', {label: tl('data.effect'), condition: point => ['particle', 'sound'].includes(point.keyframe.channel)});
new Property(KeyframeDataPoint, 'string', 'locator',{label: tl('data.locator'), condition: point => ['particle', 'sound'].includes(point.keyframe.channel)});
new Property(KeyframeDataPoint, 'molang', 'script', {label: tl('timeline.pre_effect_script'), condition: point => ['particle', 'timeline'].includes(point.keyframe.channel), default: ''});
new Property(KeyframeDataPoint, 'string', 'file', 	{exposed: false, condition: point => ['particle', 'sound'].includes(point.keyframe.channel)});
new Property(KeyframeDataPoint, 'boolean', 'bind_to_actor', {exposed: false, default: true, condition: point => ['particle'].includes(point.keyframe.channel)});

export class Keyframe {
	constructor(data, uuid, animator) {
		this.type = 'keyframe'
		this.uuid = (uuid && isUUID(uuid)) ? uuid : guid();
		this.time = 0;
		this.channel = 'rotation'
		this.selected = false;
		this.has_expressions = false;
		this.display_value = 0;
		this.data_points = []

		if (typeof data === 'object') {
			Merge.string(this, data, 'channel')
			this.animator = animator;
			this.transform = !!(this.animator.channels[this.channel]).transform;
			this.data_points.push(new KeyframeDataPoint(this));
		}

		for (var key in Keyframe.properties) {
			Keyframe.properties[key].reset(this);
		}

		if (typeof data === 'object') {
			this.extend(data)
		}
	}
	extend(data) {
		for (var key in Keyframe.properties) {
			Keyframe.properties[key].merge(this, data)
		}
		if (data.data_points && data.data_points.length) {
			this.data_points.splice(data.data_points.length);
			data.data_points.forEach((point, i) => {
				if (!this.data_points[i]) {
					this.data_points.push(new KeyframeDataPoint(this));
				}
				let this_point = this.data_points[i];
				this_point.extend(point)
			})
		} else {
			// Direct extending
			for (var key in KeyframeDataPoint.properties) {
				KeyframeDataPoint.properties[key].merge(this.data_points[0], data)
			}
		}
		if (this.channel == 'scale' && this.uniform &&
			this.data_points.some(d => (d.x != d.y || d.x != d.z))
		) {
			this.uniform = false;
		}
		return this;
	}
	get(axis, data_point = 0) {
		if (data_point) data_point = Math.clamp(data_point, 0, this.data_points.length-1);
		data_point = this.data_points[data_point];
		if (!data_point || !data_point[axis]) {
			return this.transform ? 0 : '';
		} else {
			return exportMolang(data_point[axis])
		}
	}
	calc(axis, data_point = 0) {
		if (data_point) data_point = Math.clamp(data_point, 0, this.data_points.length-1);
		data_point = this.data_points[data_point];
		let last_value = Animator._last_values[this.channel]?.[getAxisNumber(axis)];
		let result = Animator.MolangParser.parse(data_point?.[axis], {
			'this': last_value,
			'query.anim_time': this.animator.animation.time
		});
		return result;
	}
	set(axis, value, data_point = 0) {
		if (data_point) data_point = Math.clamp(data_point, 0, this.data_points.length-1);
		if (typeof value == 'number') value = Math.roundTo(value, 10).toString();
		if (this.data_points[data_point]) {
			if (this.uniform) {
				this.data_points[data_point].x = value;
				this.data_points[data_point].y = value;
				this.data_points[data_point].z = value;
			} else {
				this.data_points[data_point][axis] = value;
			}
		}
		return this;
	}
	offset(axis, amount, data_point = 0) {
		if (data_point) data_point = Math.clamp(data_point, 0, this.data_points.length-1);
		var value = this.get(axis, data_point);
		if (!value || value === '0') {
			this.set(axis, amount, data_point);
			return amount;
		}
		if (typeof value === 'number') {
			this.set(axis, value+amount, data_point);
			return value+amount
		}

		value = processMolangReturn(value, (expression) => {
			let value = exportMolang(expression);
			if (!value || value === '0') {
				return amount;
			}
			if (typeof value === 'number') {
				return value+amount
			}
			var start = value.match(/^-?\s*\d+(\.\d+)?\s*(\+|-)/)
			if (start) {
				var number = parseFloat( start[0].substr(0, start[0].length-1) ) + amount;
				if (number == 0) {
					value = value.substr(start[0].length + (value[start[0].length-1] == '+' ? 0 : -1));
					value = value.trim();
				} else {
					value = trimFloatNumber(number) + (start[0].substr(-2, 1) == ' ' ? ' ' : '') + value.substr(start[0].length-1);
				}
			} else {

				var end = value.match(/(\+|-)\s*\d*(\.\d+)?\s*$/)
				if (end) {
					var number = (parseFloat( end[0] ) + amount)
					value = value.substr(0, end.index) + ((number.toString()).substr(0,1)=='-'?'':'+') + trimFloatNumber(number)
				} else {
					value = trimFloatNumber(amount) +(value.substr(0,1)=='-'?'':'+')+ value
				}
			}
			value = value.replace(/^(0\s*\+)/, '').replace(/^0\s*-/, '-');
			return value;
		});

		this.set(axis, value, data_point)
		return value;
	}
	flip(axis) {
		if (!this.transform || this.channel == 'scale') return this;

		this.data_points.forEach((data_point, data_point_i) => {
			if (this.channel == 'rotation') {
				for (var i = 0; i < 3; i++) {
					if (i != axis) {
						let l = getAxisLetter(i)
						this.set(l, invertMolang(this.get(l, data_point_i)), data_point_i)
					}
				}
			} else if (this.channel == 'position') {
				let l = getAxisLetter(axis)
				this.set(l, invertMolang(this.get(l, data_point_i)), data_point_i)
			}
		})
		if (this.interpolation == 'bezier') {
			if (this.channel == 'rotation') {
				for (var i = 0; i < 3; i++) {
					if (i != axis) {
						this.bezier_left_value[i] *= -1;
						this.bezier_right_value[i] *= -1;
					}
				}
			} else if (this.channel == 'position') {
				this.bezier_left_value[axis] *= -1;
				this.bezier_right_value[axis] *= -1;
			}
		}
		return this;
	}
	getLerp(other, axis, amount, allow_expression) {
		let this_data_point = (this.data_points.length > 1 && this.time < other.time) ? 1 : 0;
		let other_data_point = (other.data_points.length > 1 && this.time > other.time) ? 1 : 0;
		if (allow_expression && this.get(axis, this_data_point) === other.get(axis, other_data_point)) {
			return this.get(axis, this_data_point);
		} else {
			let calc = this.calc(axis, this_data_point);
			return calc + (other.calc(axis, other_data_point) - calc) * amount;
		}
	}
	getCatmullromLerp(before_plus, before, after, after_plus, axis, alpha) {
		var vectors = [];

		if (before_plus && before.data_points.length == 1) vectors.push(new THREE.Vector2(before_plus.time, before_plus.calc(axis, 1)))
		if (before) 	vectors.push(new THREE.Vector2(before.time, before.calc(axis, 1)))
		if (after) 		vectors.push(new THREE.Vector2(after.time, after.calc(axis, 0)))
		if (after_plus && after.data_points.length == 1) vectors.push(new THREE.Vector2(after_plus.time, after_plus.calc(axis, 0)))

		var curve = new THREE.SplineCurve(vectors);
		let time = (alpha + (before_plus ? 1 : 0)) / (vectors.length-1);

		return curve.getPoint(time).y;
	}
	getBezierLerp(before, after, axis, alpha) {
		let axis_num = getAxisNumber(axis);
		let val_before = before.calc(axis, 1);
		let val_after = after.calc(axis, 0);
		let time_gap = after.time - before.time;
		let time_handle_before = Math.clamp(before.bezier_right_time[axis_num] || 0, 0, time_gap);
		let time_handle_after  = Math.clamp(after.bezier_left_time[axis_num]   || 0, -time_gap, 0);
		let vectors = [
			new THREE.Vector2(before.time, val_before),

			new THREE.Vector2(before.time + time_handle_before, val_before + before.bezier_right_value[axis_num] || 0),
			new THREE.Vector2(after.time  + time_handle_after,  val_after  + after.bezier_left_value[axis_num]   || 0),

			new THREE.Vector2(after.time, val_after),
		];

		let curve = new THREE.CubicBezierCurve(...vectors);
		let time = before.time + (after.time - before.time) * alpha;

		let points = curve.getPoints(200);
		let closest;
		let closest_diff = Infinity;
		points.forEach(point => {
			let diff = Math.abs(point.x - time);
			if (diff < closest_diff) {
				closest_diff = diff;
				closest = point;
			}
		})
		let second_closest;
		closest_diff = Infinity;
		points.forEach(point => {
			if (point == closest) return;
			let diff = Math.abs(point.x - time);
			if (diff < closest_diff) {
				closest_diff = diff;
				second_closest = closest;
				second_closest = point;
			}
		})
		return Math.lerp(closest.y, second_closest.y, Math.clamp(Math.getLerp(closest.x, second_closest.x, time), 0, 1));
	}
	getArray(data_point = 0) {
		var arr = [
			this.get('x', data_point),
			this.get('y', data_point),
			this.get('z', data_point),
		]
		arr.forEach((n, i) => {
			if (n.replace) arr[i] = n.replace(/\n/g, '');
		})
		return arr;
	}
	getFixed(data_point = 0, return_quaternion = true) {
		if (this.channel === 'rotation') {
			
			let fix = this.animator.group.mesh.fix_rotation;
			let use_quaternions = Format.per_animator_rotation_interpolation ? this.quaternion_interpolation : Format.quaternion_interpolation;
			if (use_quaternions) {
				let euler = new THREE.Euler(
					Math.degToRad(this.calc('x', data_point)),
					Math.degToRad(this.calc('y', data_point)),
					Math.degToRad(this.calc('z', data_point)),
					Format.euler_order
				);
				let quat = new THREE.Quaternion().setFromEuler(fix);
				quat.multiply(Reusable.quat2.setFromEuler(euler));
				return return_quaternion ? quat : euler.setFromQuaternion(quat);
			} else {
				let euler = new THREE.Euler(
					(fix.x||0) + Math.degToRad(this.calc('x', data_point)),
					(fix.y||0) + Math.degToRad(this.calc('y', data_point)),
					(fix.z||0) + Math.degToRad(this.calc('z', data_point)),
					Format.euler_order
				)
				return return_quaternion ? new THREE.Quaternion().setFromEuler(euler) : euler;
			}
		} else if (this.channel === 'position') {
			let fix = this.animator.group.mesh.fix_position;
			return new THREE.Vector3(
				fix.x + this.calc('x', data_point),
				fix.y + this.calc('y', data_point),
				fix.z + this.calc('z', data_point)
			)
		} else if (this.channel === 'scale') {
			return new THREE.Vector3(
				this.calc('x', data_point),
				this.calc('y', data_point),
				this.calc('z', data_point)
			)
		}
	}
	getTimecodeString() {
		let timecode = trimFloatNumber(Timeline.snapTime(this.time, this.animator.animation)).toString();
		if (!timecode.includes('.')) {
			timecode += '.0';
		}
		return timecode;
	}
	getPreviousKeyframe() {
		let keyframes = this.animator[this.channel].filter(kf => kf.time < this.time);
		keyframes.sort((a, b) => b.time - a.time);
		return keyframes[0];
	}
	compileBedrockKeyframe() {
		if (this.transform) {
			let flipArray = array => {
				if (this.channel == 'position') {
					array[0] = invertMolang(array[0]);
				}
				if (this.channel == 'rotation') {
					array[0] = invertMolang(array[0]);
					array[1] = invertMolang(array[1]);
				}
				return array;
			}
			if (this.interpolation == 'catmullrom') {
				let previous = this.getPreviousKeyframe();
				let include_pre = (!previous && this.time > 0) || (previous && previous.interpolation != 'catmullrom')
				return {
					pre: include_pre ? flipArray(this.getArray(0)) : undefined,
					post: flipArray(this.getArray(include_pre ? 1 : 0)),
					lerp_mode: this.interpolation,
				}
			} else if (this.data_points.length == 1) {
				let previous = this.getPreviousKeyframe();
				if (previous && previous.interpolation == 'step') {
					return new oneLiner({
						pre:  flipArray(previous.getArray(1)),
						post: flipArray(this.getArray()),
					})
				} else {
					return flipArray(this.getArray());
				}
			} else {
				return new oneLiner({
					pre:  flipArray(this.getArray(0)),
					post: flipArray(this.getArray(1)),
				})
			}
		} else if (this.channel == 'timeline') {
			let scripts = [];
			this.data_points.forEach(data_point => {
				if (data_point.script) {
					scripts.push(...data_point.script.split('\n'));
				}
			})
			scripts = scripts.filter(script => !!script.replace(/[\n\s;.]+/g, ''));
			scripts = scripts.map(line => (line.match(/;\s*$/) || line.startsWith('/')) ? line : (line+';'));
			return scripts.length <= 1 ? scripts[0] : scripts;
		} else {
			let points = [];
			this.data_points.forEach(data_point => {
				if (data_point.effect) {
					let script = data_point.script || undefined;
					if (script && !script.replace(/[\n\s;.]+/g, '')) script = undefined;
					if (script && !script.match(/;$/)) script += ';';
					points.push({
						effect: data_point.effect,
						locator: data_point.locator || undefined,
						bind_to_actor: data_point.bind_to_actor == false ? false : undefined,
						pre_effect_script: script,
					})
				}
			})
			return points.length <= 1 ? points[0] : points;
		}
	}
	replaceOthers(save_array) {
		let all = this.animator[this.channel].slice();
		all.forEach(kf => {
			if (kf != this && Math.abs(kf.time - this.time) < 0.0001) {
				save_array.push(kf);
				kf.remove();
			}
		})
	}
	select(event) {
		if (Timeline.dragging_keyframes) {
			Timeline.dragging_keyframes = false
			return this;
		}
		if (!event || (!event.shiftKey && !event.ctrlOrCmd && !Pressing.overrides.ctrl && !Pressing.overrides.shift)) {
			Timeline.selected.forEach(function(kf) {
				kf.selected = false
			})
			Timeline.selected.empty()
		}
		if (event && (event.shiftKey || Pressing.overrides.shift) && Timeline.selected.length) {
			var last = Timeline.selected[Timeline.selected.length-1]
			if (last && last.channel === this.channel && last.animator == this.animator) {
				Timeline.keyframes.forEach((kf) => {
					if (kf.channel === this.channel &&
						kf.animator === this.animator &&
						Math.isBetween(kf.time, last.time, this.time) &&
						!kf.selected
					) {
						kf.selected = true
						Timeline.selected.push(kf)
					}
				})
			} else if (last && Math.epsilon(this.time, last.time, 0.01)) {
				let animators = Timeline.animators;
				let vertical_index_last = animators.indexOf(last.animator);
				let vertical_index_this = animators.indexOf(this.animator);
				let sign = Math.sign(vertical_index_this - vertical_index_last);
				if (sign == 0) {
					let channels = Object.keys(this.animator.channels);
					sign = this.channel == channels[0] ? -1 : 1;
				}

				let active = false;
				for (let i = vertical_index_last; (sign == 1 ? (i <= vertical_index_this) : (i >= vertical_index_this)) && animators[i]; i += sign) {
					let animator = animators[i];
					let channels = Object.keys(animator.channels);
					if (sign !== 1) channels.reverse();
					for (let channel of channels) {
						if (active && channel == this.channel && animator == this.animator) active = false;
						if (active && Timeline.vue.channels[channel] !== false) {
							let match = animator[channel].find(kf => Math.epsilon(this.time, kf.time, 0.01));
							if (match && !match.selected) {
								match.selected = true;
								Timeline.selected.push(match);
							}
						}
						if (!active && channel == last.channel && animator == last.animator) active = true;
					}
				}
			}
		}
		Timeline.selected.safePush(this);
		if (Timeline.selected.length == 1 && Timeline.selected[0].animator.selected == false) {
			Timeline.selected[0].animator.select();
		}
		this.selected = true;
		TickUpdates.keyframe_selection = true;

		if (this.transform) Timeline.vue.graph_editor_channel = this.channel;

		return this;
	}
	clickSelect(event) {
		Undo.initSelection({timeline: true});

		this.select(event);

		var select_tool = true;
		Timeline.selected.forEach(kf => {
			if (kf.channel != this.channel) select_tool = false;
		})
		if (select_tool) {
			switch (this.channel) {
				case 'rotation': BarItems.rotate_tool.select(); break;
				case 'position': BarItems.move_tool.select(); break;
				case 'scale': BarItems.resize_tool.select(); break;
			}
		}
		Undo.finishSelection('Select keyframe')
	}
	callPlayhead() {
		Timeline.setTime(this.time)
		Animator.preview()
		return this;
	}
	
	showInTimeline() {
		if (!Modes.animate) {
			Modes.options.animate.select()
		}
		if (!this.animator.animation.selected) {
			this.animator.animation.select();
		}
		this.animator.addToTimeline();
		this.select();

		Vue.nextTick(() => {
			let element = $(`.keyframe#${this.uuid}`);
			let offset = element.offset();
			if (!offset) return;

			let body = document.getElementById('timeline_body');
			let body_offset = $(body).offset();

			$(body).animate({
				scrollLeft: (offset.left - body_offset.left - 300),
				scrollTop: (offset.top - body_offset.top - 120)
			}, 200);
		})
	}
	showContextMenu(event) {
		if (!this.selected) {
			this.select();
			updateKeyframeSelection();
		}
		this.menu.open(event, this);
		return this;
	}
	remove() {
		if (this.animator) {
			this.animator[this.channel].remove(this)
		}
		Timeline.selected.remove(this)
	}
	forSelected(fc, undo_tag) {
		if (Timeline.selected.length <= 1 || !Timeline.selected.includes(this)) {
			var edited = [this]
		} else {
			var edited = Timeline.selected
		}
		if (undo_tag) {
			Undo.initEdit({keyframes: edited})
		}
		for (var i = 0; i < edited.length; i++) {
			fc(edited[i])
		}
		if (undo_tag) {
			Undo.finishEdit(undo_tag)
		}
		return edited;
	}
	getUndoCopy(save, options = {}) {
		var copy = {
			animator: save ? undefined : this.animator && this.animator.uuid,
			channel: this.channel,
			data_points: []
		}
		if (!save && this.animator instanceof EffectAnimator) {
			copy.animator = 'effects';
		}
		if (save) copy.uuid = this.uuid;
		for (var key in Keyframe.properties) {
			Keyframe.properties[key].copy(this, copy)
		}
		if (save && this.interpolation != 'bezier') {
			delete copy.bezier_linked;
			delete copy.bezier_left_time;
			delete copy.bezier_left_value;
			delete copy.bezier_right_time;
			delete copy.bezier_right_value;
		}
		this.data_points.forEach(data_point => {
			let point_copy = data_point.getUndoCopy();
			if (options.absolute_paths == false) delete point_copy.file;
			copy.data_points.push(point_copy);
		})
		return copy;
	}
}
	Keyframe.prototype.menu = new Menu([
		new MenuSeparator('settings'),
		'keyframe_uniform',
		'keyframe_bezier_linked',
		'keyframe_interpolation',
		{name: 'menu.cube.color', icon: 'color_lens', children() {
			return [
				{icon: 'bubble_chart', name: 'generic.unset', click: function(kf) {kf.forSelected(kf2 => {kf2.color = -1}, 'change color')}},
				...markerColors.map((color, i) => {return {
					icon: 'bubble_chart',
					color: color.standard,
					name: color.name || 'cube.color.'+color.id,
					click(kf) {
						kf.forSelected(function(kf2){kf2.color = i}, 'change color')
					}
				}})
			];
		}},
		new MenuSeparator('actions'),
		'resolve_keyframe_expressions',
		'reset_keyframe_handles',
		'reset_keyframe',
		'round_keyframe_values',
		new MenuSeparator('copypaste'),
		'copy',
		'save_animation_preset',
		'delete',
	])
	new Property(Keyframe, 'number', 'time')
	new Property(Keyframe, 'number', 'color', {default: -1})
	new Property(Keyframe, 'boolean', 'uniform', {condition: keyframe => keyframe.channel == 'scale', default: settings.uniform_keyframe.value})
	new Property(Keyframe, 'enum', 'interpolation', {default: 'linear'})
	new Property(Keyframe, 'boolean', 'bezier_linked', {default: true})
	new Property(Keyframe, 'vector', 'bezier_left_time', {default: [-0.1, -0.1, -0.1]});
	new Property(Keyframe, 'vector', 'bezier_left_value');
	new Property(Keyframe, 'vector', 'bezier_right_time', {default: [0.1, 0.1, 0.1]});
	new Property(Keyframe, 'vector', 'bezier_right_value');
	Keyframe.selected = [];
	Keyframe.interpolation = {
		linear: 'linear',
		catmullrom: 'catmullrom',
		bezier: 'bezier',
		step: 'step',
	}

// Misc Functions
export function updateKeyframeValue(axis, value, data_point) {
	Timeline.selected.forEach(function(kf) {
		if (axis == 'uniform' && kf.channel == 'scale') kf.uniform = true;
		if (data_point && !kf.data_points[data_point]) return;
		kf.set(axis, value, data_point);
	})
	if (!['effect', 'locator', 'script'].includes(axis)) {
		Animator.preview();
		updateKeyframeSelection();
	}
}
export function updateKeyframeSelection() {
	Timeline.keyframes.forEach(kf => {
		if (kf.selected && !Timeline.selected.includes(kf)) {
			kf.selected = false;
		}
		let has_expressions = false;
		if (kf.transform) {
			has_expressions = !!kf.data_points.find((point, i) => {
				return kf.getArray(i).find(v => typeof v == 'string');
			})
		}
		if (has_expressions != kf.has_expressions) {
			kf.has_expressions = has_expressions;
		}
	})
	if (Timeline.selected.length) {
		BarItems.slider_keyframe_time.update()
		BarItems.keyframe_interpolation.set(Timeline.selected[0].interpolation)
		if (BarItems.keyframe_uniform.value != !!Timeline.selected[0].uniform) {
			BarItems.keyframe_uniform.value = !!Timeline.selected[0].uniform;
			BarItems.keyframe_uniform.updateEnabledState();
		}
		if (BarItems.keyframe_bezier_linked.value != !!Timeline.selected[0].bezier_linked) {
			BarItems.keyframe_bezier_linked.value = !!Timeline.selected[0].bezier_linked;
			BarItems.keyframe_bezier_linked.updateEnabledState();
		}
	}
	if (settings.motion_trails.value && Modes.animate && Animation.selected && (Group.first_selected || (Outliner.selected[0] && Outliner.selected[0].constructor.animator) || Project.motion_trail_lock)) {
		Animator.showMotionTrail();
	} else if (Animator.motion_trail.parent) {
		Animator.motion_trail.children.forEachReverse(child => {
			Animator.motion_trail.remove(child);
		})
	}
	if (Timeline.selected.length >= 2) {
		Interface.addSuggestedModifierKey('ctrl', 'modifier_actions.stretch_keyframes');
	} else {
		Interface.removeSuggestedModifierKey('ctrl', 'modifier_actions.stretch_keyframes');
	}
	BARS.updateConditions()
	Blockbench.dispatchEvent('update_keyframe_selection');
}
export function selectAllKeyframes() {
	if (!Animation.selected) return;
	var state = Timeline.selected.length !== Timeline.keyframes.length
	Timeline.keyframes.forEach((kf) => {
		if (state && !kf.selected) {
			Timeline.selected.push(kf)
		} else if (!state && kf.selected) {
			Timeline.selected.remove(kf)
		}
		kf.selected = state
	})
	updateKeyframeSelection()
}
export function unselectAllKeyframes() {
	if (!Animation.selected) return;
	Timeline.keyframes.forEach((kf) => {
		Timeline.selected.remove(kf)
		kf.selected = false;
	})
	updateKeyframeSelection()
}
SharedActions.add('delete', {
	condition: () => Animator.open && Prop.active_panel == 'timeline' && Keyframe.selected.length,
	priority: -1,
	run() {
		Undo.initEdit({keyframes: Timeline.selected})
		var i = Timeline.keyframes.length;
		while (i > 0) {
			i--;
			let kf = Timeline.keyframes[i]
			if (Timeline.selected.includes(kf)) {
				kf.remove()
			}
		}
		updateKeyframeSelection()
		Animator.preview()
		Undo.finishEdit('Remove keyframes')
	}
})
SharedActions.add('select_all', {
	condition: () => Animator.open && Prop.active_panel == 'timeline' && Animation.selected,
	priority: -1,
	run() {
		selectAllKeyframes()
	}
})
SharedActions.add('unselect_all', {
	condition: () => Animator.open && Prop.active_panel == 'timeline' && Animation.selected,
	priority: -1,
	run() {
		unselectAllKeyframes()
	}
})
SharedActions.add('invert_selection', {
	condition: () => Animator.open && Prop.active_panel == 'timeline' && Animation.selected,
	priority: -1,
	run() {
		Timeline.keyframes.forEach((kf) => {
			if (!kf.selected) {
				Timeline.selected.push(kf)
				kf.selected = true;
			} else {
				Timeline.selected.remove(kf);
				kf.selected = false;
			}
		})
		updateKeyframeSelection()
	}
})

//Clipbench
Object.assign(Clipbench, {
	setKeyframes() {

		var keyframes = Timeline.selected;

		Clipbench.keyframes = []
		if (!keyframes || keyframes.length === 0) {
			return;
		}
		var first = keyframes[0];
		var single_animator;
		keyframes.forEach((kf) => {
			if (kf.time < first.time) {
				first = kf
			}
			if (single_animator && single_animator !== kf.animator.uuid) {
				single_animator = false;
			} else if (single_animator == undefined) {
				single_animator = kf.animator.uuid;
			}
		})

		keyframes.forEach((kf) => {
			var copy = kf.getUndoCopy();
			copy.time_offset = kf.time - first.time;
			if (single_animator != false) {
				delete copy.animator;
			}
			Clipbench.keyframes.push(copy)
		})
		if (isApp) {
			clipboard.writeHTML(JSON.stringify({type: 'keyframes', content: Clipbench.keyframes}))
		}
	},
	pasteKeyframes() {
		if (isApp) {
			var raw = clipboard.readHTML()
			try {
				var data = JSON.parse(raw)
				if (data.type === 'keyframes' && data.content) {
					Clipbench.keyframes = data.content
				}
			} catch (err) {}
		}
		if (Clipbench.keyframes && Clipbench.keyframes.length) {

			if (!Animation.selected) return;
			var keyframes = [];
			Undo.initEdit({keyframes});
			Timeline.selected.empty();
			Timeline.keyframes.forEach((kf) => {
				kf.selected = false;
			})
			Clipbench.keyframes.forEach(function(data, i) {

				if (data.animator) {
					var animator = Animation.selected.animators[data.animator];
					if (!animator && data.animator == 'effects') {
						animator = Animation.selected.animators.effects = new EffectAnimator(Animation.selected);
					}
					if (animator && !Timeline.animators.includes(animator)) {
						animator.addToTimeline();
					}
				} else {
					var animator = Timeline.selected_animator;
				}
				if (animator) {
					var kf = animator.createKeyframe(data, Timeline.time + data.time_offset, data.channel, false, false)
					if (!kf) return;
					keyframes.push(kf);
					kf.selected = true;
					Property.resetUniqueValues(Keyframe, kf);
					Timeline.selected.push(kf);
				}

			})
			TickUpdates.keyframe_selection = true;
			Animator.preview()
			Undo.finishEdit('Paste keyframes');
		}
	}
})


BARS.defineActions(function() {
	new Action('add_keyframe', {
		icon: 'add_circle',
		category: 'animation',
		condition: {modes: ['animate']},
		keybind: new Keybind({key: 'q'}, {
			reset_values: 'shift'
		}),
		variations: {
			reset_values: {
				name: 'action.add_keyframe.reset_values'
			}
		},
		click: function (event) {
			var animator = Timeline.selected_animator;
			if (!animator) return;
			var channel = Object.keys(animator.channels)[0];
			if (Toolbox.selected.id == 'rotate_tool' && animator.channels['rotation']) channel = 'rotation';
			if (Toolbox.selected.id == 'move_tool' && animator.channels['position']) channel = 'position';
			if (Toolbox.selected.id == 'resize_tool' && animator.channels['scale']) channel = 'scale';
			if (Timeline.vue.graph_editor_open && Prop.active_panel == 'timeline' && animator.channels[Timeline.vue.graph_editor_channel]) {
				channel = Timeline.vue.graph_editor_channel;
			}
			let reset_values = BarItems.add_keyframe.keybind.additionalModifierTriggered(event) == 'reset_values';
			animator.createKeyframe(reset_values ? {} : null, Timeline.time, channel, true);
			if (reset_values) {
				Animator.preview();
			}
		}
	})

	new Action('move_keyframe_back', {
		icon: 'arrow_back',
		category: 'transform',
		condition: {modes: ['animate'], method: () => (!open_menu && Timeline.selected.length)},
		keybind: new Keybind({key: 37}),
		click: function (e) {
			Undo.initEdit({keyframes: Timeline.selected})
			Timeline.selected.forEach((kf) => {
				kf.time = Timeline.snapTime(limitNumber(kf.time - Timeline.getStep(), 0, 1e4))
			})
			Animator.preview()
			BarItems.slider_keyframe_time.update()
			Undo.finishEdit('Move keyframes back')
		}
	})
	new Action('move_keyframe_forth', {
		icon: 'arrow_forward',
		category: 'transform',
		condition: {modes: ['animate'], method: () => (!open_menu && Timeline.selected.length)},
		keybind: new Keybind({key: 39}),
		click: function (e) {
			Undo.initEdit({keyframes: Timeline.selected})
			Timeline.selected.forEach((kf) => {
				kf.time = Timeline.snapTime(limitNumber(kf.time + Timeline.getStep(), 0, 1e4))
			})
			Animation.selected.setLength();
			Animator.preview()
			BarItems.slider_keyframe_time.update()
			Undo.finishEdit('Move keyframes forwards')
		}
	})
	function slideKeyframes(difference, event) {
		Undo.initEdit({keyframes: Timeline.selected});
		let round_num = canvasGridSize(event.shiftKey || Pressing.overrides.shift, event.ctrlOrCmd || Pressing.overrides.ctrl);
		if (Toolbox.selected.id === 'resize_tool') {
			round_num *= 0.1;
		}
		difference *= round_num;
		for (let kf of Timeline.selected) {
			kf.offset(Timeline.vue.graph_editor_axis, difference);
		}
		Undo.finishEdit('Move keyframe graph');
	}
	new Action('move_graph_keyframes_up', {
		icon: 'arrow_warm_up',
		category: 'transform',
		condition: {modes: ['animate'], method: () => (!open_menu && Timeline.selected.length && Timeline.vue.graph_editor_open)},
		keybind: new Keybind({key: 38, ctrl: null, shift: null}),
		click(e) {
			slideKeyframes(1, e);
			Animator.preview()
		}
	})
	new Action('move_graph_keyframes_down', {
		icon: 'arrow_cool_down',
		category: 'transform',
		condition: {modes: ['animate'], method: () => (!open_menu && Timeline.selected.length && Timeline.vue.graph_editor_open)},
		keybind: new Keybind({key: 40, ctrl: null, shift: null}),
		click(e) {
			slideKeyframes(-1, e);
			Animator.preview()
		}
	})
	new Action('previous_keyframe', {
		icon: 'fa-arrow-circle-left',
		category: 'animation',
		condition: {modes: ['animate']},
		click: function () {

			var time = Timeline.time;
			function getDelta(kf, abs) {
				return kf.time - time
			}
			let animator = Timeline.selected_animator
						|| (Timeline.selected[0] && Timeline.selected[0].animator)
						|| Timeline.animators[0];
			let channel = Timeline.selected[0] ? Timeline.selected[0].channel : (animator && Object.keys(animator.channels)[0]);
			
			var matches = []
			for (var kf of Timeline.keyframes) {
				if ((!animator || animator == kf.animator) && (!channel || channel == kf.channel)) {
					let delta = getDelta(kf)
					if (delta < 0) {
						matches.push(kf)
					}
				}
			}
			matches.sort((a, b) => {
				return Math.abs(getDelta(a)) - Math.abs(getDelta(b))
			})
			var kf = matches[0]
			if (kf) {
				kf.select().callPlayhead()
			} else {
				if (Timeline.selected.length) {
					selectAllKeyframes()
					selectAllKeyframes()
				}
				Timeline.setTime(0)
				Animator.preview()
			}
		}
	})
	new Action('next_keyframe', {
		icon: 'fa-arrow-circle-right',
		category: 'animation',
		condition: {modes: ['animate']},
		click: function () {

			var time = Timeline.time;
			function getDelta(kf, abs) {
				return kf.time - time
			}
			let animator = Timeline.selected_animator
						|| (Timeline.selected[0] && Timeline.selected[0].animator)
						|| Timeline.animators[0];
			let channel = Timeline.selected[0] ? Timeline.selected[0].channel : (animator && Object.keys(animator.channels)[0]);

			var matches = []
			for (var kf of Timeline.keyframes) {
				if ((!animator || animator == kf.animator) && (!channel || channel == kf.channel)) {
					let delta = getDelta(kf)
					if (delta > 0) {
						matches.push(kf)
					}
				}
			}
			matches.sort((a, b) => {
				return Math.abs(getDelta(a)) - Math.abs(getDelta(b))
			})
			var kf = matches[0]
			if (kf) {
				kf.select().callPlayhead()
			}
		}
	})

	new NumSlider('slider_keyframe_time', {
		category: 'animation',
		condition: () => Animator.open && Timeline.selected.length,
		getInterval(event) {
			if ((event && event.shiftKey) || Pressing.overrides.shift) return 1;
			return Timeline.getStep()
		},
		get: function() {
			return Timeline.selected[0] ? Timeline.selected[0].time : 0
		},
		change: function(modify) {
			Timeline.selected.forEach((kf) => {
				kf.time = Timeline.snapTime(limitNumber(modify(kf.time), 0, 1e4))
			})
			Animator.preview()
		},
		onBefore: function() {
			Undo.initEdit({keyframes: Timeline.selected})
		},
		onAfter: function() {
			Animation.selected.setLength();
			Undo.finishEdit('Change keyframe time')
		}
	})
	new Toggle('keyframe_uniform', {
		icon: 'link',
		category: 'animation',
		condition: () => Animator.open && Timeline.selected.length && !Timeline.selected.find(kf => kf.channel !== 'scale'),
		onChange(value) {
			let keyframes = Timeline.selected;
			Undo.initEdit({keyframes})
			keyframes.forEach((kf) => {
				kf.uniform = value;
			})
			Undo.finishEdit('Change keyframes uniform setting')
			Interface.Panels.keyframe.inside_vue.$forceUpdate();
			updateKeyframeSelection();
		}
	})
	new Toggle('keyframe_bezier_linked', {
		icon: 'fa-bezier-curve',
		category: 'animation',
		condition: () => Animator.open && Timeline.selected.length && !Timeline.selected.find(kf => kf.interpolation !== 'bezier'),
		onChange(value) {
			let keyframes = Timeline.selected;
			Undo.initEdit({keyframes})
			keyframes.forEach((kf) => {
				kf.bezier_linked = value;
				if (value) {
					kf.bezier_right_time.V3_set(kf.bezier_left_time).V3_multiply(-1);
					kf.bezier_right_value.V3_set(kf.bezier_left_value).V3_multiply(-1);
				}
			})
			Timeline.vue.show_zero_line = !Timeline.vue.show_zero_line;
			Timeline.vue.show_zero_line = !Timeline.vue.show_zero_line;
			Undo.finishEdit('Change keyframes bezier link option');
			updateKeyframeSelection();
		}
	})
	new BarSelect('keyframe_interpolation', {
		category: 'animation',
		condition: () => Animator.open && Timeline.selected.length && Timeline.selected.find(kf => kf.transform),
		options: {
			linear: true,
			catmullrom: true,
			bezier: true,
			step: true,
		},
		onChange: function(sel, event) {
			Undo.initEdit({keyframes: Timeline.selected})
			Timeline.selected.forEach((kf) => {
				if (kf.transform) {
					kf.interpolation = sel.value;
				}
			})
			Undo.finishEdit('Change keyframes interpolation')
			updateKeyframeSelection();
		}
	})
	new Action('reset_keyframe', {
		icon: 'replay',
		category: 'animation',
		condition: () => Animator.open && Timeline.selected.length,
		click: function () {
			Undo.initEdit({keyframes: Timeline.selected})
			Timeline.selected.forEach((kf) => {
				kf.data_points.replace([new KeyframeDataPoint(kf)]);
				if (kf.interpolation == 'bezier') {
					kf.bezier_left_time.V3_set(-0.1, -0.1, -0.1);
					kf.bezier_left_value.V3_set(0, 0, 0);
					kf.bezier_right_time.V3_set(0.1, 0.1, 0.1);
					kf.bezier_right_value.V3_set(0, 0, 0);
				}
			})
			Undo.finishEdit('Reset keyframes')
			updateKeyframeSelection()
			Animator.preview()
		}
	})
	new Action('reset_keyframe_handles', {
		icon: 'replay',
		category: 'animation',
		condition: () => Animator.open && Keyframe.selected.length && Timeline.vue.graph_editor_open && Keyframe.selected.find(kf => kf.interpolation == 'bezier'),
		click: function () {
			Undo.initEdit({keyframes: Timeline.selected})
			Timeline.selected.forEach((kf) => {
				if (kf.interpolation == 'bezier') {
					kf.bezier_left_time.V3_set(-0.1, -0.1, -0.1);
					kf.bezier_left_value.V3_set(0, 0, 0);
					kf.bezier_right_time.V3_set(0.1, 0.1, 0.1);
					kf.bezier_right_value.V3_set(0, 0, 0);
				}
			})
			Timeline.vue.show_zero_line = !Timeline.vue.show_zero_line;
			Timeline.vue.show_zero_line = !Timeline.vue.show_zero_line;
			Undo.finishEdit('Reset keyframe handles')
			updateKeyframeSelection()
			Animator.preview()
		}
	})
	new Action('round_keyframe_values', {
		icon: 'percent',
		category: 'animation',
		condition: () => Animator.open && Timeline.selected.length,
		click: function () {
			let round = (input) => {
				if (typeof input == 'number') return Math.round(input);
				return input.replace(/\d+.\d+/g, (number) => {
					return Math.round(parseFloat(number));
				})
			}
			let keyframes = Timeline.selected.filter(kf => kf.transform);
			Undo.initEdit({keyframes})
			keyframes.forEach((kf) => {
				for (let dp of kf.data_points) {
					for (let axis of 'xyz') {
						if (!Condition(KeyframeDataPoint.properties[axis].condition, dp)) continue;
						dp[axis] = round(dp[axis]);
					}
				}
			})
			Undo.finishEdit('Round keyframe values')
			updateKeyframeSelection()
			Animator.preview()
		}
	})
	new Action('resolve_keyframe_expressions', {
		icon: 'functions',
		category: 'animation',
		condition: () => Animator.open && Timeline.selected.length,
		click: function () {
			Undo.initEdit({keyframes: Timeline.selected})
			let time_before = Timeline.time;
			Timeline.selected.forEach((kf) => {
				if (kf.animator.fillValues) {
					Timeline.time = kf.time;
					kf.animator.fillValues(kf, null, false, false);
				}
			})
			Timeline.time = time_before;
			Undo.finishEdit('Resolve keyframes')
			updateKeyframeSelection()
		}
	})
	new Action('reverse_keyframes', {
		icon: 'swap_horizontal_circle',
		category: 'animation',
		condition: () => Animator.open && Timeline.selected.length,
		click: function () {
			var start = 1e9;
			var end = 0;
			Timeline.selected.forEach((kf) => {
				start = Math.min(start, kf.time);
				end = Math.max(end, kf.time);
			})
			Undo.initEdit({keyframes: Timeline.selected})
			Timeline.selected.forEach((kf) => {
				kf.time = end + start - kf.time;
				if (kf.transform && kf.data_points.length > 1) {
					kf.data_points.reverse();
				}
				if (kf.interpolation == 'bezier') {
					let rt = kf.bezier_right_time.slice();
					let rv = kf.bezier_right_value.slice();
					kf.bezier_right_time.replace(kf.bezier_left_time);
					kf.bezier_right_value.replace(kf.bezier_left_value);
					kf.bezier_left_time.replace(rt);
					kf.bezier_left_value.replace(rv);

					kf.bezier_right_time.V3_multiply(-1);
					kf.bezier_left_time.V3_multiply(-1);
				}
			})
			Undo.finishEdit('Reverse keyframes')
			updateKeyframeSelection()
			Animator.preview()
		}
	})
	let channels = ['rotation', 'position', 'scale']
	new Action('keyframe_column_create', {
		icon: 'add_road',
		category: 'animation',
		condition: () => Animator.open,
		keybind: new Keybind({}, {
			all_channels: 'shift'
		}),
		variations: {
			all_channels: {
				name: 'action.keyframe_column_create.all_channels',
				description: 'action.keyframe_column_create.all_channels.desc'
			}
		},
		click(event) {
			let all_channels = BarItems.keyframe_column_create.keybind.additionalModifierTriggered(event) == 'all_channels';
			Timeline.selected.empty();
			let new_keyframes = [];
			Undo.initEdit({keyframes: new_keyframes})
			Timeline.animators.forEach(animator => {
				if (animator instanceof BoneAnimator == false) return;
				channels.forEach(channel => {
					if (Timeline.vue.channels[channel] !== false && animator[channel] && (animator[channel].length || all_channels)) {
						let kf = animator[channel].find(kf => Math.epsilon(kf.time, Timeline.time, 1e-5));
						if (!kf) {
							kf = animator.createKeyframe(null, Timeline.time, channel, false, false);
							new_keyframes.push(kf)
						}
						Timeline.selected.push(kf);
						kf.selected = true;
					}
				})
			})
			updateKeyframeSelection();
			Undo.finishEdit('Create keyframe column');
		}
	})
	function selectKeyframes(select_condition) {
		Timeline.selected.empty();
		Timeline.animators.forEach(animator => {
			if (animator instanceof BoneAnimator == false) return;
			channels.forEach(channel => {
				if (Timeline.vue.channels[channel] !== false && animator[channel] && animator[channel].length) {
					animator[channel].forEach(kf => {
						if (Timeline.vue.channels[kf.channel] === false) return;
						if (select_condition(kf)) {
							Timeline.selected.push(kf);
							kf.selected = true;
						}
					})
				}
			})
		})
		updateKeyframeSelection();
	}
	new Action('keyframe_column_select', {
		icon: 'unfold_more_double',
		category: 'animation',
		condition: () => Animator.open,
		click() {
			selectKeyframes((kf) => {
				return Math.epsilon(kf.time, Timeline.time, 1e-5);
			});
		}
	})
	new Action('keyframe_select_before_playhead', {
		icon: 'text_select_move_back_character',
		category: 'animation',
		condition: () => Animator.open,
		click() {
			selectKeyframes((kf) => {
				return kf.time < (Timeline.time + 1e-5);
			});
		}
	})
	new Action('keyframe_select_after_playhead', {
		icon: 'text_select_move_forward_character',
		category: 'animation',
		condition: () => Animator.open,
		click() {
			selectKeyframes((kf) => {
				return kf.time > (Timeline.time - 1e-5);
			});
		}
	})
})

Interface.definePanels(function() {
	
	new Panel('keyframe', {
		icon: 'icon-keyframe',
		condition: {modes: ['animate'], method: () => !AnimationController.selected},
		default_position: {
			slot: 'left_bar',
			float_position: [0, 0],
			float_size: [300, 400],
			height: 400,
			sidebar_index: 4,
		},
		toolbars: [
			new Toolbar({
				id: 'keyframe',
				children: [
					'slider_keyframe_time',
					'keyframe_interpolation',
					'keyframe_uniform',
					'reset_keyframe'
				]
			})
		],
		component: {
			name: 'panel-keyframe',
			components: {VuePrismEditor},
			data() { return {
				keyframes: Timeline.selected,
				channel_colors: {
					x: 'color_x',
					y: 'color_y',
					z: 'color_z',
				}
			}},
			methods: {
				updateInput(axis, value, data_point) {
					updateKeyframeValue(axis, value, data_point);
				},
				updateToggleInput(axis, value, data_point) {
					Undo.initEdit({keyframes: Timeline.selected})
					updateKeyframeValue(axis, value, data_point);
					Undo.finishEdit('Edit keyframe');
				},
				getKeyframeInfos() {
					let channel_name = this.firstKeyframe?.animator.channels[this.channel]?.name;
					let list =  [channel_name ?? ''];
					if (this.keyframes.length > 1) list.push(this.keyframes.length);
					return list.join(', ')
				},
				addDataPoint() {
					Undo.initEdit({keyframes: Timeline.selected})
					Timeline.selected.forEach(kf => {
						if (kf.data_points.length < kf.animator.channels[kf.channel].max_data_points) {
							kf.data_points.push(new KeyframeDataPoint(kf))
							kf.data_points.last().extend(kf.data_points[0])
						}
					})
					Animator.preview()
					Undo.finishEdit('Add keyframe data point')
				},
				removeDataPoint(data_point_index) {
					Undo.initEdit({keyframes: Timeline.selected})
					Timeline.selected.forEach(kf => {
						if (kf.data_points.length >= 2) {
							kf.data_points.splice(data_point_index, 1);
						}
					})
					Animator.preview()
					Undo.finishEdit('Remove keyframe data point')
				},
				updateLocatorSuggestionList() {
					Locator.updateAutocompleteList();
				},
				changeBindToActor(event, i) {
					Undo.initEdit({keyframes: Timeline.selected});
					for (let kf of Timeline.selected) {
						if (kf.data_points[i]) kf.data_points[i].bind_to_actor = event.target.checked;
					}
					Undo.finishEdit('Change keyframe property bind to actor');
				},
				focusAxis(axis) {
					if ('xyz'.includes(axis)) {
						Timeline.vue.graph_editor_axis = axis;
					}
				},
				slideValue(axis, e1, data_point) {
					convertTouchEvent(e1);
					let last_event = e1;
					let started = false;
					let move_calls = 0;
					let last_val = 0;
					let total = 0;
					let clientX = e1.clientX;
					function start() {
						started = true;
						if (!e1.touches && last_event == e1 && e1.target.requestPointerLock) e1.target.requestPointerLock();
						Undo.initEdit({keyframes: Keyframe.selected});
					}
		
					function move(e2) {
						convertTouchEvent(e2);
						if (!started && Math.abs(e2.clientX - e1.clientX) > 5) {
							start()
						}
						if (started) {
							if (e1.touches) {
								clientX = e2.clientX;
							} else {
								let limit = move_calls <= 2 ? 1 : 100;
								clientX += Math.clamp(e2.movementX, -limit, limit);
							}
							let val = Math.round((clientX - e1.clientX) / 40);
							let difference = (val - last_val);
							if (difference) {
								if (Keyframe.selected[0]?.channel == 'rotation') {
									difference *= getRotationInterval(e2);
								} else {
									difference *= canvasGridSize(e2.shiftKey || Pressing.overrides.shift, e2.ctrlOrCmd || Pressing.overrides.ctrl);
								}
							
								Keyframe.selected.forEach(kf => {
									kf.offset(axis, difference, data_point);
								})

								last_val = val;
								total += difference;

								Animator.preview()
								Blockbench.setStatusBarText(trimFloatNumber(total));
							}
							last_event = e2;
							move_calls++;
						}
					}
					function off(e2) {
						if (document.exitPointerLock) document.exitPointerLock()
						removeEventListeners(document, 'mousemove touchmove', move);
						removeEventListeners(document, 'mouseup touchend', off);
						if (total) {
							Undo.finishEdit('Slide keyframe');
						} else {
							Undo.cancelEdit();
						}
					}
					addEventListeners(document, 'mouseup touchend', off);
					addEventListeners(document, 'mousemove touchmove', move);
				},
				changeKeyframeFile(data_point, keyframe) {
					if (keyframe.channel == 'particle') {
						Blockbench.import({
							resource_id: 'animation_particle',
							extensions: ['json'],
							type: 'Bedrock Particle',
							startpath: keyframe.data_points[0].file
						}, function(files) {

							let {path} = files[0];
							Undo.initEdit({keyframes: [keyframe]})
							data_point.file = path;
							let effect = Animator.loadParticleEmitter(path, files[0].content);
							if (!data_point.effect) data_point.effect = files[0].name.toLowerCase().split('.')[0].replace(/[^a-z0-9._]+/g, '');
							delete effect.config.preview_texture;
							Undo.finishEdit('Change keyframe particle file');

							if (!isApp) {
								Blockbench.showMessageBox({
									title: 'message.import_particle_texture.import',
									message: 'message.import_particle_texture.message',
									buttons: ['dialog.cancel'],
									commands: {
										import: 'message.import_particle_texture.import'
									}
								}, result => {
									if (result != 'import') return;

									Blockbench.import({
										extensions: ['png'],
										type: 'Particle Texture',
										readtype: 'image',
										startpath: effect.config.preview_texture || path
									}, function(files) {
										effect.config.preview_texture = isApp ? files[0].path : files[0].content;
										effect.config.updateTexture();
									})
								})

							} else if (effect.config.texture.image.src.startsWith('data:')) {
								Blockbench.import({
									extensions: ['png'],
									type: 'Particle Texture',
									readtype: 'image',
									startpath: effect.config.preview_texture || path
								}, function(files) {
									effect.config.preview_texture = isApp ? files[0].path : files[0].content;
									effect.config.updateTexture();
								})
							}
						})
					} else {
						Blockbench.import({
							resource_id: 'animation_audio',
							extensions: ['ogg', 'wav', 'mp3'],
							type: 'Audio File',
							startpath: keyframe.data_points[0].file
						}, function(files) {

							let path = isApp
								? files[0].path
								: URL.createObjectURL(files[0].browser_file);

							Undo.initEdit({keyframes: [keyframe]})
							data_point.file = path;
							if (!data_point.effect) data_point.effect = files[0].name.toLowerCase().replace(/\.[a-z]+$/, '').replace(/[^a-z0-9._]+/g, '');
							Timeline.visualizeAudioFile(path);
							Undo.finishEdit('Change keyframe audio file')
						})
					}
				},
				openMolangContextMenu(axis, event, value, data_point_i) {
					new Menu([
						{
							name: 'menu.text_edit.expression_editor',
							icon: 'code_blocks',
							click() {
								openMolangEditor({
									autocomplete_context: MolangAutocomplete.KeyframeContext,
									text: value
								}, result => {
									Undo.initEdit({keyframes: Timeline.selected});
									Timeline.selected.forEach(function(kf) {
										if (data_point_i && !kf.data_points[data_point_i]) return;
										kf.set(axis, result, data_point_i);
									})
									Undo.finishEdit('Change keyframe value')
									if (!['effect', 'locator', 'script'].includes(axis)) {
										Animator.preview();
										updateKeyframeSelection();
									}
								})
							}
						}
					]).open(event);
				},
				autocomplete(text, position) {
					if (Settings.get('autocomplete_code') == false) return [];
					let test = MolangAutocomplete.KeyframeContext.autocomplete(text, position);
					return test;
				},
				tl,
				Condition
			},
			computed: {
				channel() {
					var channel = false;
					for (var kf of this.keyframes) {
						if (channel === false) {
							channel = kf.channel
						} else if (channel !== kf.channel) {
							channel = false
							break;
						}
					}
					return channel;
				},
				firstKeyframe() {
					let data_point_length = 0;
					let keyframe;
					for (let kf of this.keyframes) {
						if (kf.data_points.length > data_point_length) {
							keyframe = kf;
							data_point_length = kf.data_points.length;
						}
					}
					return keyframe;
				}
			},
			template: `
				<div>
					<div class="toolbar_wrapper keyframe"></div>

					<template v-if="channel != false">

						<div id="keyframe_type_label">
							<label>{{ tl('panel.keyframe.type', [getKeyframeInfos()]) }}</label>
							<div
								class="in_list_button"
								v-if="firstKeyframe.animator.channels[channel] && firstKeyframe.data_points.length < firstKeyframe.animator.channels[channel].max_data_points && firstKeyframe.interpolation !== 'catmullrom'"
								v-on:click.stop="addDataPoint()"
								title="${ tl('panel.keyframe.change_effect_file') }"
							>
								<i class="material-icons">add</i>
							</div>
						</div>

						<ul class="list" :style="{overflow: firstKeyframe.data_points.length > 1 ? 'auto' : 'visible'}">

							<div v-for="(data_point, data_point_i) of firstKeyframe.data_points" class="keyframe_data_point">

								<div class="keyframe_data_point_header" v-if="firstKeyframe.data_points.length > 1">
									<label>{{ firstKeyframe.transform ? tl('panel.keyframe.' + (data_point_i ? 'post' : 'pre')) : (data_point_i + 1) }}</label>
									<div class="flex_fill_line"></div>
									<div class="in_list_button" v-on:click.stop="removeDataPoint(data_point_i)" title="${ tl('panel.keyframe.remove_data_point') }">
										<i class="material-icons">clear</i>
									</div>
								</div>

								<template v-if="channel == 'scale' && firstKeyframe.uniform && data_point.x_string == data_point.y_string && data_point.y_string == data_point.z_string">
									<div
										class="bar flex"
										id="keyframe_bar_uniform_scale"
									>
										<label>${ tl('generic.all') }</label>
										<vue-prism-editor 
											class="molang_input keyframe_input tab_target"
											v-model="data_point['x_string']"
											@change="updateInput('uniform', $event, data_point_i)"
											@contextmenu="openMolangContextMenu('uniform', $event, data_point['x_string'], data_point_i)"
											language="molang"
											:autocomplete="autocomplete"
											:ignoreTabKey="true"
											:line-numbers="false"
										/>
									</div>
								</template>


								<template v-else>
									<div
										v-for="(property, key) in data_point.constructor.properties"
										v-if="property.exposed != false && Condition(property.condition, data_point)"
										class="bar flex"
										:id="'keyframe_bar_' + property.name"
									>
										<label :class="{[channel_colors[key]]: true, slidable_input: property.type == 'molang', axis: !!channel_colors[key]}" @mousedown="slideValue(key, $event, data_point_i)" @touchstart="slideValue(key, $event, data_point_i)">{{ property.label }}</label>
										<vue-prism-editor 
											v-if="property.type == 'molang'"
											class="molang_input keyframe_input tab_target"
											v-model="data_point[key+'_string']"
											@change="updateInput(key, $event, data_point_i)"
											@focus="focusAxis(key)"
											@contextmenu="openMolangContextMenu(key, $event, data_point[key+'_string'], data_point_i)"
											language="molang"
											:autocomplete="autocomplete"
											:ignoreTabKey="true"
											:line-numbers="false"
										/>
										<input
											type="checkbox"
											v-else-if="property.type == 'boolean'"
											class="keyframe_input tab_target"
											@input="updateToggleInput(key, $event.target.checked, data_point_i)"
											:checked="data_point[key]"
										/>
										<input
											v-else
											type="text"
											class="dark_bordered code keyframe_input tab_target"
											v-model="data_point[key]"
											:list="key == 'locator' && 'locator_suggestion_list'"
											@focus="key == 'locator' && updateLocatorSuggestionList()"
											@input="updateInput(key, $event.target.value, data_point_i)"
										/>
										<input type="checkbox" v-if="key == 'locator'" :checked="data_point.bind_to_actor" title="${tl('timeline.bind_to_actor')}" @input="changeBindToActor($event, data_point_i)">
										<div class="tool" v-if="key == 'effect'" :title="tl(channel == 'sound' ? 'timeline.select_sound_file' : 'timeline.select_particle_file')" @click="changeKeyframeFile(data_point, firstKeyframe)">
											<i class="material-icons">upload_file</i>
										</div>
									</div>
								</template>
							</div>
						</ul>
					</template>
				</div>
			`
		}
	})

	let keyframe_edit_value;
	function isTarget(target) {
		return target?.classList?.contains('keyframe_input') || target?.parentElement?.parentElement?.classList?.contains('keyframe_input');
	}
	document.addEventListener('focus', event => {
		if (isTarget(event.target)) {

			keyframe_edit_value = event.target.value || event.target.innerText;
			Undo.initEdit({keyframes: Timeline.selected.slice()})
		}
	}, true)
	document.addEventListener('focusout', event => {
		if (isTarget(event.target)) {

			let val = event.target.value || event.target.innerText;
			if (val != keyframe_edit_value) {
				Undo.finishEdit('Edit keyframe');
			} else {
				Undo.cancelEdit();
			}
		}
	})
})

Object.assign(window, {
	KeyframeDataPoint,
	Keyframe,
	BBKeyframe: Keyframe,
	updateKeyframeValue,
	updateKeyframeSelection,
	selectAllKeyframes,
	unselectAllKeyframes
})
