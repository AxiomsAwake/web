
export class NullObject extends OutlinerElement {
	constructor(data, uuid) {
		super(data, uuid);

		for (var key in NullObject.properties) {
			NullObject.properties[key].reset(this);
		}

		if (data) {
			this.extend(data);
		}
	}
	get origin() {
		return this.position;
	}
	extend(object) {
		if (object.from) this.position.V3_set(object.from);
		for (var key in NullObject.properties) {
			NullObject.properties[key].merge(this, object)
		}
		this.sanitizeName();
		Merge.boolean(this, object, 'export');
		return this;
	}
	select(event, isOutlinerClick) {
		super.select(event, isOutlinerClick);
		if (Animator.open && Animation.selected) {
			Animation.selected.getBoneAnimator(this)?.select(true);
		}
		return this;
	}
	unselect(...args) {
		if (Animator.open && Timeline.selected_animator && Timeline.selected_animator.element == this) {
			Timeline.selected_animator.selected = false;
		}
		return super.unselect(...args);
	}
	flip(axis, center) {
		var offset = this.position[axis] - center
		this.position[axis] = center - offset;
		// Name
		flipNameOnAxis(this, axis);
		this.createUniqueName();
		this.preview_controller.updateTransform(this);
		return this;
	}
	getWorldCenter(with_animation) {
		let pos = new THREE.Vector3();
		let q = Reusable.quat1.set(0, 0, 0, 1);
		let parent_object = this.parent.scene_object;
		if (parent_object) {
			THREE.fastWorldPosition(parent_object, pos);
			parent_object.getWorldQuaternion(q);
			if (this.parent instanceof Group) {
				let offset2 = Reusable.vec2.fromArray(this.parent.origin).applyQuaternion(q);
				pos.sub(offset2);
			}
		}
		let offset;
		if (with_animation && Animation.selected) {
			offset = Reusable.vec3.copy(this.mesh.position);
			if (this.parent instanceof Group) {
				offset.x += this.parent.origin[0];
				offset.y += this.parent.origin[1];
				offset.z += this.parent.origin[2];
			}
		} else {
			offset = Reusable.vec3.fromArray(this.position);
		}
		offset.applyQuaternion(q);
		pos.add(offset);

		return pos;
	}
	static behavior = {
		movable: true,
		hide_in_screenshot: true,
	}
}
	NullObject.prototype.title = tl('data.null_object');
	NullObject.prototype.type = 'null_object';
	NullObject.prototype.icon = 'far.fa-circle';
	//NullObject.prototype.name_regex = 'a-z0-9_'
	NullObject.prototype.visibility = true;
	NullObject.prototype.buttons = [
		//Outliner.buttons.export,
		Outliner.buttons.locked,
		Outliner.buttons.visibility,
	];
	NullObject.prototype.menu = new Menu([
			new MenuSeparator('ik'),
			'set_ik_target',
			'set_ik_source',
			'set_ik_pole',
			{
				id: 'lock_ik_target_rotation',
				name: 'menu.null_object.lock_ik_target_rotation',
				icon: null_object => null_object.lock_ik_target_rotation ? 'check_box' : 'check_box_outline_blank',
				click(clicked_null_object) {
					let value = !clicked_null_object.lock_ik_target_rotation;
					let affected = NullObject.selected.filter(null_object => null_object.lock_ik_target_rotation != value);
					Undo.initEdit({elements: affected});
					affected.forEach(null_object => {
						null_object.lock_ik_target_rotation = value;
					})
					Undo.finishEdit('Change null object lock ik target rotation option');
					if (Modes.animate) Animator.preview();
					updateSelection();
				}
			},
			...Outliner.control_menu_group,
			new MenuSeparator('manage'),
			'rename',
			'delete'
		])
	
	new Property(NullObject, 'string', 'name', {default: 'null_object'})
	new Property(NullObject, 'vector', 'position')
	new Property(NullObject, 'string', 'ik_target', {
		condition: () => Format.animation_mode,
		inputs: {
			element_panel: {
				input: {label: 'null_object.ik_target', description: 'action.set_ik_target.desc', type: 'outliner_node', getOutlinerNodes() {
					let nodes = [];
					if (NullObject.hasSelected()) iterate(NullObject.selected[0].getParentArray(), 0);
					function iterate(arr, level) {
						arr.forEach(node => {
							if (node.constructor.animator || node instanceof Locator) {
								if (level) nodes.push(node);
							}
							if (node.children) {
								iterate(node.children, level+1);
							}
						})
					}
					return nodes;
				}},
				onChange() {
					if (Modes.animate) Animator.preview();
				}
			}
		}
	});
	new Property(NullObject, 'string', 'ik_source', {
		condition: () => Format.animation_mode,
		inputs: {
			element_panel: {
				input: {label: 'null_object.ik_source', description: 'action.set_ik_source.desc', type: 'outliner_node', getOutlinerNodes() {
					let nodes = [];
					iterate(Outliner.root)
					function iterate(arr) {
						arr.forEach(node => {
							if (node.children) {
								if (node.constructor.animator) {
									nodes.push(node);
								}
								iterate(node.children)
							}
						})
					}
					return nodes;
				}},
				onChange() {
					if (Modes.animate) Animator.preview();
				}
			}
		}
	});
	new Property(NullObject, 'string', 'ik_pole', {
		condition: () => Format.animation_mode,
		inputs: {
			element_panel: {
				input: {label: 'null_object.ik_pole', description: 'action.set_ik_pole.desc', type: 'outliner_node', getOutlinerNodes() {
					let nodes = [];
					if (NullObject.hasSelected()) iterate(NullObject.selected[0].getParentArray(), 0);
					function iterate(arr) {
						arr.forEach(node => {
							if (node.selected) return;
							if (node instanceof Group) {
								nodes.push(node);
								iterate(node.children);
							} else if (node instanceof Locator || node instanceof NullObject) {
								nodes.push(node);
							}
						})
					}
					return nodes;
				}},
				onChange() {
					if (Modes.animate) Animator.preview();
				}
			}
		}
	});
	new Property(NullObject, 'boolean', 'lock_ik_target_rotation', {
		condition: () => Format.animation_mode,
		inputs: {
			element_panel: {
				input: {label: 'menu.null_object.lock_ik_target_rotation', type: 'checkbox'},
				onChange() {
					if (Modes.animate) Animator.preview();
				}
			}
		}
	})
	new Property(NullObject, 'boolean', 'visibility', {default: true});
	new Property(NullObject, 'boolean', 'locked');
	
	OutlinerElement.registerType(NullObject, 'null_object');


	const map = new THREE.TextureLoader().load( 'assets/null_object.png' );
	map.magFilter = map.minFilter = THREE.NearestFilter;
	
new NodePreviewController(NullObject, {
	setup(element) {
		let material = new THREE.SpriteMaterial({
			map,
			alphaTest: 0.1,
			sizeAttenuation: false
		});
		var mesh = new THREE.Sprite(material);
		Project.nodes_3d[element.uuid] = mesh;
		mesh.name = element.uuid;
		mesh.type = element.type;
		mesh.isElement = true;
		mesh.visible = element.visibility;
		mesh.rotation.order = Format.euler_order;
		element.mesh.fix_position = new THREE.Vector3();
		this.updateTransform(element);

		this.dispatchEvent('setup', {element});
		this.dispatchEvent('update_selection', {element});
	},
	updateTransform(element) {
		NodePreviewController.prototype.updateTransform.call(this, element);

		element.mesh.fix_position.copy(element.mesh.position);

		this.updateWindowSize(element);

		this.dispatchEvent('update_transform', {element});
	},
	updateSelection(element) {
		let {mesh} = element;

		mesh.material.color.set(element.selected ? gizmo_colors.outline : CustomTheme.data.colors.text);
		mesh.material.depthTest = !element.selected;
		mesh.renderOrder = element.selected ? 100 : 0;
		mesh.visible = !!Canvas.show_element_markers;

		this.dispatchEvent('update_selection', {element});
	},
	updateWindowSize(element) {
		let size = 0.38 * Preview.selected.camera.fov / Preview.selected.height;
		element.mesh.scale.set(size, size, size);
	}
})


BARS.defineActions(function() {
	new Action('add_null_object', {
		icon: 'far.fa-circle',
		category: 'edit',
		condition: () => Format.animation_mode && Modes.edit,
		click: function () {
			var objs = []
			Undo.initEdit({elements: objs, outliner: true});
			var null_object = new NullObject().addTo(Group.first_selected||Outliner.selected[0]).init();
			null_object.select().createUniqueName();
			objs.push(null_object);
			Undo.finishEdit('Add null object');
			Vue.nextTick(function() {
				if (settings.create_rename.value) {
					null_object.rename();
				}
			})
		}
	})
	
	new Action('set_ik_target', {
		icon: 'fa-paperclip',
		category: 'edit',
		condition() {
			let action = BarItems.set_ik_target;
			return NullObject.selected.length && action.children(action).length
		},
		searchable: true,
		children() {
			let nodes = [];
			iterate(NullObject.selected[0].getParentArray(), 0);

			function iterate(arr, level) {
				arr.forEach(node => {
					if (node.constructor.animator || node instanceof Locator) {
						if (level) nodes.push(node);
					}
					if (node.children) {
						iterate(node.children, level+1);
					}
				})
			}
			return nodes.map(node => {
				return {
					name: node.name + (node.uuid == NullObject.selected[0].ik_target ? ' (✔)' : ''),
					icon: node.icon,
					marked: node.uuid == NullObject.selected[0].ik_target,
					color: markerColors[node.color % markerColors.length]?.standard,
					click() {
						Undo.initEdit({elements: NullObject.selected});
						NullObject.selected.forEach(null_object => {
							null_object.ik_target = node.uuid;
						})
						Undo.finishEdit('Set IK target');
					}
				}
			})
		},
		click(event) {
			new Menu('set_ik_target', this.children(this), {searchable: true}).show(event.target, this);
		}
	})

	new Action('set_ik_source', {
		icon: 'fa-link',
		category: 'edit',
		condition() {
			let action = BarItems.set_ik_source;
			return NullObject.selected.length && action.children(action).length
		},
		searchable: true,
		children() {
			let nodes = [];
			iterate(Outliner.root)

			function iterate(arr) {
				arr.forEach(node => {
					if (node.children) {
						if (node.constructor.animator) {
							nodes.push(node);
						}
						iterate(node.children)
					}
				})
			}
			return nodes.map(node => {
				return {
					name: node.name + (node.uuid == NullObject.selected[0].ik_source ? ' (✔)' : ''),
					icon: node instanceof Locator ? 'fa-anchor' : 'folder',
					marked: node.uuid == NullObject.selected[0].ik_source,
					color: markerColors[node.color % markerColors.length]?.standard,
					click() {
						Undo.initEdit({elements: NullObject.selected});
						NullObject.selected.forEach(null_object => {
							null_object.ik_source = node.uuid;
						})
						Undo.finishEdit('Set IK source');
					}
				}
			})
		},
		click(event) {
			new Menu('set_ik_source', this.children(this), {searchable: true}).show(event.target, this);
		}

	})

	new Action('set_ik_pole', {
		icon: 'chip_extraction',
		category: 'edit',
		condition() {
			let action = BarItems.set_ik_pole;
			return NullObject.selected.length && action.children(action).length
		},
		searchable: true,
		children() {
			let nodes = [];
			iterate(NullObject.selected[0].getParentArray());

			function iterate(arr) {
				arr.forEach(node => {
					if (node.selected) return;
					if (node instanceof Group) {
						nodes.push(node);
						iterate(node.children);
					} else if (node instanceof Locator || node instanceof NullObject) {
						nodes.push(node);
					}
				})
			}
			return nodes.map(node => {
				return {
					name: node.name + (node.uuid == NullObject.selected[0].ik_pole ? ' (✔)' : ''),
					icon: node.icon,
					color: markerColors[node.color % markerColors.length] && markerColors[node.color % markerColors.length].standard,
					click() {
						Undo.initEdit({ elements: NullObject.selected });
						NullObject.selected.forEach(null_object => {
							if (null_object.ik_pole == node.uuid) {
								null_object.ik_pole = undefined;
							} else {
								null_object.ik_pole = node.uuid;
							}
						})
						Undo.finishEdit('Set IK pole');
					}
				}
			})
		},
		click(event) {
			new Menu('set_ik_pole', this.children(this), { searchable: true }).show(event.target, this);
		}
	})
})

Object.assign(window, {
	NullObject
});
