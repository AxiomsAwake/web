
export class Group extends OutlinerNode {
	constructor(data, uuid) {
		super(uuid)

		for (var key in Group.properties) {
			Group.properties[key].reset(this);
		}

		this.name = (Format.bone_rig && !Format.armature_rig) ? 'bone' : 'group';
		this.children = []
		this.reset = false;
		this.shade = true;
		this.mirror_uv = false;
		this.selected = false;
		this.locked = false;
		this.visibility = true;
		this.export = true;
		this.autouv = 0;
		this.parent = 'root';
		this.isOpen = false;

		if (typeof data === 'object') {
			this.extend(data)
		} else if (typeof data === 'string') {
			this.name = data
		}
	}
	extend(object) {
		for (var key in Group.properties) {
			Group.properties[key].merge(this, object)
		}
		Merge.string(this, object, 'name')
		this.sanitizeName();
		Merge.boolean(this, object, 'shade')
		Merge.boolean(this, object, 'mirror_uv')
		Merge.boolean(this, object, 'reset')
		/*
		if (object.origin) {
			Merge.number(this.origin, object.origin, 0)
			Merge.number(this.origin, object.origin, 1)
			Merge.number(this.origin, object.origin, 2)
		}
		if (object.rotation) {
			Merge.number(this.rotation, object.rotation, 0)
			Merge.number(this.rotation, object.rotation, 1)
			Merge.number(this.rotation, object.rotation, 2)
		}*/
		Merge.number(this, object, 'autouv')
		Merge.boolean(this, object, 'export')
		Merge.boolean(this, object, 'locked')
		Merge.boolean(this, object, 'visibility')
		return this;
	}
	getMesh() {
		return this.mesh;
	}
	init() {
		super.init();
		Project.groups.push(this);
		if (!this.mesh || !this.mesh.parent) {
			this.constructor.preview_controller.setup(this);
		}
		Canvas.updateAllBones([this]);
		return this;
	}
	select(event, is_outliner_click) {
		if (Blockbench.hasFlag('renaming') || this.locked) return this;
		if (!event) event = true
		var allSelected = Group.multi_selected.length == 1 && Group.first_selected === this && Outliner.selected.length && this.matchesSelection();
		let previous_first_selected = Project.selected_elements[0];
		let multi_select = (event.ctrlOrCmd || Pressing.overrides.ctrl) && !Modes.animate;
		let shift_select = (event.shiftKey || Pressing.overrides.shift) && !Modes.animate;

		//Unselect others
		if (!multi_select && !shift_select) {
			unselectAllElements();
			Project.groups.forEach(function(s) {
				s.selected = false;
			})
		}

		if (event && shift_select && this.getParentArray().includes(Group.multi_selected.last()) && is_outliner_click) {
			let selecting;
			let last_selected = Group.multi_selected.last();
			this.getParentArray().forEach((s, i) => {
				let select_this = false;
				if (s === last_selected || s === this) {
					selecting = !selecting;
					select_this = true;
				} else if (selecting) {
					select_this = true;
				}
				if (select_this) {
					if (s instanceof Group) {
						s.multiSelect()
					} else if (!Outliner.selected.includes(s)) {
						s.markAsSelected()
					}
				}
			})
		} else {
			//Select This Group
			this.selected = true;
			Group.multi_selected.safePush(this);
		}

		//Select / Unselect Children
		if (allSelected && (event.which === 1 || isTouchEvent(event))) {
			//Select Only Group, unselect Children
			this.forEachChild(child => {
				child.unselect();
			});
		} else {
			// Fix for #2401
			if (previous_first_selected && previous_first_selected.isChildOf(this)) {
				Outliner.selected.safePush(previous_first_selected);
			}
			this.children.forEach(function(s) {
				s.markAsSelected(true)
			})
		}
		if (Animator.open && Animation.selected) {
			let ba = Animation.selected.getBoneAnimator(this);
			if (ba) {
				ba.select(true);
			} else {
				Blockbench.showQuickMessage('The current animation does not target this node');
			}
		}
		updateSelection()
		return this;
	}
	clickSelect(event, is_outliner_click) {
		if (Blockbench.hasFlag('renaming') || this.locked) return this;
		Undo.initSelection();
		this.select(event, is_outliner_click);
		Undo.finishSelection('Select group');
	}
	multiSelect() {
		if (this.locked) return this;
		this.selected = true;
		Group.multi_selected.safePush(this);
		this.children.forEach(function(s) {
			s.markAsSelected()
		})
		TickUpdates.selection = true;
		return this;
	}
	selectChildren(event) {
		console.warn('Group#selectChildren is deprecated');
	}
	markAsSelected(descendants) {
		this.selected = true
		this.children.forEach(function(s) {
			s.markAsSelected(descendants)
		})
		TickUpdates.selection = true;
		return this;
	}
	unselect(unselect_parent) {
		if (Animator.open && Animation.selected) {
			var ba = Animation.selected.animators[this.uuid];
			if (ba) {
				ba.selected = false
			}
		}
		Group.multi_selected.remove(this);
		this.selected = false;
		if (unselect_parent && this.parent.selected) {
			this.parent.unselect(unselect_parent);
		}
		TickUpdates.selection = true;
		return this;
	}
	matchesSelection() {
		if (Group.multi_selected.length != 1 || this != Group.first_selected) return false;
		let scope = this;
		let match = true;
		for (let i = 0; i < Outliner.selected.length; i++) {
			if (!Outliner.selected[i].isChildOf(scope, 128)) {
				return false
			}
		}
		this.forEachChild(obj => {
			if (!obj.selected) {
				match = false
			}
		})
		return match;
	}
	openUp() {
		this.isOpen = true
		this.updateElement()
		if (this.parent && this.parent !== 'root') {
			this.parent.openUp()
		}
		return this;
	}
	remove(undo) {
		let elements = [];
		let groups = [this];
		if (undo) {
			this.forEachChild(function(element) {
				if (element.type == 'group') {
					groups.push(element)
				} else {
					elements.push(element)
				}
			})
			let animations = [];
			Animator.animations.forEach(animation => {
				if (animation.animators && animation.animators[this.uuid]) {
					animations.push(animation);
				}
			})
			Undo.initEdit({elements, groups, outliner: true, selection: true, animations})
		}
		this.unselect()
		super.remove();
		var i = this.children.length-1
		while (i >= 0) {
			this.children[i].remove(false)
			i--;
		}
		Animator.animations.forEach(animation => {
			if (animation.animators && animation.animators[this.uuid]) {
				animation.removeAnimator(this.uuid);
			}
			if (animation.selected && Animator.open) {
				updateKeyframeSelection();
			}
		})
		TickUpdates.selection = true;
		Project.groups.remove(this);
		delete OutlinerNode.uuids[this.uuid];
		if (undo) {
			elements.empty();
			groups.empty();
			Undo.finishEdit('Delete group')
		}
	}
	resolve(undo = true) {
		var array = this.children.slice();
		var index = this.getParentArray().indexOf(this)
		let all_elements = [];
		let all_groups = [this];
		this.forEachChild(obj => {
			if (obj instanceof Group == false) {
				all_elements.push(obj);
			} else {
				all_groups.push(obj);
			}
		})

		if (undo) Undo.initEdit({outliner: true, groups: all_groups, elements: all_elements})

		array.forEach((obj, i) => {
			obj.addTo(this.parent, index)
			
			if ((obj instanceof Cube && Format.rotate_cubes) || (obj instanceof OutlinerElement && obj.getTypeBehavior('rotatable')) || (obj instanceof Group && Format.bone_rig)) {
				let quat = new THREE.Quaternion().copy(obj.mesh.quaternion);
				quat.premultiply(obj.mesh.parent.quaternion);
				let e = new THREE.Euler().setFromQuaternion(quat, obj.mesh.rotation.order);
				obj.extend({
					rotation: [
						Math.roundTo(Math.radToDeg(e.x), 4),
						Math.roundTo(Math.radToDeg(e.y), 4),
						Math.roundTo(Math.radToDeg(e.z), 4),
					]
				})
			}
			if (obj.mesh) {
				let pos = new THREE.Vector3().copy(obj.mesh.position);
				pos.applyQuaternion(this.mesh.quaternion).sub(obj.mesh.position);
				let diff = pos.toArray();

				if (obj.from) obj.from.V3_add(diff);
				if (obj.to) obj.to.V3_add(diff);
				if (obj.getTypeBehavior('rotatable') || obj instanceof Group) obj.origin.V3_add(diff);

				if (obj instanceof Group) {
					obj.forEachChild(child => {
						if (child instanceof Mesh) {
							for (let vkey in child.vertices) {
								child.vertices[vkey].V3_add(diff);
							}
						}
						if (child instanceof Cube) child.from.V3_add(diff);
						if (child.to) child.to.V3_add(diff);
						if (child.origin) child.origin.V3_add(diff);
					})
				}
			}
		})
		Canvas.updateAllPositions();
		if (Format.bone_rig) {
			Canvas.updateAllBones();
		}
		this.remove(false);
		if (undo) {
			all_groups.remove(this);
			Undo.finishEdit('Resolve group');
		}
		return array;
	}
	showContextMenu(event) {
		if (this.locked) return this;
		if (!Group.multi_selected.includes(this)) this.select(event);
		this.menu.open(event, this)
		return this;
	}
	getWorldCenter() {
		return THREE.fastWorldPosition(this.mesh, new THREE.Vector3());
	}
	transferOrigin(origin) {
		if (!this.mesh) return;
		var q = new THREE.Quaternion().copy(this.mesh.quaternion)
		var shift = new THREE.Vector3(
			this.origin[0] - origin[0],
			this.origin[1] - origin[1],
			this.origin[2] - origin[2],
		)
		var dq = new THREE.Vector3().copy(shift)
		dq.applyQuaternion(q)
		shift.sub(dq)
		shift.applyQuaternion(q.invert())
		this.origin.V3_set(origin);

		function iterateChild(obj) {
			if (obj instanceof Group) {
				obj.origin.V3_add(shift);
				obj.children.forEach(child => iterateChild(child));

			} else {
				if (obj.getTypeBehavior('movable')) {
					obj.origin.V3_add(shift);
				}
				if (obj.to) {
					obj.from.V3_add(shift);
					obj.to.V3_add(shift);
				}
			}
		}
		this.children.forEach(child => iterateChild(child));

		Canvas.updatePositions()
		return this;
	}
	setColor(index) {
		this.color = index;
		return this;
	}
	sortContent() {
		Undo.initEdit({outliner: true})
		if (this.children.length < 1) return;
		this.children.sort(function(a,b) {
			return sort_collator.compare(a.name, b.name)
		});
		Undo.finishEdit('Sort group content')
		return this;
	}
	duplicate() {
		var copy = this.getChildlessCopy(false);
		Clipbench.duplicate_map.set(this, copy);
		delete copy.parent;
		if (this.getTypeBehavior('unique_name')) copy.temp_data.old_name = this.name;
		Property.resetUniqueValues(Group, copy);
		copy.sortInBefore(this, 1).init()
		if (this.getTypeBehavior('unique_name')) {
			copy.createUniqueName()
		}
		for (var child of this.children) {
			child.duplicate().addTo(copy)
		}
		copy.isOpen = true;
		Canvas.updatePositions();
		return copy;
	}
	getSaveCopy(nested) {
		let base_group = this.getChildlessCopy(true);
		if (nested) {
			for (let child of this.children) {
				base_group.children.push(child.getSaveCopy(nested));
			}
		}
		delete base_group.parent;
		return base_group;
	}
	getChildlessCopy(keep_uuid) {
		var base_group = new Group({name: this.name}, keep_uuid ? this.uuid : null);
		for (var key in Group.properties) {
			Group.properties[key].copy(this, base_group)
		}
		base_group.name = this.name;
		base_group.origin.V3_set(this.origin);
		base_group.rotation.V3_set(this.rotation);
		base_group.shade = this.shade;
		base_group.mirror_uv = this.mirror_uv;
		base_group.reset = this.reset;
		base_group.locked = this.locked;
		base_group.visibility = this.visibility;
		base_group.export = this.export;
		base_group.autouv = this.autouv;
		base_group.isOpen = this.isOpen;
		if (keep_uuid) {
			base_group.primary_selected = Group.selected.includes(this);
		}
		return base_group;
	}
	compile(undo) {
		var obj = {
			name: this.name
		}
		for (var key in Group.properties) {
			Group.properties[key].copy(this, obj)
		}
		if (this.shade == false) {
			obj.shade = false
		}
		if (undo) {
			obj.uuid = this.uuid;
			obj.export = this.export;
			obj.mirror_uv = this.mirror_uv;
			obj.isOpen = this.isOpen === true;
			obj.locked = this.locked;
			obj.visibility = this.visibility;
			obj.autouv = this.autouv;
			obj.selected = Group.multi_selected.includes(this);
		}
		
		if (this.rotation.allEqual(0)) {
			delete obj.rotation;
		}
		if (this.reset) {
			obj.reset = true
		}
		obj.children = []
		return obj;
	}
	forEachChild(cb, type, forSelf) {
		var i = 0
		if (forSelf) {
			cb(this)
		}
		while (i < this.children.length) {
			if (!type || (type instanceof Array ? type.find(t2 => this.children[i] instanceof t2) : this.children[i] instanceof type)) {
				cb(this.children[i])
			}
			if (this.children[i].forEachChild) {
				this.children[i].forEachChild(cb, type)
			}
			i++;
		}
	}
	setAutoUV(val) {
		this.forEachChild(function(s) {
			s.autouv = val;
			s.updateElement()
		})
		this.autouv = val;
		this.updateElement()
	}
	static behavior = {
		unique_name: false,
		parent: true,
		select_children: 'all_first',
		movable: true,
		rotatable: true,
		has_pivot: true,
		use_absolute_position: true,
		marker_color: true,
	}
}
Group.addBehaviorOverride({
	condition: {features: ['bone_rig']},
	behavior: {
		unique_name: true
	}
})
	Group.prototype.title = tl('data.group');
	Group.prototype.type = 'group';
	Group.prototype.icon = 'folder';
	Group.prototype.name_regex = () => Format.bone_rig ? (Format.node_name_regex ?? 'a-zA-Z0-9_') : false;
	Group.prototype.buttons = [
		Outliner.buttons.autouv,
		Outliner.buttons.mirror_uv,
		Outliner.buttons.shade,
		Outliner.buttons.export,
		Outliner.buttons.locked,
		Outliner.buttons.visibility,
	];
	Group.prototype.menu = new Menu([
		...Outliner.control_menu_group,
		new MenuSeparator('settings'),
		'edit_bedrock_binding',
		'set_element_marker_color',
		"randomize_marker_colors",
		{name: 'menu.cube.texture', icon: 'collections', condition: () => Format.per_group_texture, children(context) {
			function applyTexture(texture_value, undo_message) {
				let affected_groups = Group.all.filter(g => g.selected);
				Undo.initEdit({groups: affected_groups});
				for (let group of affected_groups) {
					group.texture = texture_value;
				}
				Undo.finishEdit(undo_message);
				Canvas.updateAllFaces();
			}
			let arr = [
				{icon: 'crop_square', name: Format.single_texture_default ? 'menu.cube.texture.default' : 'menu.cube.texture.blank', click(group) {
					applyTexture('', 'Unassign texture from group');
				}}
			]
			Texture.all.forEach(t => {
				arr.push({
					name: t.name,
					icon: (t.mode === 'link' ? t.img : t.source),
					marked: t.uuid == context.texture,
					click(group) {
						applyTexture(t.uuid, 'Apply texture to group');
					}
				})
			})
			return arr;
		}},
		{icon: 'sort_by_alpha', name: 'menu.group.sort', condition: {modes: ['edit']}, click: function(group) {group.sortContent()}},
		'apply_animation_preset',
		'add_all_to_timeline',
		'add_locator',
		new MenuSeparator('manage'),
		'resolve_group',
		'rename',
		'delete'
	]);
	Object.defineProperty(Group, 'all', {
		get() {
			return Project.groups || [];
		},
		set(arr) {
			Project.groups.replace(arr);
		}
	})
	Object.defineProperty(Group, 'multi_selected', {
		get() {
			return Project.selected_groups || []
		},
		set(arr) {
			if (arr instanceof Array == false) {
				console.warn('Not an array!')
			}
			Project.selected_groups.replace(arr)
		}
	})
	Object.defineProperty(Group, 'selected', {
		get() {
			return Project.selected_groups || []
		},
		set(arr) {
			if (arr instanceof Array == false) {
				console.warn('Not an array!')
			}
			Project.selected_groups.replace(arr)
		}
	})
	Object.defineProperty(Group, 'first_selected', {
		get() {
			return Project.selected_groups?.[0]
		},
		set(group) {
			Project.selected_groups.replace([group]);
		}
	})

new Property(Group, 'vector', 'origin', {default() {
	return Format.centered_grid ? [0, 0, 0] : [8, 8, 8]
}});
new Property(Group, 'vector', 'rotation');
new Property(Group, 'number', 'scope');
new Property(Group, 'string', 'bedrock_binding', {
	condition: {formats: ['bedrock']},
	inputs: {
		element_panel: {
			input: {label: 'group.bedrock_binding', description: 'action.edit_bedrock_binding.desc', type: 'text'},
			onChange() {
				Group.selected.forEach(group => {
					group.preview_controller.updateTransform(group);
				});
			}
		}
	}
});
new Property(Group, 'array', 'cem_animations', {condition: {formats: ['optifine_entity']}});
new Property(Group, 'boolean', 'cem_attach', {
	condition: {formats: ['optifine_entity']},
	inputs: {
		element_panel: {
			input: {label: 'group.cem_attach', type: 'checkbox'}
		}
	}
});
new Property(Group, 'string', 'cem_model', {
	condition: {formats: ['optifine_entity']},
	inputs: {
		element_panel: {
			input: {label: 'group.cem_model', type: 'text'}
		}
	}
});
new Property(Group, 'number', 'cem_scale', {
	condition: {formats: ['optifine_entity']},
	inputs: {
		element_panel: {
			input: {label: 'group.cem_scale', type: 'number'}
		}
	}
});
new Property(Group, 'string', 'texture', {condition: {features: ['per_group_texture']}});
//new Property(Group, 'vector2', 'texture_size', {condition: {formats: ['optifine_entity']}});
new Property(Group, 'vector', 'skin_original_origin', {condition: {formats: ['skin']}});
new Property(Group, 'number', 'color');

new NodePreviewController(Group, {
	setup(group) {
		let bone = new THREE.Object3D();
		bone.name = group.uuid;
		bone.isGroup = true;
		Project.nodes_3d[group.uuid] = bone;
		bone.rotation.order = Format.euler_order;

		this.dispatchEvent('update_transform', {group});
	},
	updateVisibility(element) {
		this.dispatchEvent('update_visibility', {element});
	},
	updateTransform(group) {
		NodePreviewController.prototype.updateTransform.call(this, group);
		let bone = group.scene_object;

		if (group.scope >= 2 && Project.getMultiFileRuleset()) {
			if (group.bedrock_binding) {
				let base = 85000;
				let bone_names = [];
				let mapped_binding = group.bedrock_binding.replace(/'(\w+)'/g, (match, name) => {
					bone_names.push(name.toLowerCase());
					return base + bone_names.length-1;
				})
				let result = Animator.MolangParser.parse(mapped_binding, {
					"query.item_slot_to_bone_name"(input) {
						return 85070;
					}
				});
				let bone_name = bone_names[result - base];
				if (result == 85070) bone_name = 'rightitem';
				let target_group = bone_name && Group.all.find(g => g.name.length == bone_name.length && g.name.toLowerCase() == bone_name);

				if (target_group) {
					bone.position.set(group.origin[0], group.origin[1], group.origin[2])
					if (group.parent instanceof Group) {
						bone.position.x -= group.parent.origin[0];
						bone.position.y -= group.parent.origin[1];
						bone.position.z -= group.parent.origin[2];
					} else {
						bone.position.y -= 24;
					}
					target_group.mesh.add(bone);
					bone.updateMatrixWorld();
				}
			} else {
				let name = group.name.toLowerCase();
				let target_group = Group.all.find(g => g.scope == 1 && g.name.toLowerCase() == name);
				if (target_group) {
					target_group.mesh.add(bone);
					bone.position.set(0, 0, 0);
					bone.updateMatrixWorld();
				}
			}
		}

		bone.scale.x = bone.scale.y = bone.scale.z = 1;
		bone.fix_position = bone.position.clone();
		bone.fix_rotation = bone.rotation.clone();
	}
})


export function getCurrentGroup() {
	if (Group.first_selected) {
		return Group.first_selected
	} else if (Outliner.selected.length) {
		var g1 = Outliner.selected[0].parent;
		if (g1 instanceof Group) {
			for (var obj of Outliner.selected) {
				if (obj.parent !== g1) {
					return;
				}
			}
			return g1;
		}
	}
}
export function getAllGroups() {
	var ta = []
	function iterate(array) {
		for (var obj of array) {
			if (obj instanceof Group) {
				ta.push(obj)
				iterate(obj.children)
			}
		}
	}
	iterate(Outliner.root)
	return ta;
}
window.__defineGetter__('selected_group', () => {
	console.warn('selected_group is deprecated. Please use Group.first_selected instead.')
	return Group.first_selected
})

BARS.defineActions(function() {
	new Action('add_group', {
		icon: 'create_new_folder',
		category: 'edit',
		condition: () => Modes.edit,
		keybind: new Keybind({key: 'g', ctrl: true}),
		click: function () {
			Undo.initEdit({outliner: true, groups: [], selection: true});
			let lowest_selected = Outliner.selected.concat(Group.multi_selected).filter(n => !n.parent?.selected);
			var add_group = lowest_selected.find(s => s instanceof Group) || lowest_selected[0];
			var base_group = new Group({
				origin: add_group ? add_group.origin : undefined,
				scope: add_group?.scope
			})
			base_group.isOpen = true
			if (base_group.getTypeBehavior('unique_name')) {
				base_group.createUniqueName()
			}

			if (add_group?.children && add_group?.getTypeBehavior('child_types')?.includes('group') == false) {
				add_group = undefined;
			} else if (add_group?.parent instanceof OutlinerNode && add_group.parent.getTypeBehavior('child_types')?.includes('group') == false) {
				add_group = undefined;
			}

			if (lowest_selected.length >= 2 && add_group) {
				base_group.sortInBefore(add_group, 1);
				lowest_selected.forEach((s) => {
					s.addTo(base_group)
				})
			} else {
				base_group.addTo(add_group)
			}

			base_group.init().select()
			Undo.finishEdit('Add group', {outliner: true, groups: [base_group], selection: true});
			Vue.nextTick(function() {
				updateSelection()
				if (settings.create_rename.value) {
					base_group.rename()
				}
				base_group.showInOutliner()
				Blockbench.dispatchEvent( 'add_group', {object: base_group} )
			})
		}
	})
	new Action('group_elements', {
		icon: 'drive_folder_upload',
		category: 'edit',
		condition: () => Modes.edit && (Outliner.selected.length || Group.first_selected) && !Outliner.selected.some(el => el.getTypeBehavior('parent_types')?.includes('group') == false),
		keybind: new Keybind({key: 'g', ctrl: true, shift: true}),
		click: function () {
			let add_group = Group.first_selected;
			if (!add_group && Outliner.selected.length) {
				add_group = Outliner.selected.last()
			}
			if (add_group?.parent instanceof OutlinerNode &&
				add_group.parent.getTypeBehavior('child_types')?.includes('group') == false
			) {
				return;
			}
			Undo.initEdit({outliner: true, groups: [], selection: true});
			let new_name = add_group?.name;
			let base_group = new Group({
				origin: add_group ? add_group.origin : undefined,
				name: ['cube', 'mesh'].includes(new_name) ? undefined : new_name,
				scope: add_group?.scope
			})
			base_group.sortInBefore(add_group);
			base_group.isOpen = true
			base_group.init();
		
			if (base_group.getTypeBehavior('unique_name')) {
				base_group.createUniqueName()
			}
			Outliner.selected.concat(Group.multi_selected).forEach((s) => {
				if (s.parent?.selected) return;
				s.addTo(base_group);
				s.preview_controller.updateTransform(s);
			})
			base_group.select()
			Undo.finishEdit('Add group', {outliner: true, groups: [base_group], selection: true});
			Vue.nextTick(function() {
				updateSelection()
				if (settings.create_rename.value) {
					base_group.rename()
				}
				base_group.showInOutliner()
				Blockbench.dispatchEvent( 'group_elements', {object: base_group} )
			})
		}
	})
	new Action('collapse_groups', {
		icon: 'format_indent_decrease',
		category: 'edit',
		condition: () => Group.all.length > 0 || Outliner.elements.some(e => e.children),
		click: function() {
			Group.all.forEach(g => g.isOpen = false);
			Outliner.elements.forEach(element => {
				if ('isOpen' in element) element.isOpen = false;
			});
		}
	})
	new Action('unfold_groups', {
		icon: 'format_indent_increase',
		category: 'edit',
		condition: () => Group.all.length > 0 || Outliner.elements.some(e => e.children),
		click: function() {
			Group.all.forEach(g => g.isOpen = true);
			Outliner.elements.forEach(element => {
				if ('isOpen' in element) element.isOpen = true;
			});
		}
	})
	new Action('edit_bedrock_binding', {
		icon: 'fa-paperclip',
		category: 'edit',
		condition: () => Format.bone_binding_expression && Group.first_selected,
		click: function() {

			let dialog = new Dialog({
				id: 'edit_bedrock_binding',
				title: 'action.edit_bedrock_binding',
				resizable: 'x',
				component: {
					components: {VuePrismEditor},
					data: {
						binding: Group.first_selected.bedrock_binding,
					},
					methods: {
						showPresetMenu(event) {
							new Menu([
								{
									name: 'Item Slot',
									icon: 'build',
									click: () => {
										this.binding = 'q.item_slot_to_bone_name(c.item_slot)';
									}
								},
								{
									name: 'Right Hand',
									icon: 'build',
									click: () => {
										this.binding = '\'rightitem\'';
									}
								},
								{
									name: 'Left Hand',
									icon: 'build',
									click: () => {
										this.binding = '\'leftitem\'';
									}
								},
								{
									name: 'Body',
									icon: 'build',
									click: () => {
										this.binding = '\'body\'';
									}
								},
								{
									name: 'Head',
									icon: 'build',
									click: () => {
										this.binding = '\'head\'';
									}
								}
							]).show(event.target);
						},
						autocomplete(text, position) {
							if (Settings.get('autocomplete_code') == false) return [];
							let test = MolangAutocomplete.BedrockBindingContext.autocomplete(text, position);
							return test;
						}
					},
					template: 
						`<div class="dialog_bar">
							<vue-prism-editor class="molang_input" v-model="binding" language="molang" :autocomplete="autocomplete" :line-numbers="false" style="width: calc(100% - 36px); display: inline-block;" />
							<i class="tool material-icons" style="vertical-align: top; padding: 3px; float: none;" @click="showPresetMenu($event)">menu</i>
						</div>`
				},
				onConfirm: form_data => {
					dialog.hide().delete();
					let value = dialog.component.data.binding.replace(/\n/g, '');
					if (
						value != Group.first_selected.bedrock_binding
					) {
						Undo.initEdit({groups: Group.multi_selected});
						for (let group of Group.multi_selected) {
							group.bedrock_binding = value;
							group.preview_controller.updateTransform(group);
						}
						Undo.finishEdit('Edit group binding');
						updateSelection();
					}
				},
				onCancel() {
					dialog.hide().delete();
				}
			}).show();
		}
	})
	new Action('resolve_group', {
		icon: 'fa-leaf',
		condition: {modes: ['edit'], method: () => Group.first_selected},
		click() {
			let all_elements = [];
			let all_groups = [];
			for (let group of Group.multi_selected) {
				all_groups.push(group);
				group.forEachChild(obj => {
					if (obj instanceof Group == false) {
						all_elements.safePush(obj);
					} else {
						all_groups.push(obj);
					}
				})
			}
			Undo.initEdit({outliner: true, elements: all_elements, groups: all_groups})
			for (let group of Group.multi_selected.slice()) {
				group.resolve(false);
				all_groups.remove(group);
			}
			Undo.finishEdit('Resolve group');
		}
	})
})

Interface.definePanels(function() {
	new Panel('bone', {
		icon: 'fas.fa-bone',
		condition: !Blockbench.isMobile && {modes: ['animate'], method: () => !AnimationController.selected},
		display_condition: () => Group.first_selected,
		default_position: {
			slot: 'right_bar',
			float_position: [0, 0],
			float_size: [300, 400],
			height: 400,
			sidebar_index: 3,
		},
		component: {
			template: `
				<div>
					<p class="panel_toolbar_label">${ tl('panel.element.origin') }</p>
					<div class="toolbar_wrapper bone_origin"></div>
				</div>
			`
		}
	})
})

Object.assign(window, {
	Group,
	getCurrentGroup,
	getAllGroups
});
