import { Filesystem } from "../file_system";
import { getFocusedTextInput } from "../interface/keyboard"
import { Property } from "../util/property"

export interface TextureLayerData {
	name?: string
	in_limbo?: boolean
	offset?: ArrayVector2
	scale?: ArrayVector2
	width?: number
	height?: number
	opacity?: number
	visible?: boolean
	blend_mode?: LayerBlendMode
	image_data?: ImageData
	data_url?: string
}
export type LayerBlendMode = 'default' | 'set_opacity' | 'color' | 'multiply' | 'add' | 'darken' | 'lighten' | 'screen' | 'overlay' | 'difference' | 'alpha_mask'

/**
 * Abstract parent class for texture layers and layer groups. In the future can be expanded for things like text or fx layers
 */
export abstract class TextureLayerItem {
	texture: Texture
	name: string
	uuid: UUID
	parent_uuid: string | UUID
	multi_selected: boolean
	visible: boolean
	public type = 'layer'
	declare menu?: Menu

	constructor(data: TextureLayerData, texture = Texture.selected, uuid?: UUID) {
		this.uuid = (uuid && isUUID(uuid)) ? uuid : guid();
		this.texture = texture;
		this.multi_selected = false;
	}
	get selected() {
		return this.texture.selected_layer == this || this.multi_selected;
	}
	get parent(): TextureLayerGroup | null {
		if (!this.parent_uuid) return null;
		return this.texture.layers.find(l => l.uuid == this.parent_uuid) as TextureLayerGroup ?? null;
	}
	set parent(parent: TextureLayerGroup) {
		this.parent_uuid = parent.uuid;
	}
	getDepth(): number {
		let d = 0;
		let it = (p: TextureLayerItem) => {
			if (p.parent) {
				d++;
				return it(p.parent);
			} else {
				return d;
			}
		}
		return it(this);
	}
	extend(data: any) {}
	getSaveCopy(arg: any): any {}
	getUndoCopy(arg: any): any {}
	/**
	 * Selects the layer
	 */
	select(multi_select?: boolean) {
		this.texture.selected_layer = this;
		if (!multi_select) {
			this.texture.layers.forEach(layer => layer.multi_selected = false);
		}
		this.texture.layers.replace(TextureLayerItem.solveLayerOrder(this.texture.layers));
		this.multi_selected = true;
		UVEditor.vue.layer = this;
	}
	clickSelect(event: MouseEvent) {
		Undo.initSelection();
		if (event.shiftKey || Pressing.overrides.shift) {
			let previous = TextureLayerItem.previous_selected;
			let previous_index = this.texture.layers.indexOf(previous);
			let current_index = this.texture.layers.indexOf(this);
			if (previous_index != -1 && previous_index != current_index) {
				for (let i = current_index; i != previous_index; i += Math.sign(previous_index-current_index)) {
					this.texture.layers[i].select(true);
				}
			} else {
				this.select(true);
			}

		} else {
			this.select(event.ctrlOrCmd || Pressing.overrides.ctrl);
		}
		TextureLayerItem.previous_selected = this;
		Undo.finishSelection('Select layer');
	}
	showContextMenu(event: MouseEvent): void {
		if (!this.selected) this.clickSelect(event);
		if ('menu' in this) this.menu.open(event, this);
	}
	/**
	 * Add the layer to the associated texture above the previously selected layer, select this layer, and scroll the layer panel list to it
	 */
	addForEditing(): this {
		let layer_list = this.texture.layers;
		let i = layer_list.indexOf(this.texture.selected_layer);
		if (i == -1) {
			layer_list.push(this);
		} else {
			layer_list.splice(i+1, 0, this);
		}
		layer_list.replace(TextureLayerItem.solveLayerOrder(layer_list));
		this.select();
		Vue.nextTick(() => {
			this.scrollTo();
		});
		return this;
	}
	/**
	 * Scroll the layer panel list to
	 */
	scrollTo(): this {
		let el = document.querySelector(`#layers_list > li[layer_id="${this.uuid}"]`);
		if (el) {
			el.scrollIntoView({behavior: 'smooth', block: 'nearest'});
		}
		return this;
	}
	/**
	 * Remove the layer
	 * @param undo Create an undo point and update the texture
	 */
	remove(undo = false) {
		if (undo) {
			Undo.initEdit({textures: [this.texture], bitmap: true});
		}
		let index = this.texture.layers.indexOf(this);
		this.texture.layers.splice(index, 1);
		if (this.texture.selected_layer == this) {
			let select_next = this.texture.layers[index-1] || this.texture.layers[index];
			if (select_next) select_next.select();
		}
		if (undo) {
			this.texture.updateChangesAfterEdit();
			Undo.finishEdit('Remove layer');
		}
	}
	/**
	 * Open the properties dialog
	 */
	propertiesDialog(): void {
		let dialog = new Dialog({
			id: 'layer_properties',
			title: `${this.name}`,
			form: {
				name: {label: 'generic.name', value: this.name},
			},
			onConfirm: form_data => {
				dialog.hide().delete();
				if (
					form_data.name != this.name
				) {
					Undo.initEdit({layers: [this]});
					this.extend(form_data);
					this.texture.updateChangesAfterEdit();
					Blockbench.dispatchEvent('edit_layer_properties', {layer: this});
					Undo.finishEdit('Edit layer properties');
				}
			},
			onCancel() {
				dialog.hide().delete();
			}
		})
		dialog.show();
	}

	/**
	 * Util function to update the order of layers of a texture to support the hierarchy.
	 * Returns a new array with the result
	 */
	static solveLayerOrder(list: TextureLayerItem[]): TextureLayerItem[] {
		let sorted_list: TextureLayerItem[] = [];
		let layer_by_parent: Record<string, TextureLayerItem[]> = {'': []};
		list.forEachReverse(layer => {
			layer_by_parent[layer.parent_uuid??''] ??= [];
			layer_by_parent[layer.parent_uuid??''].push(layer);
		});
		let addRecursive = (layer: TextureLayerItem) => {
			sorted_list.unshift(layer);
			if (!layer_by_parent[layer.uuid]) return;
			for (let layer2 of layer_by_parent[layer.uuid]) {
				addRecursive(layer2);
			}
		};
		for (let layer of layer_by_parent['']) {
			addRecursive(layer);
		}
		return sorted_list;
	}
	static types: Record<string, any> = {};
	static registerType(id: string, constructor: any) {
		TextureLayerItem.types[id] = constructor;
	}
	static previous_selected: TextureLayerItem | null = null;
}

/**
 * Texture layers always belong to a texture and represent the layers of the texture. Each layer has its own HTML canvas and canvas context
 */
export class TextureLayer extends TextureLayerItem {
	canvas: HTMLCanvasElement
	ctx: CanvasRenderingContext2D
	in_limbo: boolean
	img: HTMLImageElement
	declare menu?: Menu
	/**
	 * Layer offset from the top left corner of the texture to the top left corner of the layer
	 */
	offset: ArrayVector2
	/**
	 * Layer scale. This is only used by the layer transform tool and should be applied and reset to 1x1 before doing further changes
	 */
	scale: ArrayVector2
	opacity: number
	blend_mode: LayerBlendMode

	public type = 'pixel_layer'
	static properties: Record<string, Property<any>>

	constructor(data: TextureLayerData, texture = Texture.selected, uuid?: UUID) {
		super(data, texture, uuid);
		this.uuid = (uuid && isUUID(uuid)) ? uuid : guid();
		this.texture = texture;
		this.canvas = document.createElement('canvas');
		this.ctx = this.canvas.getContext('2d', {willReadFrequently: true});
		this.in_limbo = false;

		this.img = new Image();
		this.img.onload = () => {
			this.canvas.width = this.img.naturalWidth;
			this.canvas.height = this.img.naturalHeight;
			this.ctx.drawImage(this.img, 0, 0);
		}

		for (let key in TextureLayer.properties) {
			TextureLayer.properties[key].reset(this);
		}

		if (data) this.extend(data);
	}
	get width() {
		return this.canvas.width;
	}
	get height() {
		return this.canvas.height;
	}
	get scaled_width() {
		return this.canvas.width * this.scale[0];
	}
	get scaled_height() {
		return this.canvas.height * this.scale[1];
	}
	get size() {
		return [this.canvas.width, this.canvas.height];
	}
	extend(data: TextureLayerData) {
		for (let key in TextureLayer.properties) {
			TextureLayer.properties[key].merge(this, data)
		}
		if (data.image_data) {
			let image_data = data.image_data;
			this.canvas.width = data.width || 16;
			this.canvas.height = data.height || 16;
			if (image_data instanceof ImageData == false) {
				// Process serialized session data
				image_data = this.ctx.createImageData(this.canvas.width, this.canvas.height);
				image_data.data.set(data.image_data.data, 0);
			}
			this.ctx.putImageData(image_data, 0, 0);

		} else if (data.data_url) {
			this.canvas.width = data.width || 16;
			this.canvas.height = data.height || 16;
			this.img.src = data.data_url;
		}
	}
	/**
	 * Selects the layer
	 */
	select(multi_select?: boolean) {
		super.select(multi_select);
		BarItems.layer_opacity.update();
		BarItems.layer_blend_mode.set(this.blend_mode);
		if (this.in_limbo && Toolbox.selected.id != 'selection_tool') {
			BarItems.selection_tool.select();
		}
	}
	getUndoCopy(image_data: boolean): any {
		let copy: any = {};
		copy.texture = this.texture.uuid;
		copy.uuid = this.uuid;
		copy.type = this.type;
		for (let key in TextureLayer.properties) {
			TextureLayer.properties[key].copy(this, copy);
		}
		copy.width = this.width;
		copy.height = this.height;
		if (image_data) {
			copy.image_data = this.ctx.getImageData(0, 0, this.width, this.height);
		}
		return copy;
	}
	getSaveCopy(): any {
		let copy: any = {};
		copy.type = this.type;
		for (let key in TextureLayer.properties) {
			TextureLayer.properties[key].copy(this, copy);
		}
		delete copy.in_limbo;
		copy.width = this.width;
		copy.height = this.height;
		copy.data_url = this.canvas.toDataURL('image/png', 1);
		return copy;
	}
	/**
	 * Set the layer into a limbo state, where clicking Place or clicking next to the layer will place it on the layer below
	 */
	setLimbo() {
		this.texture.layers.forEach(layer => {
			if ("in_limbo" in layer) layer.in_limbo = false;
		});
		this.in_limbo = true;
	}
	/**
	 * Resolves the limbo state by turning the limbo layer into a full layer, or merging it into the layer below
	 * @param keep_separate If true, the layer is kept as a separate layer
	 */
	resolveLimbo(keep_separate: boolean): void {
		if (keep_separate) {
			if (this.scale[0] != 1 || this.scale[1] != 1) {
				
				let temp_canvas = this.canvas.cloneNode() as HTMLCanvasElement;
				let temp_canvas_ctx = temp_canvas.getContext('2d');
				temp_canvas_ctx.drawImage(this.canvas, 0, 0);
	
				Undo.initEdit({layers: [this], bitmap: true});
	
				this.canvas.width = Math.round(this.canvas.width * this.scale[0]);
				this.canvas.height = Math.round(this.canvas.height * this.scale[1]);
				this.ctx.imageSmoothingEnabled = false;
				this.ctx.drawImage(temp_canvas, 0, 0, this.canvas.width, this.canvas.height);
				this.scale.V2_set(1, 1);
	
				this.texture.updateLayerChanges(true);
				TextureLayer.selected.in_limbo = false;
				Undo.finishEdit('Place selection as layer');

			} else {
				TextureLayer.selected.in_limbo = false;
			}
		} else {
			if (this.texture.flags.has('temporary_layers') && this.texture.layers.length == 2) {
				Undo.initEdit({textures: [this.texture], bitmap: true});
				TextureLayer.selected.mergeDown(false);
				this.texture.layers_enabled = false;
				this.texture.selected_layer = null;
				this.texture.layers.empty();
				Undo.finishEdit('Disable layers on texture');
				UVEditor.vue.layer = null;
				updateInterfacePanels();
				BARS.updateConditions();
			} else {
				TextureLayer.selected.mergeDown(true);
			}
		}
		this.texture.flags.delete('temporary_layers');
		UVEditor.vue.$forceUpdate();
		Texture.selected.selection.clear();
		UVEditor.updateSelectionOutline();
		Interface.removeSuggestedModifierKey('alt', 'modifier_actions.drag_to_duplicate');
	}
	/**
	 * Set the layer size. This resizes the canvas, which discards the layer content
	 */
	setSize(width: number, height: number): this {
		this.canvas.width = width;
		this.canvas.height = height;
		return this;
	}
	/**
	 * Toggle layer visibility. This creates an undo point
	 */
	toggleVisibility(): this {
		Undo.initEdit({layers: [this]});
		this.visible = !this.visible;
		this.texture.updateChangesAfterEdit();
		Undo.finishEdit('Toggle layer visibility');
		return this;
	}
	/**
	 * Merge this texture onto the texture below
	 * @param undo Create an undo entry
	 */
	mergeDown(undo: boolean = true): void {
		let down_layer = this.texture.layers[this.texture.layers.indexOf(this) - 1];
		if (down_layer instanceof TextureLayer == false) {
			this.in_limbo = false;
			return;
		}

		if (undo) {
			Undo.initEdit({textures: [this.texture], bitmap: true});
		}
		if (this.blend_mode == 'alpha_mask') {
			let opacity_factor = this.opacity / 100;
			let mask = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
			let target = down_layer.ctx.getImageData(0, 0, down_layer.canvas.width, down_layer.canvas.height);
			for (let y = 0; y < down_layer.canvas.height; y++) {
				let mask_y = y + down_layer.offset[1] - this.offset[1];
				if (mask_y < 0 || mask_y >= this.canvas.height) continue;
				for (let x = 0; x < down_layer.canvas.width; x++) {
					let mask_x = x + down_layer.offset[0] - this.offset[0];
					if (mask_x < 0 || mask_x >= this.canvas.width) continue;
					let value = mask.data[(mask_y * this.canvas.width + mask_x) * 4];
					target.data[(y * down_layer.canvas.width + x) * 4 + 3] *= (value / 255) * opacity_factor;
				}
			}
			down_layer.ctx.putImageData(target, 0, 0);
		} else {
			down_layer.expandTo(this.offset, this.offset.slice().V2_add(this.width, this.height));
			down_layer.ctx.imageSmoothingEnabled = false;
			down_layer.ctx.filter = `opacity(${this.opacity / 100})`;
			down_layer.ctx.globalCompositeOperation = Painter.getBlendModeCompositeOperation(this.blend_mode);

			down_layer.ctx.drawImage(this.canvas, this.offset[0] - down_layer.offset[0], this.offset[1] - down_layer.offset[1], this.scaled_width, this.scaled_height);

			down_layer.ctx.filter = '';
			down_layer.ctx.globalCompositeOperation = 'source-over';
		}

		let index = this.texture.layers.indexOf(this);
		this.texture.layers.splice(index, 1);
		if (this.texture.selected_layer == this) {
			let select_next = this.texture.layers[index-1] || this.texture.layers[index];
			if (select_next) select_next.select();
		}
		if (undo) {
			this.texture.updateChangesAfterEdit();
			Undo.finishEdit('Merge layers');
		}
	}
	/**
	 * Expand the layer to include the listed pixels
	 * @param points
	 */
	expandTo(...points: ArrayVector2[]): void {
		let min = this.offset.slice();
		let max = this.offset.slice().V2_add(this.width, this.height);
		points.forEach(point => {
			point = [
				Math.clamp(Math.round(point[0]), 0, this.texture.width),
				Math.clamp(Math.round(point[1]), 0, this.texture.height),
			]
			min[0] = Math.min(min[0], point[0]);
			min[1] = Math.min(min[1], point[1]);
			max[0] = Math.max(max[0], point[0]);
			max[1] = Math.max(max[1], point[1]);
		});
		if (min[0] < this.offset[0] || min[1] < this.offset[1] || max[0] > this.offset[0]+this.width || max[1] > this.offset[1]+this.height) {
			let copy_canvas = Painter.copyCanvas(this.canvas);
			this.canvas.width = max[0] - min[0];
			this.canvas.height = max[1] - min[1];
			this.ctx.drawImage(copy_canvas, this.offset[0] - min[0], this.offset[1] - min[1]);
			this.offset.replace(min);
		}
	}
	/**
	 * Flip the texture along an axis
	 * @param axis Flip axis, where 0 is X and 1 is Y
	 * @param undo Create an undo entry
	 */
	flip(axis: 0 | 1 = 0, undo: boolean): void {
		let temp_canvas = this.canvas.cloneNode() as HTMLCanvasElement;
		let temp_canvas_ctx = temp_canvas.getContext('2d');
		temp_canvas_ctx.drawImage(this.canvas, 0, 0);

		if (undo) Undo.initEdit({layers: [this], bitmap: true});

		this.ctx.save();
		this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
		if (axis == 0) {
			this.ctx.translate(this.canvas.width, 0);
			this.ctx.scale(-1, 1);
			this.ctx.drawImage(temp_canvas, this.canvas.width, 0, -this.canvas.width, this.canvas.height);
		} else {
			this.ctx.translate(0, this.canvas.height);
			this.ctx.scale(1, -1);
			this.ctx.drawImage(temp_canvas, 0, this.canvas.height, this.canvas.width, -this.canvas.height);
		}
		this.ctx.restore();

		if (undo) {
			Undo.finishEdit('Flip layer');
			this.texture.updateChangesAfterEdit();
		} else {
			this.texture.updateLayerChanges();
			this.texture.saved = false;
		}
	}
	/**
	 * Rotate the layer around itself in 90 degree steps
	 * @param angle Angle in degrees
	 * @param undo Create an undo entry
	 */
	rotate(angle: number = 90, undo: boolean): void {
		let temp_canvas = this.canvas.cloneNode() as HTMLCanvasElement;
		let temp_canvas_ctx = temp_canvas.getContext('2d');
		temp_canvas_ctx.drawImage(this.canvas, 0, 0);

		if (undo) Undo.initEdit({layers: [this], bitmap: true});

		[this.canvas.width, this.canvas.height] = [this.canvas.height, this.canvas.width];
		this.ctx.save();
		this.ctx.translate(this.canvas.width/2,this.canvas.height/2);
		this.ctx.rotate(Math.degToRad(angle));
		this.ctx.drawImage(temp_canvas,-temp_canvas.width/2,-temp_canvas.height/2);
		this.ctx.restore();

		if (undo) {
			Undo.finishEdit('Rotate layer');
			this.texture.updateChangesAfterEdit();
		} else {
			this.texture.updateLayerChanges();
			this.texture.saved = false;
		}
		UVEditor.vue.$forceUpdate();
	}
	/**
	 * Centers the layer on the texture
	 */
	center(): void {
		this.offset[0] = Math.round(Math.max(0, this.texture.width  - this.width ) / 2);
		this.offset[1] = Math.round(Math.max(0, this.texture.height - this.height) / 2);
		this.texture.updateLayerChanges();
	}
	/**
	 * Open the properties dialog
	 */
	propertiesDialog(): void {
		let blend_mode_options = {};
		TextureLayer.properties.blend_mode.enum_values.forEach(mode => {
			blend_mode_options[mode] = `action.blend_mode.${mode}`
		});
		let opacity_range = settings.opacity_range.value == '255' ? 255 : 100;
		let dialog = new Dialog({
			id: 'layer_properties',
			title: `${this.name} (${this.width}x${this.height})`,
			form: {
				name: {label: 'generic.name', value: this.name},
				opacity: {label: 'action.layer_opacity', type: 'range', value: Math.round(this.opacity / 100 * opacity_range), min: 0, max: opacity_range},
				blend_mode: {label: 'action.blend_mode', type: 'select', value: this.blend_mode, options: blend_mode_options},
			},
			onConfirm: form_data => {
				dialog.hide().delete();
				form_data.opacity = form_data.opacity / opacity_range * 100;
				if (
					form_data.name != this.name
					|| !Math.epsilon(form_data.opacity, this.opacity, 0.2)
					|| form_data.blend_mode != this.blend_mode
				) {
					Undo.initEdit({layers: [this]});
					this.extend(form_data);
					this.texture.updateChangesAfterEdit();
					Blockbench.dispatchEvent('edit_layer_properties', {layer: this});
					Undo.finishEdit('Edit layer properties');
					(BarItems.layer_opacity as NumSlider).update();
				}
			},
			onCancel() {
				dialog.hide().delete();
			}
		})
		dialog.show();
	}

	/**
	 * Get all layers of the active texture
	 */
	static all: TextureLayer[] = []
	/**
	 * Get the selected layer
	 */
	static selected: TextureLayer | null = null
}
TextureLayerItem.registerType('pixel_layer', TextureLayer);
TextureLayer.prototype.menu = new Menu([
	new MenuSeparator('settings'),
	'layer_blend_mode',
	new MenuSeparator('edit'),
	{id: 'transform', name: 'menu.transform', icon: 'transform', children: [
		'flip_texture_x',
		'flip_texture_y',
		'rotate_texture_cw',
		'rotate_texture_ccw',
	]},
	'crop_layer_to_selection',
	'layer_to_texture_size',
	'merge_layer_down',
	new MenuSeparator('copypaste'),
	'copy',
	'duplicate',
	'delete',
	new MenuSeparator('properties'),
	{
		icon: 'list',
		name: 'menu.texture.properties',
		click(layer) { layer.propertiesDialog()}
	}
	/**
	 * Merge
	 * Copy
	 * Duplicate
	 * Delete
	 */
])
new Property(TextureLayer, 'string', 'name', {default: 'layer'});
new Property(TextureLayer, 'string', 'parent_uuid');
new Property(TextureLayer, 'vector2', 'offset');
new Property(TextureLayer, 'vector2', 'scale', {default: [1, 1]});
new Property(TextureLayer, 'number', 'opacity', {default: 100});
new Property(TextureLayer, 'boolean', 'visible', {default: true});
new Property(TextureLayer, 'enum', 'blend_mode', {default: 'default', values: ['default', 'set_opacity', 'color', 'multiply', 'add', 'darken', 'lighten', 'screen', 'overlay', 'difference', 'alpha_mask']});
new Property(TextureLayer, 'boolean', 'in_limbo', {default: false});

Object.defineProperty(TextureLayer, 'all', {
	get() {
		return Texture.selected?.layers_enabled ? Texture.selected.layers.filter(l => l instanceof TextureLayer) : [];
	}
})
Object.defineProperty(TextureLayer, 'selected', {
	get() {
		let layer = Texture.selected?.selected_layer;
		if (layer instanceof TextureLayer) return Texture.selected?.selected_layer;
	}
})


export interface TextureLayerGroupData {
	name?: string
	folded?: boolean
}
export type TextureLayerHierarchy = (TextureLayerGroupData|string)[]
export class TextureLayerGroup extends TextureLayerItem {
	folded: boolean
	public type = 'layer_group'
	static properties: Record<string, Property<any>>

	constructor(data: TextureLayerGroupData, texture?: Texture, uuid?: UUID) {
		super(data, texture, uuid);
		for (let key in TextureLayer.properties) {
			TextureLayer.properties[key].reset(this);
		}
		this.extend(data);
	}
	get children(): TextureLayerItem[] {
		return this.texture.layers.filter(l => l.parent_uuid == this.uuid);
	}
	extend(data: TextureLayerGroupData) {
		for (let key in TextureLayer.properties) {
			TextureLayer.properties[key].merge(this, data)
		}
	}
	getUndoCopy(): TextureLayerGroupData {
		let data: any = {
			texture: this.texture.uuid,
			type: this.type,
			name: this.name,
			uuid: this.uuid,
			folded: this.folded
		};
		for (let key in TextureLayerGroup.properties) {
			TextureLayerGroup.properties[key].copy(this, data);
		}

		return data;
	}
	getSaveCopy() {
		return this.getUndoCopy();
	}
	getAllChildren(): TextureLayerItem[] {
		let list = [];
		for (let layer of this.texture.layers) {
			if (layer.parent_uuid != this.uuid || layer == this) continue;
			list.safePush(layer);
			if (layer instanceof TextureLayerGroup) {
				list.safePush(...layer.getAllChildren());
			}
		}
		return list;
	}
	/**
	 * Selects the layer
	 */
	select(multi_select?: boolean) {
		super.select(multi_select);

		UVEditor.vue.layer = this.texture.getActiveLayer();

		let selectChildren = (group: TextureLayerGroup) => {
			let children = group.children;
			for (let child of children) {
				child.multi_selected = true;
				if (child instanceof TextureLayerGroup) selectChildren(child);
			}
		}
		selectChildren(this);
	}
	/**
	 * Toggle layer groupvisibility. This creates an undo point
	 */
	toggleVisibility(): this {
		let layers = this.getAllChildren();
		let first = layers.find(layer => 'toggleVisibility' in layer) as TextureLayer;
		if (!first) return;
		Undo.initEdit({layers});
		let value = !first.visible;
		for (let layer of layers) {
			if ('visible' in layer) {
				layer.visible = value;
			}
		}
		this.visible = value;
		this.texture.updateChangesAfterEdit();
		Undo.finishEdit('Toggle layer visibility');
		return this;
	}
	/**
	 * Open the properties dialog
	 */
	propertiesDialog(): void {
		let dialog = new Dialog({
			id: 'layer_properties',
			title: this.name,
			form: {
				name: {label: 'generic.name', value: this.name},
			},
			onConfirm: form_data => {
				dialog.hide().delete();
				if (
					form_data.name != this.name
				) {
					Undo.initEdit({layers: [this]});
					this.extend(form_data);
					this.texture.updateChangesAfterEdit();
					Blockbench.dispatchEvent('edit_layer_properties', {layer: this});
					Undo.finishEdit('Edit layer group properties');
				}
			},
			onCancel() {
				dialog.hide().delete();
			}
		})
		dialog.show();
	}
}
TextureLayerItem.registerType('layer_group', TextureLayerGroup);
new Property(TextureLayerGroup, 'string', 'name', {default: 'layer'});
new Property(TextureLayerGroup, 'boolean', 'folded');
new Property(TextureLayerGroup, 'string', 'parent_uuid');
new Property(TextureLayerGroup, 'boolean', 'visible', {default: true});
TextureLayerGroup.prototype.menu = new Menu([
	new MenuSeparator('edit'),
	{id: 'transform', name: 'menu.transform', icon: 'transform', children: [
		'flip_texture_x',
		'flip_texture_y',
		'rotate_texture_cw',
		'rotate_texture_ccw',
	]},
	new MenuSeparator('copypaste'),
	'copy',
	'duplicate',
	'resolve_layer_group',
	'delete',
	new MenuSeparator('properties'),
	{
		icon: 'list',
		name: 'menu.texture.properties',
		click(layer) { layer.propertiesDialog()}
	}
])


SharedActions.add('delete', {
	subject: 'layer',
	condition: () => Prop.active_panel == 'layers' && !!Texture.selected?.selected_layer,
	run() {
		if (Texture.selected.layers.length >= 2) {
			Texture.selected?.selected_layer.remove(true);
		}
	}
})
SharedActions.add('delete', {
	subject: 'layer_priority',
	condition: () => Texture.selected?.selected_layer instanceof TextureLayer && Texture.selected?.selected_layer.in_limbo,
	priority: 2,
	run() {
		if (Texture.selected.layers.length >= 2) {
			Texture.selected?.selected_layer.remove(true);
		}
		Texture.selected.selection.clear()
		UVEditor.updateSelectionOutline()
	}
})
SharedActions.add('duplicate', {
	subject: 'layer',
	condition: () => Prop.active_panel == 'layers' && !!Texture.selected?.selected_layer,
	run() {
		let texture = Texture.selected;
		let original = texture.selected_layer!;
		let copy = original.getUndoCopy(true);
		copy.name += '-copy';
		Undo.initEdit({textures: [texture], bitmap: true});
		let constructor = TextureLayerItem.types[original.type] || TextureLayer;
		let layer = new constructor(copy, texture);
		layer.addForEditing();
		texture.updateLayerChanges(true);
		Undo.finishEdit('Duplicate layer');
	}
})
SharedActions.add('copy', {
	subject: 'layer',
	condition: () => Prop.active_panel == 'layers' && !!TextureLayer.selected,
	run() {
		let layer = TextureLayer.selected;
		let copy = layer.getUndoCopy(true);
		Clipbench.layer = copy;
	}
})
SharedActions.add('paste', {
	subject: 'layer',
	condition: () => Prop.active_panel == 'layers' && Texture.selected && !!Clipbench.layer,
	run() {
		let texture = Texture.selected;
		Undo.initEdit({textures: [texture], bitmap: true});
		if (!texture.layers_enabled) texture.activateLayers(false);
		let layer = new TextureLayer(Clipbench.layer, texture);
		layer.addForEditing();
		texture.updateLayerChanges(true);
		Undo.finishEdit('Paste layer');
	}
})

BARS.defineActions(() => {
	new Action('create_empty_layer', {
		icon: 'new_window',
		category: 'layers',
		condition: () => Modes.paint && Texture.all.length > 0,
		click() {
			if (!Texture.selected) Texture.all[0].select();
			let texture = Texture.selected;
			Undo.initEdit({textures: [texture], bitmap: true});
			if (!texture.layers_enabled) texture.activateLayers(false);
			let layer = new TextureLayer({
				name: `layer #${texture.layers.length+1}`
			}, texture);
			layer.setSize(texture.width, texture.height);
			layer.addForEditing();
			Undo.finishEdit('Create empty layer');
			BARS.updateConditions();
		}
	})
	new Action('import_layer', {
		icon: 'add_photo_alternate',
		category: 'layers',
		condition: () => Modes.paint && Texture.all.length > 0,
		click() {
			if (!Texture.selected) Texture.all[0].select();
			let texture = Texture.selected;
			if (!texture.layers_enabled) texture.activateLayers(true);

			let start_path: string;
			if (!isApp) {} else
			if (Texture.all.length > 0) {
				let arr = Texture.all[0].path.split(osfs)
				arr.splice(-1)
				start_path = arr.join(osfs)
			} else if (Project.export_path) {
				let arr = Project.export_path.split(osfs)
				arr.splice(-3)
				arr.push('textures')
				start_path = arr.join(osfs)
			}
			let extensions = [];
			for (let key in Texture.file_formats) {
				if (Texture.file_formats[key].decode) continue; // Custom decode function means they are not supported by HTML images
				extensions.safePush(...Texture.file_formats[key].extensions);
			}
			Blockbench.import({
				resource_id: 'texture',
				readtype: 'image',
				type: 'Image File',
				extensions,
				multiple: true,
				startpath: start_path
			}, async (files) => {
				let texture = Texture.selected;
				Undo.initEdit({textures: [texture], bitmap: true});

				for (let file of files) {
					let img = new Image();
					await new Promise((resolve, reject) => {
						img.src = Filesystem.getImageSource(file);
						img.onload = resolve;
						img.onerror = reject;
					})
					let frame = new CanvasFrame(img);
					let layer = new TextureLayer({name: file.name, offset: [0, 0]}, texture);
					let image_data = frame.ctx.getImageData(0, 0, frame.width, frame.height);
					layer.setSize(frame.width, frame.height);
					layer.ctx.putImageData(image_data, 0, 0);
					texture.layers.push(layer);
					layer.center();
					if (file == files.last()) {
						layer.select();
						layer.setLimbo();
					}
				}
				texture.updateLayerChanges(true);
				Undo.finishEdit('Add image as layer');
				updateInterfacePanels();
				BARS.updateConditions();
				(BarItems.move_layer_tool as Tool).select();
			})
		}
	})
	new Action('create_layer_group', {
		icon: 'files',
		category: 'layers',
		condition: () => Modes.paint && !!Texture.selected?.selected_layer,
		click() {
			if (!Texture.selected) Texture.all[0].select();
			let texture = Texture.selected;
			Undo.initEdit({textures: [texture]});
			if (!texture.layers_enabled) texture.activateLayers(false);
			
			let group = new TextureLayerGroup({name: 'Layer Group'}, texture);
			group.parent_uuid = group.texture.selected_layer?.parent_uuid || '';
			let i = group.texture.layers.indexOf(group.texture.selected_layer);
			if (i == -1) {
				group.texture.layers.push(group);
			} else {
				group.texture.layers.splice(i+1, 0, group);
			}
			for (let layer of group.texture.layers) {
				if (layer == group || !layer.selected) continue;
				layer.parent_uuid = group.uuid;
			}
			group.select();
			Undo.finishEdit('Create layer group');
		}
	})
	new Action('resolve_layer_group', {
		icon: 'fa-leaf',
		category: 'layers',
		condition: () => (
			Modes.paint &&
			Texture.selected?.layers_enabled &&
			Texture.selected.layers.some(l => l.selected && l instanceof TextureLayerGroup)
		),
		click() {
			if (!Texture.selected) Texture.all[0].select();
			let texture = Texture.selected;
			Undo.initEdit({textures: [texture]});
			
			let groups = texture.layers.filter(l => l.selected && l instanceof TextureLayerGroup && !l.parent?.selected);
			for (let group of groups) {
				for (let layer of texture.layers) {
					if (layer.parent_uuid == group.uuid) {
						layer.parent_uuid = group.parent_uuid;
					}
				}
				group.remove(false);
			}


			Undo.finishEdit('Resolve layer group');
		}
	})
	let getTexture = () => Texture.selected || Texture.getDefault();
	new Action('enable_texture_layers', {
		icon: 'library_add_check',
		category: 'layers',
		condition: () => getTexture()?.layers_enabled == false,
		click() {
			if (!Modes.paint) {
				Modes.options.paint.select();
			}
			let texture = getTexture();
			texture.activateLayers(true);
		}
	})
	new Action('disable_texture_layers', {
		icon: 'layers_clear',
		category: 'layers',
		condition: () => Texture.selected && Texture.selected.layers_enabled,
		click() {
			let texture = Texture.selected;
			Undo.initEdit({textures: [texture], bitmap: true});
			texture.layers_enabled = false;
			texture.selected_layer = null;
			texture.layers.empty();
			Undo.finishEdit('Disable layers on texture');
			UVEditor.vue.layer = null;
			updateInterfacePanels();
			BARS.updateConditions();
		}
	})
	new NumSlider('layer_opacity', {
		category: 'layers',
		condition: () => Modes.paint && Texture.selected && Texture.selected.layers_enabled && !!Texture.selected.getActiveLayer(),
		settings: {
			min: 0,
			get max() {return settings.opacity_range.value == '255' ? 255 : 100},
			get default() {return settings.opacity_range.value == '255' ? 255 : 100},
			show_bar: true
		},
		getInterval(event) {
			if (event.ctrlOrCmd || Pressing.overrides.ctrl) return 1;
			return settings.opacity_range.value == '255' ? 4 : 2;
		},
		get() {
			let opacity_range = settings.opacity_range.value == '255' ? 255 : 100;
			let value = Texture.selected.getActiveLayer().opacity ?? 100;
			return Math.roundTo(value / 100 * opacity_range, 0);
		},
		change(modify) {
			let opacity_range = settings.opacity_range.value == '255' ? 255 : 100;
			let layer = Texture.selected.getActiveLayer();
			let new_value = modify(layer.opacity / 100 * opacity_range);
			layer.opacity = Math.roundTo(Math.clamp(new_value / opacity_range * 100, 0, 100), 4);
			Texture.selected.updateLayerChanges();
		},
		onBefore() {
			Undo.initEdit({layers: [Texture.selected.getActiveLayer()]});
		},
		onAfter() {
			Undo.finishEdit('Change layer opacity');
			Texture.selected.updateChangesAfterEdit();
		}
	})
	let blend_mode_options = {};
	TextureLayer.properties.blend_mode.enum_values.forEach(mode => {
		blend_mode_options[mode] = `action.blend_mode.${mode}`;
	})
	new BarSelect('layer_blend_mode', {
		name: 'action.blend_mode',
		category: 'animation',
		condition: () => Modes.paint && !!TextureLayer.selected,
		options: blend_mode_options,
		onChange(sel) {
			let mode = sel.value as LayerBlendMode;
			let layer = TextureLayer.selected;
			Undo.initEdit({layers: [layer]});
			layer.blend_mode = mode;
			layer.texture.updateChangesAfterEdit();
			Undo.finishEdit('Change layer blend mode');
		}
	})
	new Action('layer_to_texture_size', {
		icon: 'fit_screen',
		category: 'layers',
		condition: () => !!TextureLayer.selected,
		click() {
			let layer = TextureLayer.selected;
			Undo.initEdit({layers: [layer], bitmap: true});

			let copy = Painter.copyCanvas(layer.canvas);
			layer.canvas.width = layer.texture.width;
			layer.canvas.height = layer.texture.height;
			layer.ctx.drawImage(copy, layer.offset[0], layer.offset[1]);
			layer.offset.V2_set(0, 0);

			Undo.finishEdit('Expand layer to texture size');
			layer.texture.updateLayerChanges(true);
		}
	})
	new Action('merge_layer_down', {
		icon: 'fa-caret-square-down',
		category: 'layers',
		condition: () => !!TextureLayer.selected,
		click() {
			TextureLayer.selected.mergeDown(true);
		}
	})
	
	new Action('crop_layer_to_selection', {
		icon: 'crop',
		category: 'layers',
		condition: () => !!TextureLayer.selected,
		click() {
			let layer = TextureLayer.selected;
			let rect = layer.texture.selection.getBoundingRect();
			if (!rect.width || !rect.height) return;

			Undo.initEdit({layers: [layer], bitmap: true});

			let copy = Painter.copyCanvas(layer.canvas)
			layer.canvas.width = rect.width;
			layer.canvas.height = rect.height;
			layer.ctx.drawImage(copy, layer.offset[0]-rect.start_x, layer.offset[1]-rect.start_y);
			layer.offset.V2_set(rect.start_x, rect.start_y);

			layer.texture.updateChangesAfterEdit();

			Undo.finishEdit('Crop layer to selection');
		}
	})
})

Interface.definePanels(function() {
	Vue.component('texture-layer-icon', {
		props: {
			layer: TextureLayer
		},
		template: '<div class="layer_icon_wrapper checkerboard"></div>',
		mounted() {
			this.$el.append(this.layer.canvas);
		}
	})
	function eventTargetToLayer(target: Element, texture: Texture): [TextureLayerItem, Element] | [] {
		let target_node = target;
		let i = 0;
		while (target_node && target_node.classList && !target_node.classList.contains('texture_layer')) {
			if (i < 3 && target_node) {
				target_node = target_node.parentNode as Element;
				i++;
			} else {
				return [];
			}
		}
		return [texture.layers.find(layer => layer.uuid == target_node.getAttribute('layer_id')), target_node];
	}
	type LayerPanelVue = {
		layers: TextureLayerItem[]
	}
	new Panel('layers', {
		icon: 'layers',
		growable: true,
		resizable: true,
		condition: () => Modes.paint,
		default_position: {
			attached_to: 'textures',
			attached_index: 1,
			slot: 'left_bar',
			float_position: [0, 0],
			float_size: [300, 300],
			height: 300,
			sidebar_index: 5,
		},
		mode_positions: {
			paint_2d: {
				slot: 'right_bar',
				sidebar_index: 7,
			}
		},
		toolbars: [
			new Toolbar('layers', {
				children: [
					'create_empty_layer',
					'import_layer',
					'enable_texture_layers',
					'create_layer_group',
					'layer_opacity',
					'layer_blend_mode'
				]
			})
		],
		component: {
			name: 'panel-layers',
			data() { return {
				layers: [],
			}},
			methods: {
				openMenu(this: LayerPanelVue, event) {
					Interface.Panels.layers.menu.show(event)
				},
				dragLayer(this: LayerPanelVue, e1) {
					if (getFocusedTextInput()) return;
					if (e1.button == 1 || e1.button == 2) return;
					convertTouchEvent(e1);

					let texture = Texture.selected;
					if (!texture) return;
					let [layer] = eventTargetToLayer(e1.target, texture);
					if (!layer) return;

					let active = false;
					let helper: HTMLDivElement;
					let timeout;
					let drop_target: TextureLayerItem;
					let drop_target_node: Element;
					let target_is_list = false;
					let order;
					let last_event = e1;

					function getOrder(loc: number, obj: TextureLayerItem, height: number = 40) {
						if (!obj) return;
						if (loc < height*0.3) return -1;
						if (loc > height*0.7) return 1;
						return 0;
					}

					function move(e2) {
						convertTouchEvent(e2);
						let offset = [
							e2.clientX - e1.clientX,
							e2.clientY - e1.clientY,
						]
						if (!active) {
							let distance = Math.sqrt(Math.pow(offset[0], 2) + Math.pow(offset[1], 2))
							if (Blockbench.isTouch) {
								if (distance > 20 && timeout) {
									clearTimeout(timeout);
									timeout = null;
								} else {
									document.getElementById('layers_list').scrollTop += last_event.clientY - e2.clientY;
								}
							} else if (distance > 6) {
								active = true;
							}
						} else {
							if (e2) e2.preventDefault();
							
							if (Menu.open) Menu.open.hide();

							if (!helper) {
								helper = document.createElement('div');
								helper.id = 'animation_drag_helper';
								let icon = document.createElement('i');		icon.className = 'material-icons'; icon.innerText = 'image'; helper.append(icon);
								let span = document.createElement('span');	span.innerText = layer.name;	helper.append(span);
								document.body.append(helper);
							}
							helper.style.left = `${e2.clientX}px`;
							helper.style.top = `${e2.clientY}px`;

							// drag
							$('.drag_hover').removeClass('drag_hover');
							$('.texture_layer[order]').attr('order', null);
							target_is_list = false;

							let target = document.elementFromPoint(e2.clientX, e2.clientY);
							[drop_target, drop_target_node] = eventTargetToLayer(target, texture);
							if (drop_target) {
								let location = e2.clientY - $(drop_target_node).offset().top;
								order = getOrder(location, drop_target, drop_target_node.clientHeight);
							} else if (target?.id == 'layers_list') {
								drop_target = texture.layers[0];
								drop_target_node = document.querySelector(`.texture_layer[layer_id="${drop_target.uuid}"]`);
								order = 1;
								target_is_list = true;
							}
							if (drop_target_node) {
								drop_target_node.setAttribute('order', order);
								drop_target_node.classList.add('drag_hover');
							}
						}
						last_event = e2;
					}
					function off(e2: MouseEvent) {
						if (helper) helper.remove();
						removeEventListeners(document, 'mousemove touchmove', move);
						removeEventListeners(document, 'mouseup touchend', off);
						$('.drag_hover').removeClass('drag_hover');
						$('.texture_layer[order]').attr('order', null);
						if (Blockbench.isTouch) clearTimeout(timeout);

						function layerIsChildOf(child_layer: TextureLayerItem, parent_layer: TextureLayerItem): boolean {
							let parent = child_layer.parent;
							let i = 0;
							while (parent) {
								if (parent == parent_layer || parent == child_layer) return true;
								parent = parent.parent;
								i++;
								if (i > 20) break;
							}
							return false;
						}

						if (active && !Menu.open) {
							convertTouchEvent(e2);
							let target_layer = drop_target;
							if (!target_layer || layerIsChildOf(target_layer, layer) ) return;
							if (target_layer == layer && !target_is_list) return;

							let index = texture.layers.indexOf(target_layer);

							if (index == -1) return;
							if (texture.layers.indexOf(layer) < index) index--;
							if (order == -1) index++;
							
							Undo.initEdit({textures: [texture]});

							texture.layers.remove(layer);
							texture.layers.splice(index, 0, layer);

							if (order == 0) {
								if (target_layer instanceof TextureLayerGroup) {
									layer.parent_uuid = target_layer.uuid;
								} else {
									let group = new TextureLayerGroup({name: 'Layer Group'}, texture);
									group.parent_uuid = target_layer.parent_uuid;
									texture.layers.splice(index, 0, group);
									layer.parent_uuid = group.uuid;
									target_layer.parent_uuid = group.uuid;
								}
							} else if (target_is_list) {
								layer.parent_uuid = '';
							} else {
								layer.parent_uuid = target_layer.parent_uuid;
							}

							texture.layers.replace(TextureLayerItem.solveLayerOrder(texture.layers));
							texture.updateChangesAfterEdit();
							Undo.finishEdit('Reorder layers');
						}
					}

					if (Blockbench.isTouch) {
						timeout = setTimeout(() => {
							active = true;
							move(e1);
						}, 320)
					}

					addEventListeners(document, 'mousemove touchmove', move, {passive: false});
					addEventListeners(document, 'mouseup touchend', off, {passive: false});
				},
				activateLayers(this: LayerPanelVue, ) {
					let texture = Texture.selected || Texture.getDefault();
					if (!texture) return;
					if (!texture.selected) texture.select();
					if (!texture.layers_enabled) {
						BarItems.enable_texture_layers.trigger();
					}
				}
			},
			computed: {
				displayedLayers(this: LayerPanelVue) {
					let isDisplayed = (layer: TextureLayerItem): boolean => {
						let parent = layer.parent;
						if (parent) {
							return !parent.folded && isDisplayed(parent);
						} else {
							return true;
						}

					}
					return this.layers.filter(isDisplayed);
				}
			},
			template: `
				<ul
					id="layers_list"
					class="list mobile_scrollbar"
					@contextmenu.stop.prevent="openMenu($event)"
					@mousedown="dragLayer($event)"
					@touchstart="dragLayer($event)"
				>
					<li
						v-for="layer in displayedLayers"
						:class="{ selected: layer.selected, in_limbo: layer.in_limbo }"
						:key="layer.uuid"
						:layer_id="layer.uuid"
						:layer_type="layer.type"
						class="texture_layer"
						:style="{'--indentation': layer.getDepth()}"
						@click.stop="layer.clickSelect($event)"
						@dblclick.stop="layer.propertiesDialog()"
						@contextmenu.prevent.stop="layer.showContextMenu($event)"
					>
						<texture-layer-icon v-if="layer.type == 'pixel_layer'" :layer="layer" />

						<i
							v-if="layer.type == 'layer_group'"
							@click.stop="layer.folded = !layer.folded" class="icon-open-state fa"
							@dblclick.stop
							:class='{"fa-angle-right": layer.folded, "fa-angle-down": !layer.folded}'
						></i>

						<label>
							{{ layer.name }}
						</label>

						<div v-if="'toggleVisibility' in layer" class="in_list_button" @click.stop="layer.toggleVisibility()" @dblclick.stop>
							<i v-if="layer.visible" class="material-icons icon">visibility</i>
							<i v-else class="material-icons icon toggle_disabled">visibility_off</i>
						</div>
					</li>
					<div v-if="layers.length == 0" class="activate_layers_button" @click="activateLayers()">
						<span>${tl('action.enable_texture_layers')}</span>
					</div>
				</ul>
			`
		},
		menu: new Menu([
			'create_empty_layer',
			'import_layer',
			'create_layer_group',
		])
	})
})

const global = {
	TextureLayer,
	TextureLayerGroup,
	TextureLayerItem,
};
declare global {
	const TextureLayer: typeof global.TextureLayer
	type TextureLayer = import('./layers').TextureLayer
	const TextureLayerGroup: typeof global.TextureLayerGroup
	type TextureLayerGroup = import('./layers').TextureLayerGroup
	const TextureLayerItem: typeof global.TextureLayerItem
	type TextureLayerItem = import('./layers').TextureLayerItem
    interface BarItemRegistry {
		layer_opacity: NumSlider
		layer_blend_mode: BarSelect
		selection_tool: Tool
		create_empty_layer: Action
		import_layer: Action
		enable_texture_layers: Action
		disable_texture_layers: Action
		layer_to_texture_size: Action
		merge_layer_down: Action
		crop_layer_to_selection: Action
    }
}
Object.assign(window, global);
