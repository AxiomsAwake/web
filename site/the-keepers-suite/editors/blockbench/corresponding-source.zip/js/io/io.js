import { Filesystem } from "../file_system";
import { shell } from "../native_apis";
import { Extruder } from './extrude_image'

//Import
export function setupDragHandlers() {
	Blockbench.addDragHandler(
		'texture',
		{
			extensions: Texture.getAllExtensions,
			propagate: true,
			readtype: 'image',
			condition: () => !Dialog.open
		},
		function(files, event) {
			loadImages(files, event)
		}
	)
	Blockbench.addDragHandler(
		'texture_set',
		{extensions: ['texture_set.json'], propagate: true, readtype: 'image', condition: () => Format.pbr && !Dialog.open},
		function(files, event) {
			importTextureSet(files[0]);
		}
	)
	Blockbench.addDragHandler(
		'reference_image',
		{extensions: ReferenceImage.supported_extensions, propagate: true, readtype: 'image', condition: () => Project && !Dialog.open},
		function(files, event) {
			ReferenceImageMode.importReferences(files);
		}
	)
	Blockbench.addDragHandler(
		'model',
		{extensions: Codec.getAllExtensions},
		function(files) {
			files.forEach(file => {
				loadModelFile(file);
			})
		}
	)
	Blockbench.addDragHandler(
		'style',
		{extensions: ['bbtheme']},
		function(files) {
			CustomTheme.import(files[0]);
		}
	)
	Blockbench.addDragHandler(
		'settings',
		{extensions: ['bbsettings']},
		function(files) {
			Settings.import(files[0]);
		}
	)
	Blockbench.addDragHandler(
		'plugin',
		{extensions: ['bbplugin', 'js']},
		function(files) {
			files.forEach(file => {
				new Plugin().loadFromFile(file, true);
			})
		}
	)
}

export function loadModelFile(file, args) {
	
	let existing_tab = isApp && ModelProject.all.find(project => (
		project.save_path == file.path || project.export_path == file.path
	))

	let extension = pathToExtension(file.path);

	function loadIfCompatible(codec, type, content) {
		if (codec.load_filter && codec.load_filter.type == type) {
			let extensions = typeof codec.load_filter.extensions == 'function'
				? codec.load_filter.extensions()
				: codec.load_filter.extensions ?? [];
			if (extensions.includes(extension) && Condition(codec.load_filter.condition, content)) {
				if (existing_tab && !codec.multiple_per_file) {
					existing_tab.select();
				} else {
					codec.load(content, file, args);
				}
				return true;
			}
		}
	}

	// Image
	for (let id in Codecs) {
		let success = loadIfCompatible(Codecs[id], 'image', file.content);
		if (success) return;
	}
	// Text
	for (let id in Codecs) {
		let success = loadIfCompatible(Codecs[id], 'text', file.content);
		if (success) return;
	}
	// JSON
	let model = autoParseJSON(file.content, {file_path: file.path});
	for (let id in Codecs) {
		let success = loadIfCompatible(Codecs[id], 'json', model);
		if (success) return;
	}
	unsupportedFileFormatMessage(file.path);
}

export async function loadImages(files, event) {
	let options = {};
	let texture_li = event && $(event.target).parents('li.texture');
	let replace_texture;

	let img = new Image();
	await new Promise((resolve, reject) => {
		img.src = Filesystem.getImageSource(files[0]);
		img.onload = resolve;
		// TGA images will fail, should still continue
		img.onerror = resolve;
	})

	// Options
	if (event == undefined) {
		// When using "Open with > Blockbench", ensure these are listed first
		options.edit = null;
	}
	if (Project && texture_li && texture_li.length) {
		replace_texture = Texture.all.findInArray('uuid', texture_li.attr('texid'))
		if (replace_texture) {
			options.replace_texture = 'menu.texture.change';
		}
	}
	if (Project) {
		if (!Format.image_editor && Condition(Panels.textures.condition)) {
			options.texture = 'action.import_texture';
		}
		if (Modes.paint && Texture.selected) {
			options.layer = 'message.load_images.add_layer';
		}
		if (Modes.edit && (!Project.box_uv || Format.optional_box_uv)) {
			options.extrude_with_cubes = 'dialog.extrude.title';
		}
	}
	options.edit = 'message.load_images.edit_image';
	if (Project) {
		options.reference_image = 'data.reference_image';
	}
	if (img.naturalHeight == img.naturalWidth && [64, 128].includes(img.naturalWidth)) {
		options.minecraft_skin = 'format.skin';
	}
	if (Project && Condition(Panels.textures.condition)) {
		if (Format.image_editor) {
			options.texture = 'message.load_images.add_image';
		} else {
			options.texture = 'action.import_texture';
		}
	}

	function doLoadImages(method) {
		if (method == 'texture') {
			let new_textures = [];
			Undo.initEdit({textures: new_textures});
			files.forEach(function(f, i) {
				let tex = new Texture().fromFile(f).add(false, true).fillParticle();
				new_textures.push(tex);
				if (Format.image_editor && i == 0) {
					tex.select();
				}
			});
			Undo.finishEdit('Add texture');

		} else if (method == 'replace_texture') {
			replace_texture.fromFile(files[0])
			updateSelection();
			
		} else if (method == 'layer') {
			let texture = Texture.getDefault();
			let frame = new CanvasFrame(img);
			Undo.initEdit({textures: [texture], bitmap: true});
			if (!texture.layers_enabled) {
				texture.activateLayers(false);
			}
			let layer = new TextureLayer({name: files[0].name, offset: [0, 0]}, texture);
			let image_data = frame.ctx.getImageData(0, 0, frame.width, frame.height);
			layer.setSize(frame.width, frame.height);
			layer.ctx.putImageData(image_data, 0, 0);
			texture.layers.push(layer);
			layer.center();
			layer.select();
			layer.setLimbo();
			texture.updateLayerChanges(true);

			Undo.finishEdit('Add image as layer');
			updateInterfacePanels();
			BARS.updateConditions();
			BarItems.move_layer_tool.select();
			
		} else if (method == 'reference_image') {
			ReferenceImageMode.importReferences(files);
			
		} else if (method == 'edit') {
			Codecs.image.load(files, files[0].path, [img.naturalWidth, img.naturalHeight]);
			
		} else if (method == 'minecraft_skin') {
			Formats.skin.setup_dialog.show();
			Formats.skin.setup_dialog.setFormValues({
				texture_source: 'upload_texture',
				texture_file: files[0]
			})

		} else if (method == 'extrude_with_cubes') {
			Extruder.dialog.show();
			Extruder.drawImage(files[0]);
		}
	}

	let all_methods = Object.keys(options);
	if (all_methods.length == 1) {
		doLoadImages(all_methods[0]);

	} else if (all_methods.length) {
		let icons = {
			replace_texture: 'file_upload',
			texture: 'library_add',
			layer: 'new_window',
			reference_image: 'wallpaper',
			edit: 'draw',
			minecraft_skin: 'icon-player',
			extrude_with_cubes: 'eject',
		};
		let categories = {
			replace_texture: 'message.load_images.category.add_to_project',
			texture: 'message.load_images.category.add_to_project',
			layer: 'message.load_images.category.add_to_project',
			reference_image: 'message.load_images.category.add_to_project',
			edit: 'message.load_images.category.new_project',
			minecraft_skin: 'message.load_images.category.new_project',
			extrude_with_cubes: 'message.load_images.category.add_to_project',
		}
		let commands = {};
		for (let id in options) {
			if (categories[id] == 'message.load_images.category.new_project') continue;
			commands[id] = {
				text: options[id],
				icon: icons[id],
				category: categories[id],
			};
		}
		for (let id in options) {
			commands[id] = {
				text: options[id],
				icon: icons[id],
				category: categories[id],
			};
		}
		let title = tl('message.load_images.title');
		let message = `${files[0].name}`;
		if (files.length > 1) message += ` (${files.length})`;
		Blockbench.showMessageBox({
			id: 'load_images',
			commands,
			title, message,
			icon: img,
			buttons: ['dialog.cancel'],
		}, result => {
			doLoadImages(result);
		})
	}
}

export function unsupportedFileFormatMessage(file_path) {
	let extension = pathToExtension(file_path).toLowerCase();
	let supported_plugins = Plugins.all.filter(plugin => {
		return plugin.contributes?.open_extensions?.includes(extension);
	})
	let commands = {};
	for (let plugin of supported_plugins) {
		commands[plugin.id] = {
			icon: (!plugin.icon || plugin.icon.match(/\.(svg|png)/)) ? 'extension' : plugin.icon,
			text: tl('message.invalid_format.install_plugin', [plugin.title])
		}
	}
	if (isApp && file_path.match(/[\\\/]/)) {
		commands.open_in_default_program = {
			icon: 'open_in_new',
			text: 'message.unsupported_file_extension.open_in_default_program'
		}
	}
	Blockbench.showMessageBox({
		translateKey: 'unsupported_file_extension',
		message: tl('message.unsupported_file_extension.message', ['`' + pathToName(file_path, true) + '`']),
		commands,
	}, (plugin_id) => {
		if (plugin_id == 'open_in_default_program') {
			return shell.openPath(file_path);
		}
		let plugin = plugin_id && supported_plugins.find(p => p.id == plugin_id);
		if (plugin) {
			BarItems.plugins_window.click();
			Plugins.dialog.content_vue.selectPlugin(plugin);
		}
	})
}



BARS.defineActions(function() {
	//Import
	new Action('open_model', {
		icon: 'file_open',
		category: 'file',
		keybind: new Keybind({key: 'o', ctrl: true}),
		click: function () {
			var startpath;
			if (isApp && recent_projects && recent_projects.length) {
				let first_recent_project = recent_projects.find(p => !p.favorite) || recent_projects[0];
				startpath = first_recent_project.path;
				if (typeof startpath == 'string') {
					startpath = startpath.replace(/[\\\/][^\\\/]+$/, '');
				}
			}
			Blockbench.import({
				resource_id: 'model',
				extensions: Codec.getAllExtensions(),
				type: 'Model',
				readtype: file => {
					if (typeof file == 'string' && file.search(/\.png$/i) > 0) {
						return 'image'
					}},
				startpath,
				multiple: true
			}, function(files) {
				let image_extensions = Texture.getAllExtensions();
				if (files.allAre(file => image_extensions.includes(pathToExtension(file.name).toLowerCase()))) {
					loadImages(files);
				} else {
					files.forEach(file => {
						loadModelFile(file);
					});
				}
			})
		}
	})
	new Action('open_from_link', {
		icon: 'link',
		category: 'file',
		click() {
			Blockbench.textPrompt('action.open_from_link', '', link => {
				if (link.match(/https:\/\/blckbn.ch\//) || link.length == 4 || link.length == 6) {
					let code = link.replace(/\/$/, '').split('/').last();
					$.getJSON(`https://blckbn.ch/api/models/${code}`, (model) => {
						Codecs.project.load(model, {path: ''});
					}).fail(error => {
						Blockbench.showQuickMessage('message.invalid_link')
					})
				} else {
					$.getJSON(link, (model) => {
						Codecs.project.load(model, {path: ''});
					}).fail(error => {
						Blockbench.showQuickMessage('message.invalid_link')
					})
				}
			}, {placeholder: 'https://blckbn.ch/123abc'});
		}
	})
	Blockbench.on('drop_text', ({text}) => {
		if (text && text.startsWith('https://blckbn.ch/')) {
			let code = text.replace(/\/$/, '').split('/').last();
			$.getJSON(`https://blckbn.ch/api/models/${code}`, (model) => {
				Codecs.project.load(model, {path: ''});
			}).fail(error => {
				Blockbench.showQuickMessage('message.invalid_link')
			})
		}
	})
	// Smart Save
	new Action('export_over', {
		icon: 'save',
		category: 'file',
		keybind: new Keybind({key: 's', ctrl: true}),
		condition: () => Project,
		click: async function(event) {
			let export_codec = Codecs[Project.export_codec] ?? Format?.codec;
			if (isApp) {
				await saveTextures()
				if (Format) {
					if (Project.save_path) {
						Codecs.project.write(Codecs.project.compile(), Project.save_path);
					}
					if (Project.export_path && export_codec?.compile) {
						if (export_codec.id != 'image') {
							export_codec.write(export_codec.compile(), Project.export_path)
						}

					} else if (export_codec?.export && !Project.save_path) {
						if (export_codec.id === 'project' || settings.dialog_save_codec.value == false) {
							export_codec.export();

						} else {
							await new Promise(resolve => Blockbench.showMessageBox({
								translateKey: 'save_codec_selector',
								icon: 'save',
								commands: {
									project: 'message.save_codec_selector.project_file',
									[export_codec.id]: export_codec.name || 'Default Format',
									both: 'message.save_codec_selector.both',
								},
								checkboxes: {
									dont_show_again: {value: false, text: 'dialog.dontshowagain'}
								},
								buttons: ['dialog.cancel']
							}, (codec, checkboxes = {}) => {
								if (codec == 'both') {
									Codecs.project.export();
									export_codec.export();
	
								} else if (codec) {
									Codecs[codec].export();
								}
								if (checkboxes.dont_show_again) {
									settings.dialog_save_codec.set(false);
								}
								resolve();
							}));
						}
					} else if (!Project.save_path) {
						if (Format.edit_mode) {
							Codecs.project.export();
						}
					}
				}
				if (Format.animation_mode && Format.animation_files && AnimationItem.all.length) {
					BarItems.save_all_animations.trigger();
				}
			} else {
				await saveTextures()
				if (Format.codec && Format.codec.export) {
					Format.codec.export()
				}
				/*
				if (Format.codec && Format.codec.export) {

					let codec = await new Promise(resolve => Blockbench.showMessageBox({
						translateKey: 'save_codec_selector',
						icon: 'save',
						commands: {
							project: 'message.save_codec_selector.project_file',
							[export_codec.id]: export_codec.name || 'Default Format',
							both: 'message.save_codec_selector.both',
						},
						buttons: ['dialog.cancel']
					}, resolve));
					
					if (codec == 'both') {
						Codecs.project.export();
						export_codec.export();

					} else if (codec) {
						Codecs[codec].export();
					}

				} else if (Format.edit_mode) {
					Codecs.project.export();

				} else {
					Project.saved = false;
				}*/
			}
			Blockbench.dispatchEvent('quick_save_model', {});
		}
	})
	if (!isApp) {
		new Action('export_asset_archive', {
			icon: 'archive',
			category: 'file',
			condition: _ => Format && Format.codec,
			click: function() {
				var archive = new JSZip();
				var content = Format.codec.compile()
				var name = `${Format.codec.fileName()}.${Format.codec.extension}`
				archive.file(name, content)
				Texture.all.forEach(tex => {
					if (tex.mode === 'bitmap') {
						archive.file(pathToName(tex.name) + '.png', tex.source.replace('data:image/png;base64,', ''), {base64: true});
					}
				})
				archive.generateAsync({type: 'blob'}).then(content => {
					Blockbench.export({
						type: 'Zip Archive',
						extensions: ['zip'],
						name: 'assets',
						startpath: Project.export_path,
						content: content,
						savetype: 'zip'
					})
					Project.saved = true;
				})
			}
		})
	}

})

Object.assign(window, {
	setupDragHandlers,
	loadModelFile,
	loadImages,
	Extruder,
	unsupportedFileFormatMessage,
	compileJSON,
	autoParseJSON,
})
